"""Derived full-text index over the vault (SQLite FTS5, BM25). Never a source of truth.

The index keeps itself current: every query first syncs it against the files, using each
file's (mtime, size) signature, so pages written moments ago are searchable and deleted
pages disappear, with no manual step.
"""

from __future__ import annotations

import os
import re
import sqlite3
import zlib
from collections.abc import Callable
from contextlib import closing
from dataclasses import dataclass
from typing import Literal

from sb.frontmatter import FrontmatterError, parse
from sb.pages import Page, load_page, strip_data_uris
from sb.vault import Vault, VaultError, fold, read_text

INDEXED_ZONES = frozenset({"wiki", "notes", "context", "memory", "sources"})
_SCHEMA = (
    "CREATE VIRTUAL TABLE IF NOT EXISTS pages USING fts5("
    "path UNINDEXED, title, description, body, type UNINDEXED, "
    "tokenize = 'unicode61 remove_diacritics 2')",
    "CREATE TABLE IF NOT EXISTS files (path TEXT PRIMARY KEY, sig TEXT)",
)
# bm25() weights per column: path (unindexed), title, description, body, type (unindexed).
# Lower score = better.
# Zone weight (bm25 is negative: a larger multiplier ranks higher). Compiled knowledge is
# what a query should read first; raw sources are for checking quotes, and working memory
# mentions everything in passing (ADR-012).
_ZONE_WEIGHT = (
    "CASE WHEN path LIKE 'wiki/%' THEN 2.0 "
    "WHEN path LIKE 'memory/%' OR path LIKE 'sources/%' THEN 0.7 ELSE 1.0 END"
)
_BM25 = "bm25(pages, 0.0, 10.0, 5.0, 1.0, 0.0)"
_ROW_REV = "3"  # bump when what `_row` stores changes; schema, ranking and weights need no bump


def _recipe_id(*parts: str) -> int:
    """A positive 31-bit fingerprint of how the index is built (it fits `PRAGMA user_version`)."""
    return zlib.crc32("\0".join(parts).encode()) & 0x7FFFFFFF or 1


# An index built by another recipe is rebuilt automatically (ADR-019).
_RECIPE_ID = _recipe_id(*_SCHEMA, _BM25, _ZONE_WEIGHT, _ROW_REV)
_LOCK_WAIT = 5.0  # seconds to wait for another program that holds the index
_UNUSABLE = "the search index is unusable: delete .sb/index.sqlite, then run `sb index rebuild`"
_INSERT = "INSERT INTO pages(path, title, description, body, type) VALUES (?, ?, ?, ?, ?)"
_FILTERS = {"zone": "path LIKE ?", "type": "type = ?"}  # fixed fragments; values are bound


def _sql(*filters: str) -> str:
    """The search statement; `filters` narrow it before the limit, `path` breaks score ties."""
    where = " AND ".join(("pages MATCH ?", *(_FILTERS[name] for name in filters)))
    return (
        f"SELECT path, title, snippet(pages, 3, ?, ?, '…', 12), {_BM25} AS raw, "
        f"{_ZONE_WEIGHT} AS weight FROM pages WHERE {where} ORDER BY raw * weight, path LIMIT ?"
    )


# Control characters mark hits inside snippets: they never occur in text, so the snippet
# window can be located in the file exactly. Displayed as «guillemets».
_HI_START, _HI_END = chr(2), chr(3)
# Function words that match nearly every page (pt-BR and English). Dropped from queries
# unless the query has nothing else.
STOPWORDS = frozenset(  # folded like the query terms, so "são" and "até" match too
    fold(word)
    for word in [
        "a",
        "o",
        "as",
        "os",
        "um",
        "uma",
        "uns",
        "umas",
        "de",
        "do",
        "da",
        "dos",
        "das",
        "em",
        "no",
        "na",
        "nos",
        "nas",
        "por",
        "pelo",
        "pela",
        "para",
        "com",
        "sem",
        "e",
        "ou",
        "que",
        "se",
        "como",
        "quem",  # question words: asking "quem é X" is searching for X
        "qual",
        "quais",
        "onde",
        "quando",
        "quanto",
        "quanta",
        "quantos",
        "quantas",
        "porque",
        "who",
        "whom",
        "whose",
        "what",
        "which",
        "where",
        "when",
        "why",
        "how",
        "mas",
        "mais",
        "menos",
        "ao",
        "aos",
        "à",
        "às",
        "é",
        "são",
        "ser",
        "foi",
        "entre",
        "sobre",
        "até",
        "the",
        "an",
        "of",
        "in",
        "on",
        "at",
        "to",
        "for",
        "with",
        "and",
        "or",
        "is",
        "are",
        "be",
        "by",
        "from",
        "as",
        "this",
        "that",
        "it",
        "its",
    ]
)


@dataclass(frozen=True)
class Hit:
    path: str
    title: str
    line: int
    snippet: str
    score: float  # raw * weight; lower ranks higher
    raw: float = 0.0  # bm25 before the zone weight (shown by `--explain`)
    weight: float = 1.0  # the zone weight (ADR-012)

    @property
    def citation(self) -> str:
        return f"{self.path}:{self.line}"


@dataclass(frozen=True)
class SyncReport:
    changed: int  # paths added, updated or removed in the index
    unreadable: tuple[str, ...] = ()  # paths skipped this time; their old rows stay, retried later


def _open(vault: Vault) -> sqlite3.Connection:
    """Open the index built by the current recipe; `sqlite3.DatabaseError` if it is not usable."""
    conn = sqlite3.connect(vault.index_db, timeout=_LOCK_WAIT)
    try:
        conn.execute("PRAGMA secure_delete = ON")  # freed pages are zeroed: deleted text is gone
        version = conn.execute("PRAGMA user_version").fetchone()[0]
        if version == 0 and conn.execute("SELECT 1 FROM sqlite_master").fetchone() is None:
            conn.execute(f"PRAGMA user_version = {_RECIPE_ID}")  # a brand-new file
        elif version != _RECIPE_ID:
            raise sqlite3.DatabaseError("the index was built by another recipe")
        for statement in _SCHEMA:
            conn.execute(statement)
    except BaseException:
        conn.close()
        raise
    return conn


_FULL_DISK = ("full", "read-only", "readonly", "i/o error")  # the environment, not the index


def _refuse_if_busy(exc: sqlite3.DatabaseError) -> None:
    message = str(exc).lower()
    if "locked" in message or "busy" in message:  # healthy, only in use: never discard it
        raise VaultError("the search index is in use by another program; try again") from exc
    if any(word in message for word in _FULL_DISK):  # rebuilding would fail the same way
        raise VaultError(
            f"the search index cannot be written ({exc}); fix the cause and retry"
        ) from exc


def _discard(vault: Vault) -> None:
    """Delete the index file: it is derived data, so starting over loses nothing (ADR-002)."""
    try:
        vault.index_db.unlink(missing_ok=True)
    except OSError as exc:
        raise VaultError(_UNUSABLE) from exc


def _connect(vault: Vault) -> sqlite3.Connection:
    """Open the index, discarding it once if it is damaged or from another recipe."""
    vault.state.mkdir(exist_ok=True)
    try:
        return _open(vault)
    except sqlite3.DatabaseError as exc:
        _refuse_if_busy(exc)
    _discard(vault)
    try:
        return _open(vault)
    except sqlite3.DatabaseError as exc:
        _refuse_if_busy(exc)
        raise VaultError(_UNUSABLE) from exc


def _with_index[T](vault: Vault, work: Callable[[sqlite3.Connection], T]) -> T:
    """Run `work` on the index in one transaction.

    If the index proves damaged half-way (a truncated page, a malformed table), discard it and
    run `work` once more on a fresh one. An index that is only in use is never discarded.
    """
    error: sqlite3.DatabaseError | None = None
    for attempt in range(2):
        conn = _connect(vault)
        try:
            with conn:
                return work(conn)
        except sqlite3.DatabaseError as exc:
            _refuse_if_busy(exc)
            error = exc
        finally:
            conn.close()
        if attempt == 0:
            _discard(vault)
    raise VaultError(_UNUSABLE) from error


def _signature(entry: os.DirEntry[str]) -> str:
    """Changes whenever the file does: atomic writes also give it a new inode and ctime.

    On Windows the DirEntry stat comes from the directory listing (no extra syscall);
    there `st_ino` is 0 and ctime is the creation time, which a replace also renews.
    """
    st = entry.stat()
    return f"{st.st_mtime_ns}:{st.st_size}:{st.st_ino}:{st.st_ctime_ns}"


_Row = tuple[str, str, str, str, str]  # path, title, description, body, type


def _row(page: Page) -> _Row:
    """What the index reads of a page: its body without inline images (the file is untouched)."""
    description = str(page.meta.get("description", ""))
    kind = page.meta.get("type")
    kind = "" if kind is None else str(kind)
    return (page.rel, page.title, description, strip_data_uris(page.body), kind)


def sync(vault: Vault) -> SyncReport:
    """Bring the index in line with the files.

    A file the operating system will not give us right now (locked by another program, replaced
    while scanning) keeps its old row and its old signature, so the next sync tries it again.
    """
    current: dict[str, str] = {}
    unreadable: list[str] = []
    for rel, entry in vault.entries(".md"):
        if rel.split("/", 1)[0] in INDEXED_ZONES:
            try:
                current[rel] = _signature(entry)
            except OSError:
                unreadable.append(rel)

    def apply(conn: sqlite3.Connection) -> tuple[int, list[str]]:
        skipped: list[str] = []
        known = dict(conn.execute("SELECT path, sig FROM files"))
        changed = [rel for rel, sig in current.items() if known.get(rel) != sig]
        removed = [rel for rel in known if rel not in current and rel not in unreadable]
        conn.executemany("DELETE FROM pages WHERE path = ?", [(r,) for r in removed])
        conn.executemany("DELETE FROM files WHERE path = ?", [(r,) for r in removed])
        count = len(removed)
        dropped = bool(removed)  # did any text leave the index?
        for rel in changed:
            try:
                row: _Row | None = _row(load_page(vault, vault.root / rel))
            except OSError:
                skipped.append(rel)
                continue
            except (FrontmatterError, UnicodeDecodeError):
                row = None  # unparsable pages are lint's business; remember the signature anyway
            conn.execute("DELETE FROM pages WHERE path = ?", (rel,))
            conn.execute("DELETE FROM files WHERE path = ?", (rel,))
            dropped = dropped or rel in known
            if row is not None:
                conn.execute(_INSERT, row)
            conn.execute("INSERT INTO files VALUES (?, ?)", (rel, current[rel]))
            count += 1
        if dropped:
            # FTS5 keeps the terms of deleted rows in old segments until they merge: merge now,
            # so text that left the vault (a secret that was removed) leaves the index file too.
            conn.execute("INSERT INTO pages(pages) VALUES ('optimize')")
        return count, skipped

    count, skipped = _with_index(vault, apply)
    return SyncReport(count, tuple(sorted({*unreadable, *skipped})))


@dataclass(frozen=True)
class Health:
    status: Literal["ok", "absent", "recipe", "busy", "damaged"]
    pages: int = 0
    detail: str = ""


def health(vault: Vault) -> Health:
    """What state the index file is in, without touching it (`sb doctor`).

    A damaged index or one from another recipe is not an emergency: the next search heals it.
    """
    if not vault.index_db.is_file():
        return Health("absent")
    try:
        with closing(sqlite3.connect(f"{vault.index_db.as_uri()}?mode=ro", uri=True)) as conn:
            version = conn.execute("PRAGMA user_version").fetchone()[0]
            if conn.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                return Health("damaged", detail="fails SQLite's own integrity check")
            if version != _RECIPE_ID:
                return Health("recipe")
            return Health("ok", pages=conn.execute("SELECT count(*) FROM pages").fetchone()[0])
    except sqlite3.DatabaseError as exc:
        if "locked" in str(exc).lower() or "busy" in str(exc).lower():
            return Health("busy")  # another program is using a healthy index right now
        return Health("damaged", detail=f"is unreadable ({exc})")


def rebuild(vault: Vault) -> SyncReport:
    """Drop and recreate the index from the files."""
    _discard(vault)
    return sync(vault)


def _tokens(text: str) -> list[str]:
    return re.findall(r"\w+", fold(text))


def _cite_line(vault: Vault, rel: str, snippet: str, terms: list[str]) -> int:
    """1-based file line of the snippet's first highlighted term.

    The snippet window is located in the file's token stream (so it may span lines);
    failing that, the first line with a query term; failing that, line 1.
    """
    try:
        lines = read_text(vault.root / rel).split("\n")
    except (OSError, UnicodeDecodeError):
        return 1  # the file went bad after the sync; the hit itself is still real
    try:
        body_start = parse("\n".join(lines)).body_offset  # snippets come from the body only
    except FrontmatterError:
        body_start = 0
    lines = [strip_data_uris(line) for line in lines]  # the index never saw the payloads either
    stream = [
        (tok, n) for n, line in enumerate(lines, start=1) if n > body_start for tok in _tokens(line)
    ]
    parts = snippet.split(_HI_START)
    if len(parts) > 1:
        before, hit = _tokens(parts[0])[-3:], _tokens(parts[1].split(_HI_END)[0])
        window = before + hit[:1]
        words = [tok for tok, _ in stream]
        for i in range(len(words) - len(window) + 1):
            if words[i : i + len(window)] == window:
                return stream[i + len(before)][1]
    folded = [fold(t.rstrip("*")) for t in terms]
    body_lines = list(enumerate(lines, 1))[body_start:]  # snippets never come from frontmatter
    return next((n for n, line in body_lines if any(t in fold(line) for t in folded)), 1)


def _match_terms(text: str) -> list[str]:
    """Query words minus stopwords (unless nothing else is left); `term*` stays a prefix."""
    terms = re.findall(r"\w+\*?", text)
    content = [t for t in terms if t.endswith("*") or fold(t) not in STOPWORDS]
    return content or terms


def _fts(term: str) -> str:
    return f'"{term.rstrip("*")}"*' if term.endswith("*") else f'"{term}"'


def query(
    vault: Vault,
    text: str,
    limit: int = 5,
    *,
    zone: str | None = None,
    page_type: str | None = None,
) -> list[Hit]:
    """Match all content terms; if nothing matches, fall back to any of them."""
    return query_report(vault, text, limit, zone=zone, page_type=page_type)[0]


def query_report(
    vault: Vault,
    text: str,
    limit: int = 5,
    *,
    zone: str | None = None,
    page_type: str | None = None,
) -> tuple[list[Hit], SyncReport]:
    """`query`, plus what the sync could not read (so the CLI can say results may be partial).

    `zone` and `page_type` (the frontmatter `type`, compared exactly) narrow the search before
    the limit, so `limit` pages that match are returned even when better ones are filtered out.
    """
    if zone is not None and zone not in INDEXED_ZONES:
        raise VaultError(f"unknown zone {zone!r}; the searchable zones are {_zones()}")
    terms = _match_terms(text)
    if not terms:
        return [], SyncReport(0)
    report = sync(vault)
    quoted = [_fts(t) for t in terms]
    filters = {"zone": f"{zone}/%" if zone else None, "type": page_type}
    active = [name for name, value in filters.items() if value is not None]
    values = [filters[name] for name in active]
    sql = _sql(*active)

    def select(conn: sqlite3.Connection) -> list[tuple[str, str, str, float, float]]:
        marks = (_HI_START, _HI_END)
        rows = conn.execute(sql, (*marks, " ".join(quoted), *values, limit)).fetchall()
        if not rows and len(quoted) > 1:
            rows = conn.execute(sql, (*marks, " OR ".join(quoted), *values, limit)).fetchall()
        return list(rows)

    rows = _with_index(vault, select)
    hits = [
        Hit(
            path,
            title,
            _cite_line(vault, path, snip, terms),
            _display(snip),
            raw * weight,
            raw,
            weight,
        )
        for path, title, snip, raw, weight in rows
        if (vault.root / path).is_file()
    ]
    return hits, report


def _zones() -> str:
    return ", ".join(sorted(INDEXED_ZONES))


def _display(snippet: str) -> str:
    """One line, with «guillemets» around hits: `[ ]` would collide with [[wikilinks]]."""
    return " ".join(snippet.replace(_HI_START, "«").replace(_HI_END, "»").split())
