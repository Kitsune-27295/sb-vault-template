"""What a page relates to, worked out on demand from the vault (ADR-030).

The wikilinks are the explicit relations; everything else here is a correlation the vault already
implies and nobody wrote down: who links here, which pages draw on the same sources, which have
similar words or similar meaning, and which pages are named in the text without a link. Nothing is
stored (the pages are the truth) and nothing is decided: it is a list of leads for the curator or
the `consolidate` skill (ADR-004).
"""

from __future__ import annotations

import re
from typing import Any

from sb import search, vectors
from sb.pages import Page, link_key, load_pages, mask_code
from sb.vault import Vault, VaultError, fold

MIN_MENTION = 5  # a shorter page name would match inside any text
_WIKILINK = re.compile(r"\[\[.*?\]\]", re.DOTALL)


def find(pages: list[Page], name: str) -> Page:
    """The page called `name` (case and `.md` do not matter) or at the vault path `name`."""
    wanted = name.strip().replace("\\", "/").casefold()
    for page in pages:
        if wanted in {page.rel.casefold(), page.rel.casefold().removesuffix(".md")}:
            return page
        if link_key(page.name) == link_key(name):
            return page
    raise VaultError(f"no page named {name!r}; find it with `sb search`")


def _item(page: Page, **extra: Any) -> dict[str, Any]:
    return {"path": page.rel, "title": page.title, **extra}


def report(vault: Vault, name: str, limit: int = 10) -> dict[str, Any]:
    """The relations and correlations of one page; every list is capped at `limit`."""
    pages = load_pages(vault)
    page = find(pages, name)
    by_key = {link_key(p.name): p for p in pages}
    by_rel = {p.rel: p for p in pages}

    links_to: dict[str, int] = {}
    for target, line in page.links():
        other = by_key.get(link_key(target))
        if other is not None and other is not page:
            links_to.setdefault(other.rel, line)

    linked_from: dict[str, int] = {}
    for other in pages:
        if other is not page:
            for target, line in other.links():
                if link_key(target) == link_key(page.name):
                    linked_from.setdefault(other.rel, line)
                    break

    cited = set(page.source_ids())
    shares = sorted(
        (
            (other, sorted(cited & set(other.source_ids())))
            for other in pages
            if other is not page and other.zone != "sources" and cited & set(other.source_ids())
        ),
        key=lambda pair: (-len(pair[1]), pair[0].rel),
    )

    query = f"{page.title} {page.meta.get('description', '')}"
    similar_text = [h for h in search.query(vault, query, limit + 1) if h.path != page.rel][:limit]
    try:
        meaning = vectors.neighbors(vault, page.rel, limit)
    except VaultError:
        meaning = None  # vectors from two models: the other sections still stand

    linked_keys = {link_key(target) for target, _ in page.links()}
    text = fold(_WIKILINK.sub(" ", mask_code(page.body)))
    unlinked = [
        other
        for other in pages
        if other is not page
        and other.zone != "sources"
        and len(other.name) >= MIN_MENTION
        and link_key(other.name) not in linked_keys
        and re.search(rf"(?<!\w){re.escape(fold(other.name))}(?!\w)", text)
    ]

    return {
        "page": page.rel,
        "links_to": [_item(by_rel[rel], line=line) for rel, line in list(links_to.items())[:limit]],
        "linked_from": [
            _item(by_rel[rel], line=line) for rel, line in list(linked_from.items())[:limit]
        ],
        "shares_sources": [_item(other, shared=ids) for other, ids in shares[:limit]],
        "similar_text": [
            {"path": h.path, "title": h.title, "citation": h.citation} for h in similar_text
        ],
        "similar_meaning": None
        if meaning is None
        else [_item(by_rel[rel], score=round(score, 3)) for rel, score in meaning if rel in by_rel],
        "unlinked_mentions": [_item(other) for other in unlinked[:limit]],
    }


_SECTIONS = (
    ("links_to", "links to"),
    ("linked_from", "linked from"),
    ("shares_sources", "draws on the same sources as"),
    ("similar_text", "has similar words to"),
    ("similar_meaning", "means something close to"),
    ("unlinked_mentions", "is named in its text, without a link"),
)


def render(data: dict[str, Any]) -> str:
    """The report as text: one line per related page, grouped by how it is related."""
    lines = [str(data["page"])]
    for key, title in _SECTIONS:
        items = data[key]
        if items is None:
            lines.append("  (no vectors: run `sb index vectors` to see pages close in meaning)")
            continue
        for item in items:
            where = item.get("citation") or item["path"]
            if "line" in item:
                where = f"{item['path']}:{item['line']}"
            note = ""
            if "shared" in item:
                note = f"  [{', '.join(item['shared'])}]"
            if "score" in item:
                note = f"  ({item['score']})"
            lines.append(f"  {title}: {where}{note}  {item['title']}")
    if len(lines) == 1:
        lines.append("  nothing related found")
    return "\n".join(lines)
