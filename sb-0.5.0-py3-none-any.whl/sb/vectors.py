"""Optional semantic search (ADR-026): chunk vectors, fused with the lexical search.

Off by default and costing nothing when unused. It needs the `vector` extra (`model2vec`), and the
model, about 1 GB, is downloaded once by that library the first time a command asks for it. The
vectors live in `.sb/vectors.sqlite`, a cache like the search index: deleting it loses nothing, and
a damaged or older-recipe file is discarded and rebuilt by itself (ADR-019).
"""

from __future__ import annotations

import array
import hashlib
import math
import sqlite3
from collections.abc import Callable, Generator, Sequence
from contextlib import contextmanager
from dataclasses import replace

from sb import search
from sb.frontmatter import FrontmatterError
from sb.pages import Page, load_page, strip_data_uris
from sb.search import Hit, SyncReport
from sb.vault import Vault, VaultError

MODEL = "minishlab/potion-multilingual-128M"  # 256 dimensions, 101 languages (static embeddings)
RRF_K = 60  # reciprocal rank fusion, the constant of the original paper and of ADR-003
# A page is cut in fixed pieces with a modest overlap: the model reads only about 512 tokens (about
# 2,200 characters) of a text, so one vector per page forgets the tail of a long page (ADR-026).
CHUNK, OVERLAP, MAX_CHUNKS = 1500, 225, 40
BATCH = 32  # pages embedded and stored together, so an interrupted run keeps its progress
Embedder = Callable[[Sequence[str]], list[list[float]]]
_SCHEMA = (
    "CREATE TABLE vectors (path TEXT NOT NULL, n INTEGER NOT NULL, digest TEXT NOT NULL, "
    "sig TEXT NOT NULL, vec BLOB NOT NULL, PRIMARY KEY (path, n))"
)
# A cache made by another recipe (layout, cut, normalisation) is rebuilt, like the search index.
_TEXT_REV = "1"  # bump when what `_chunks` puts in front of each piece changes
_RECIPE_ID = search.recipe_id(
    _SCHEMA, str(CHUNK), str(OVERLAP), str(MAX_CHUNKS), "unit-f32", _TEXT_REV
)
_LOCK_WAIT = 5.0
_BUSY = "the vector cache is in use by another program; try again in a moment"
_UNUSABLE = "the vector cache is unusable: delete .sb/vectors.sqlite, then run `sb index vectors`"
_OTHER_MODEL = (
    "the stored vectors come from another model: delete .sb/vectors.sqlite, "
    "then run `sb index vectors`"
)


def load_model(name: str = MODEL) -> Embedder:
    """The embedding function of a model; the `vector` extra is imported here and nowhere else.

    The cache is tried first, with no network: asking the hub for the model by name would contact
    huggingface.co on every command. Only a missing model is downloaded.
    """
    try:
        from huggingface_hub import snapshot_download
        from model2vec import StaticModel
    except ImportError as exc:
        raise VaultError(
            'semantic search needs the `vector` extra: pip install "sb[vector]" '
            "(it downloads a model of about 1 GB the first time)"
        ) from exc
    try:
        try:
            folder = snapshot_download(name, local_files_only=True)
        except OSError:
            folder = snapshot_download(name)
        model = StaticModel.from_pretrained(folder)
    except OSError as exc:
        raise VaultError(
            f"could not load the model {name} ({exc}); the first use downloads it, "
            "so check the network, then run the command again"
        ) from exc
    return lambda texts: [[float(x) for x in row] for row in model.encode(list(texts))]


def _unit(vector: Sequence[float]) -> array.array[float]:
    norm = math.sqrt(sum(x * x for x in vector)) or 1.0
    return array.array("f", (x / norm for x in vector))


def _chunks(title: str, description: str, body: str) -> list[str]:
    """The texts to embed for a page: its body in overlapping pieces, each led by title and
    description so a piece from the middle still says what page it belongs to."""
    text = strip_data_uris(body).strip()
    step = CHUNK - OVERLAP
    pieces = [text[i : i + CHUNK] for i in range(0, max(len(text), 1), step)][:MAX_CHUNKS]
    return [f"{title}. {description}. {piece}" for piece in pieces]


def _connect(vault: Vault) -> sqlite3.Connection:
    """The cache built by the current recipe; a damaged file is deleted and made again, once."""
    vault.state.mkdir(exist_ok=True)
    path = vault.state / "vectors.sqlite"
    for attempt in (1, 2):
        conn = sqlite3.connect(path, timeout=_LOCK_WAIT)
        try:
            conn.execute("PRAGMA secure_delete = ON")  # a vector can be inverted to its text
            if conn.execute("PRAGMA user_version").fetchone()[0] != _RECIPE_ID:
                with conn:
                    conn.execute("DROP TABLE IF EXISTS vectors")
                    conn.execute(_SCHEMA)
                    conn.execute(f"PRAGMA user_version = {_RECIPE_ID}")
            return conn
        except sqlite3.DatabaseError as exc:
            conn.close()
            if "locked" in str(exc) or "busy" in str(exc):
                raise VaultError(_BUSY) from exc
            if attempt == 2:
                raise VaultError(_UNUSABLE) from exc
            path.unlink(missing_ok=True)
    raise VaultError(_UNUSABLE)  # unreachable: the second attempt raises


@contextmanager
def _open(vault: Vault) -> Generator[sqlite3.Connection]:
    conn = _connect(vault)
    try:
        yield conn
    except sqlite3.Error as exc:
        busy = "locked" in str(exc) or "busy" in str(exc)
        raise VaultError(_BUSY if busy else _UNUSABLE) from exc
    finally:
        conn.close()


def _pieces(vault: Vault, rel: str) -> list[str] | None:
    """The texts to embed for one page; None if the page does not parse. `OSError` if unreadable."""
    try:
        page = load_page(vault, vault.root / rel)
    except (FrontmatterError, UnicodeDecodeError):
        return None  # unparsable pages are lint's business, and the plain index skips them too
    return _chunks(page.title, str(page.meta.get("description", "")), page.body)


def sync(vault: Vault, embed: Embedder, model: str = MODEL) -> SyncReport:
    """Embed the pages whose text changed since the last time; `changed` counts them.

    Like the search index, it tells a changed file by its signature, so a page that did not change
    is not even read. A page is identified by a digest of the model name and its pieces, so
    changing the model re-embeds everything, a file touched without changing its text is not
    embedded again, and a deleted page loses its vectors. A page the system will not give us right
    now keeps its old vectors and is tried again next time. Pages are stored in batches, so an
    interrupted run keeps what it finished.
    """
    sigs: dict[str, str] = {}
    unreadable: set[str] = set()
    for rel, entry in vault.entries(".md"):
        if rel.split("/", 1)[0] in search.INDEXED_ZONES:
            try:
                sigs[rel] = f"{model}\0{search.signature(entry)}"
            except OSError:
                unreadable.add(rel)
    with _open(vault) as conn:
        known = {
            path: (sig, digest)
            for path, sig, digest in conn.execute("SELECT DISTINCT path, sig, digest FROM vectors")
        }
        drop = [rel for rel in known if rel not in sigs and rel not in unreadable]
        texts: dict[str, list[str]] = {}
        digests: dict[str, str] = {}
        touched: list[str] = []  # the file changed, its text did not
        for rel, sig in sigs.items():
            if known.get(rel, ("", ""))[0] == sig:
                continue
            try:
                pieces = _pieces(vault, rel)
            except OSError:
                unreadable.add(rel)
                continue
            if pieces is None:
                drop.append(rel)
                continue
            digest = hashlib.sha1("\0".join((model, *pieces)).encode()).hexdigest()
            if known.get(rel, ("", ""))[1] == digest:
                touched.append(rel)
            else:
                texts[rel], digests[rel] = pieces, digest
        with conn:
            conn.executemany("DELETE FROM vectors WHERE path = ?", [(rel,) for rel in set(drop)])
            conn.executemany(
                "UPDATE vectors SET sig = ? WHERE path = ?", [(sigs[rel], rel) for rel in touched]
            )
        todo = list(texts)
        for start in range(0, len(todo), BATCH):
            batch = todo[start : start + BATCH]
            flat = [piece for rel in batch for piece in texts[rel]]
            rows = embed(flat)
            if len(rows) != len(flat):
                raise VaultError(f"the model returned {len(rows)} vectors for {len(flat)} texts")
            vectors_ = iter(rows)
            with conn:
                for rel in batch:
                    conn.execute("DELETE FROM vectors WHERE path = ?", (rel,))
                    conn.executemany(
                        "INSERT INTO vectors VALUES (?, ?, ?, ?, ?)",
                        [
                            (rel, n, digests[rel], sigs[rel], _unit(next(vectors_)).tobytes())
                            for n in range(len(texts[rel]))
                        ],
                    )
    return SyncReport(len(todo), tuple(sorted(unreadable)))


def _nearest(
    conn: sqlite3.Connection,
    query: array.array[float],
    allowed: set[str] | None = None,
    skip: str = "",
    weighted: bool = True,
) -> dict[str, tuple[float, int]]:
    """For each page, its best piece against `query`: (score, piece number).

    The score is the cosine, times the ADR-012 zone weight when `weighted` (a search ranks the
    compiled page above a raw source; "what is like this page" does not).
    """
    best: dict[str, tuple[float, int]] = {}
    for path, n, blob in conn.execute("SELECT path, n, vec FROM vectors"):
        if path == skip or (allowed is not None and path not in allowed):
            continue
        vector = array.array("f")
        vector.frombytes(blob)
        if len(vector) != len(query):
            raise VaultError(_OTHER_MODEL)
        score = sum(a * b for a, b in zip(query, vector, strict=True))
        score *= search.zone_weight(path) if weighted else 1.0
        if path not in best or score > best[path][0]:
            best[path] = (score, n)
    return best


def rank(
    vault: Vault,
    embed: Embedder,
    text: str,
    limit: int = 20,
    allowed: set[str] | None = None,
) -> list[tuple[str, int]]:
    """(path, best piece) by cosine similarity to `text`, best first (vectors must be up to date).

    A page scores as its best piece (the long-page problem: its tail may be the answer), times the
    ADR-012 zone weight, so a raw source does not outvote the compiled page about the same thing.
    `allowed` narrows the pages considered (the zone and type filters of `sb search`).
    """
    query = _unit(embed([text])[0])
    with _open(vault) as conn:
        best = _nearest(conn, query, allowed)
    ordered = sorted(best, key=lambda path: (-best[path][0], path))[:limit]
    return [(path, best[path][1]) for path in ordered]


def neighbors(vault: Vault, rel: str, limit: int = 10) -> list[tuple[str, float]] | None:
    """The pages closest in meaning to the page at `rel`, by cosine, from the stored vectors.

    No model is loaded: the page's own pieces are averaged and compared with the other pages'
    best piece. None when there are no vectors, or none for this page (run `sb index vectors`).
    """
    if not (vault.state / "vectors.sqlite").exists():
        return None  # asking must not create the cache
    with _open(vault) as conn:
        blobs = [row[0] for row in conn.execute("SELECT vec FROM vectors WHERE path = ?", (rel,))]
        if not blobs:
            return None
        total: list[float] = []
        for blob in blobs:
            vector = array.array("f")
            vector.frombytes(blob)
            total = (
                list(vector) if not total else [a + b for a, b in zip(total, vector, strict=True)]
            )
        best = _nearest(conn, _unit(total), skip=rel, weighted=False)
    ordered = sorted(best, key=lambda path: (-best[path][0], path))[:limit]
    return [(path, best[path][0]) for path in ordered]


def _piece_line(page: Page, n: int, piece: str) -> int:
    """The line piece `n` starts on; the first line of the body if it cannot be placed."""
    body = page.body
    if strip_data_uris(body) == body:  # nothing was removed, so the cut maps straight back
        start = len(body) - len(body.lstrip()) + n * (CHUNK - OVERLAP)
    else:
        start = max(body.find(piece[:40]), 0)
    return page.body_offset + 1 + body.count("\n", 0, start)


def _semantic_hit(vault: Vault, path: str, n: int) -> Hit | None:
    """A hit only the vectors found: the piece that matched is its snippet and its citation.

    No word matched, so the snippet says so. None when the page went away since the last sync.
    """
    try:
        page = load_page(vault, vault.root / path)
    except (OSError, FrontmatterError, UnicodeDecodeError):
        return None
    description = str(page.meta.get("description", ""))
    pieces = _chunks(page.title, description, page.body)
    if n >= len(pieces):  # the page changed since the sync
        return Hit(
            path, page.title, page.body_offset + 1, f"(by meaning) {description}".strip(), 0.0
        )
    piece = pieces[n].removeprefix(f"{page.title}. {description}. ")
    shown = piece if n == 0 or piece[:1].isspace() else piece.partition(" ")[2]  # drop a cut word
    text = " ".join(shown.split())[:160] or description
    return Hit(path, page.title, _piece_line(page, n, piece), f"(by meaning) {text}", 0.0)


def hybrid(
    vault: Vault,
    embed: Embedder,
    text: str,
    limit: int = 5,
    *,
    zone: str | None = None,
    page_type: str | None = None,
) -> tuple[list[Hit], SyncReport]:
    """The lexical hits and the semantic ones, fused by reciprocal rank (ADR-003: k=60).

    A page both searches found rises; a page only the vectors found enters with the piece that
    matched, as snippet and citation. The score is the negated fusion score, so a lower score
    still ranks higher.
    The report is the lexical sync's, so the caller can say that results may be partial.
    """
    lexical, report = search.query_report(vault, text, limit * 4, zone=zone, page_type=page_type)
    narrowed = zone is not None or page_type is not None
    allowed = search.filtered_paths(vault, zone=zone, page_type=page_type) if narrowed else None
    semantic = rank(vault, embed, text, limit * 4, allowed)
    fused: dict[str, float] = {}
    for ranking in ([h.path for h in lexical], [path for path, _ in semantic]):
        for position, path in enumerate(ranking, start=1):
            fused[path] = fused.get(path, 0.0) + 1.0 / (RRF_K + position)
    by_path = {h.path: h for h in lexical}
    piece_of = dict(semantic)
    hits: list[Hit] = []
    for path in sorted(fused, key=lambda path: (-fused[path], path)):
        hit = by_path.get(path) or _semantic_hit(vault, path, piece_of[path])
        if hit is not None:
            hits.append(replace(hit, score=-fused[path]))
        if len(hits) == limit:
            break
    return hits, report
