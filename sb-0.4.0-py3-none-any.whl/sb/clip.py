"""Native capture from links (ADR-014): pages, PDFs, videos and playlists into the inbox.

The only module in `sb` that touches the network, imported only by `sb clip`. Its
libraries are the optional `capture` extra. Every capture goes through
`sources.capture_text`, so ids, normalisation and the credential refusal are the same
as for files; captured text is data, never instructions.
"""

from __future__ import annotations

import hashlib
import http.client
import io
import json
import logging
import re
import time
import urllib.error
import urllib.request
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal
from urllib.parse import parse_qsl, quote, unquote, urlencode, urlsplit, urlunsplit

from sb.sources import capture_text, source_metas
from sb.vault import Vault, VaultError, redact

MAX_BYTES = 25_000_000  # refuse larger downloads: a knowledge source, not a dataset
TIMEOUT = 30
RETRIES = 3  # on 429/503 only
BACKOFF = 5.0  # seconds, doubled per attempt
MAX_WAIT = 60.0
PLAYLIST_PAUSE = 2.0  # seconds between the videos of one playlist: be a polite client
COLLECTION_CAP = 200  # videos taken from one playlist or channel when --limit is not given
_sleep = time.sleep  # replaced in tests
USER_AGENT = "sb-clip/0.1 (+personal knowledge base; one link at a time)"
VIDEO_HOSTS = frozenset(
    {"youtube.com", "youtu.be", "music.youtube.com", "vimeo.com", "dailymotion.com", "ted.com"}
)
_TRACKING = re.compile(r"^(utm_.*|fbclid|gclid|dclid|mc_cid|mc_eid|igshid|si|feature|ref_src)$")
_YT_ID = re.compile(r"[A-Za-z0-9_-]{11}")

Status = Literal["captured", "exists", "expanded", "failed"]
Fetch = Callable[[str], tuple[bytes, str]]  # url -> (body, content type)
VideoInfo = Callable[[str, bool], dict[str, Any]]  # url, flat -> yt-dlp info dict
CaptionFetch = Callable[[str], bytes]  # caption track url -> bytes


@dataclass(frozen=True)
class ClipOutcome:
    url: str
    status: Status
    source_id: str = ""
    detail: str = ""


class ClipError(Exception):
    """One link could not be captured; the others continue."""


# --- URL identity ------------------------------------------------------------------------


def _host(netloc: str) -> str:
    host = netloc.lower().rsplit("@", 1)[-1].split(":", 1)[0]
    for prefix in ("www.", "m."):
        host = host.removeprefix(prefix)
    return host


def canonical_url(url: str) -> str:
    """One spelling per resource, so the same link is never captured twice.

    Lower-case scheme and host without `www.`/`m.`, no fragment, no tracking parameters,
    sorted query, no trailing slash; YouTube short, embed, shorts and live forms become
    `https://youtube.com/watch?v=ID`, a bare playlist `https://youtube.com/playlist?list=ID`.
    """
    raw = url.strip()
    if "://" not in raw:
        raw = "https://" + raw
    parts = urlsplit(raw)
    host = _ascii_host(_host(parts.netloc))  # same IDNA form `fetchable_url` stores
    try:
        port = parts.port
    except ValueError:  # a malformed port: keep the link's identity without it
        port = None
    if port is not None and port not in {80, 443}:
        host = f"{host}:{port}"  # a different port is a different service
    # keep_blank_values: `?WelcomeVisitors` and `?ExtremeProgramming` are different pages
    query = [
        (k, v)
        for k, v in parse_qsl(parts.query, keep_blank_values=True)
        if not _TRACKING.match(k.lower())
    ]
    # One spelling for "São Paulo", "S%C3%A3o%20Paulo" and "S%c3%a3o Paulo".
    path = quote(unquote(parts.path), safe=_PATH_SAFE).rstrip("/") or "/"
    if host in {"youtube.com", "music.youtube.com", "youtu.be"}:
        video = dict(query).get("v")
        segments = [s for s in path.split("/") if s]
        if host == "youtu.be" and segments:
            video = segments[0]
        elif len(segments) == 2 and segments[0] in {"shorts", "embed", "live", "v"}:
            video = segments[1]
        if video and _YT_ID.fullmatch(video):
            return f"https://youtube.com/watch?v={video}"
        playlist = dict(query).get("list")
        if playlist:
            return f"https://youtube.com/playlist?list={playlist}"
        host = "youtube.com"
    scheme = "https" if parts.scheme.lower() in {"http", "https"} else parts.scheme.lower()
    return urlunsplit((scheme, host, path, urlencode(sorted(query)), ""))


def fetchable_url(url: str) -> str:
    """The link as the site expects it: scheme added if missing, fragment and trackers gone,
    host, path and remaining query untouched (unlike `canonical_url`, which is for identity)."""
    raw = url.strip()
    if "://" not in raw:
        raw = "https://" + raw
    parts = urlsplit(raw)
    netloc = _ascii_netloc(parts.netloc)
    path = quote(parts.path, safe=_PATH_SAFE)  # "São Paulo" -> "S%C3%A3o%20Paulo"; %xx kept
    return urlunsplit((parts.scheme, netloc, path, "&".join(_query_items(parts.query)), ""))


_PATH_SAFE = "/%:@!$&'()*+,;=-._~"


def _query_items(query: str) -> list[str]:
    """Query parts as written (`?Flag` and `a=1` alike), minus tracking parameters."""
    return [p for p in query.split("&") if p and not _TRACKING.match(p.split("=", 1)[0].lower())]


_ARXIV_ABS = re.compile(r"https?://(?:www\.)?arxiv\.org/abs/([^?#]+)", re.I)


def full_text_url(url: str) -> str:
    """Where the full text lives when a link points at a summary page.

    An arXiv `abs` page is only the abstract (ingest found papers captured that way), so
    its PDF is fetched instead; the `abs` link stays the source's identity.
    """
    match = _ARXIV_ABS.match(url)
    return f"https://arxiv.org/pdf/{match.group(1)}" if match else url


def is_playlist(url: str) -> bool:
    """A collection of videos: a playlist, or a channel/handle page (never one video).

    Review F4: `youtube.com/@channel` treated as a video made yt-dlp resolve the whole
    channel. Collections are expanded flat, capped by `--limit` or `COLLECTION_CAP`.
    """
    key = canonical_url(url)
    parts = urlsplit(key)
    host, segments = _host(parts.netloc), [s for s in parts.path.split("/") if s]
    if host == "youtube.com":
        return not key.startswith("https://youtube.com/watch?") and bool(segments)
    if host == "vimeo.com":
        return bool(segments) and not _vimeo_video(segments)
    return False


def _vimeo_video(segments: list[str]) -> bool:
    """`/123`, `/123/<privacy hash>` (unlisted), `/channels/x/123`, `/showcase/9/video/77`:
    a numeric id that does not directly follow a collection root is a video."""
    roots = {"showcase", "album", "channels", "groups", "user"}
    if len(segments) == 2 and segments[0].isdigit():  # unlisted: id then privacy hash
        return True
    return segments[-1].isdigit() and (len(segments) == 1 or segments[-2] not in roots)


def _ascii_netloc(netloc: str) -> str:
    """IDNA only the host name; userinfo, port and IPv6 brackets are kept as written."""
    userinfo, _, hostport = netloc.rpartition("@")
    if hostport.startswith("["):  # IPv6 literal: nothing to encode
        return netloc
    host, sep, port = hostport.partition(":")
    return f"{userinfo + '@' if userinfo else ''}{_ascii_host(host)}{sep}{port}"


def _ascii_host(host: str) -> str:
    try:
        return host.encode("idna").decode("ascii")
    except UnicodeError:
        return host


def is_video(url: str) -> bool:
    key = canonical_url(url)
    host = _host(urlsplit(key).netloc)
    return host in VIDEO_HOSTS and not is_playlist(key) and urlsplit(key).path not in {"", "/"}


# --- fetching ------------------------------------------------------------------------------


def http_fetch(url: str) -> tuple[bytes, str]:
    """GET with a clear User-Agent, a timeout and a size cap; returns (body, content type).

    A 429 or 503 is retried (E5: YouTube rate-limits caption requests), honouring
    `Retry-After` up to `MAX_WAIT` seconds, with exponential backoff otherwise.
    """
    parts = urlsplit(url)
    if parts.username or parts.password:  # urllib cannot send them, and its errors would echo them
        raise ClipError(
            "the link carries a user name or password; sb clip fetches public pages only"
        )
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    body, ctype = b"", ""
    for attempt in range(RETRIES + 1):
        try:
            with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
                body = response.read(MAX_BYTES + 1)
                ctype = str(response.headers.get("Content-Type", ""))
            break
        except urllib.error.HTTPError as exc:
            if exc.code not in {429, 503} or attempt == RETRIES:
                raise ClipError(f"download failed: {exc}") from exc
            _sleep(_retry_after(exc.headers.get("Retry-After"), attempt))
        except (OSError, ValueError, http.client.HTTPException) as exc:
            # URLError and timeouts are OSError; InvalidURL is a ValueError-like HTTPException
            raise ClipError(f"download failed: {exc}") from exc
    if len(body) > MAX_BYTES:
        raise ClipError(f"larger than {MAX_BYTES // 1_000_000} MB; not a knowledge source")
    return body, ctype.split(";", 1)[0].strip().lower()


def _retry_after(header: str | None, attempt: int) -> float:
    """Seconds to wait: the server's `Retry-After` (seconds form) if sane, else backoff."""
    if header and header.strip().isdigit():
        return min(float(header.strip()), MAX_WAIT)
    return min(BACKOFF * float(2**attempt), MAX_WAIT)


def ytdlp_info(url: str, flat: bool) -> dict[str, Any]:
    """Metadata (and caption track URLs) from yt-dlp, without downloading any media."""
    try:
        import yt_dlp
    except ImportError as exc:
        raise ClipError(_missing("yt-dlp")) from exc
    options: dict[str, object] = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "noplaylist": not flat,
    }
    if flat:
        options["extract_flat"] = "in_playlist"
    try:
        with yt_dlp.YoutubeDL(options) as ydl:
            info = ydl.extract_info(url, download=False)
    except Exception as exc:  # yt-dlp raises many error types; each is one failed link
        raise ClipError(f"video site refused or failed: {exc}") from exc
    if not isinstance(info, dict):
        raise ClipError("video site returned no metadata")
    return info


def _missing(package: str) -> str:
    return f'{package} is not installed; run: pip install -e ".[capture]"'


# --- converters ----------------------------------------------------------------------------


def _front(meta: dict[str, Any]) -> str:
    lines = [f"{k}: {json.dumps(v, ensure_ascii=False)}" for k, v in meta.items() if v]
    return "---\n" + "\n".join(lines) + "\n---\n"


def page_markdown(url: str, body: bytes, ctype: str) -> tuple[str, str]:
    """(title, markdown) of an HTML page, a PDF or plain text."""
    if ctype == "application/pdf" or body[:5] == b"%PDF-":
        return _pdf_markdown(url, body)
    if ctype.startswith("text/") and "html" not in ctype:
        text = body.decode("utf-8", errors="replace")
        title = next((ln[2:].strip() for ln in text.split("\n") if ln.startswith("# ")), "")
        return title or _name_from_url(url), text
    try:
        import trafilatura
    except ImportError as exc:
        raise ClipError(_missing("trafilatura")) from exc
    html = body.decode("utf-8", errors="replace")
    content = trafilatura.extract(
        html,
        url=url,
        output_format="markdown",
        include_links=True,
        include_tables=True,
        include_comments=False,  # a page's comment thread is not the source (ingest 1 found an ad)
    )
    if not content or not content.strip():
        raise ClipError("no readable main content (JavaScript-only page or paywall?)")
    meta = trafilatura.extract_metadata(html, default_url=url)
    title = (getattr(meta, "title", None) or "").strip() or _name_from_url(url)
    header = {
        "title": title,
        "url": url,
        "author": getattr(meta, "author", None),
        "published": getattr(meta, "date", None),
        "site": getattr(meta, "sitename", None),
        "kind": "page",
    }
    return title, f"{_front(header)}\n# {title}\n\n{content.strip()}\n"


def _pdf_markdown(url: str, body: bytes) -> tuple[str, str]:
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise ClipError(_missing("pypdf")) from exc
    # pypdf logs a warning per odd font (a 54 KB wall for six arXiv papers); the text is fine.
    logging.getLogger("pypdf").setLevel(logging.ERROR)
    try:
        reader = PdfReader(io.BytesIO(body))
        pages = [(page.extract_text() or "").strip() for page in reader.pages]
        title = str(reader.metadata.get("/Title") or "").strip() if reader.metadata else ""
    except Exception as exc:  # malformed PDFs raise assorted errors
        raise ClipError(f"unreadable PDF: {exc}") from exc
    if not any(pages):
        raise ClipError("the PDF has no text layer (scanned?); OCR is out of scope")
    # Rejoin words split at a line end ("ho-\nmogeneous"), so they can be quoted; a hyphen
    # followed by an upper-case letter or a digit is kept (it is likely a real one).
    pages = [_LINE_HYPHEN.sub(r"\1\2", text) for text in pages]
    first_line = next((ln.strip() for ln in pages[0].split("\n") if ln.strip()), "")
    if not title and 8 <= len(first_line) <= 150:
        title = first_line  # papers often carry no /Title; their first line is the title
    title = title or _name_from_url(url)
    parts = [f"## Page {i}\n\n{text}" for i, text in enumerate(pages, start=1) if text]
    header = {"title": title, "url": url, "kind": "pdf", "pages": len(pages)}
    return title, f"{_front(header)}\n# {title}\n\n" + "\n\n".join(parts) + "\n"


_LINE_HYPHEN = re.compile(r"(\w)-\n([a-zà-öø-ÿ])")  # continuation starts lower-case


def _name_from_url(url: str) -> str:
    parts = urlsplit(url)
    tail = [s for s in parts.path.split("/") if s]
    return tail[-1] if tail else _host(parts.netloc)


def _pick_track(info: dict[str, Any], langs: list[str]) -> tuple[str, str, str] | None:
    """(url, ext, kind) of the best caption track: manual before automatic, then language.

    Machine-translated tracks (`tlang=` in the URL) are never used: a translation is not
    what was said, and YouTube rate-limits them (E5 root cause: 429 on every request).
    """
    order = [str(info.get("language") or ""), *langs]
    for kind, key in (("manual", "subtitles"), ("automatic", "automatic_captions")):
        tracks: dict[str, Any] = info.get(key) or {}
        for lang in [lang for lang in order if lang]:
            candidates = [
                t
                for code, ts in tracks.items()
                if _lang_matches(code, lang)
                for t in ts
                if isinstance(t, dict) and "tlang=" not in str(t.get("url", ""))
            ]
            for ext in ("json3", "vtt"):
                for track in candidates:
                    if track.get("ext") == ext and track.get("url"):
                        return str(track["url"]), ext, kind
    return None


def _lang_matches(code: str, lang: str) -> bool:
    """Same primary language: `en` ~ `en-US` ~ `en-orig`; `pt` ~ `pt-BR`."""
    return code.lower().split("-", 1)[0] == lang.lower().split("-", 1)[0]


def _stamp(seconds: float) -> str:
    total = int(seconds)
    hours, rest = divmod(total, 3600)
    return (
        f"[{hours}:{rest // 60:02d}:{rest % 60:02d}]"
        if hours
        else f"[{rest // 60:02d}:{rest % 60:02d}]"
    )


def _paragraphs(cues: Iterable[tuple[float, str]], every: float = 60.0) -> str:
    """Join caption cues into paragraphs of about `every` seconds, each led by `[mm:ss]`."""
    out: list[str] = []
    current: list[str] = []
    start = -every
    last = ""
    for seconds, text in cues:
        text = " ".join(text.split())
        if not text or text == last:  # auto captions repeat rolling lines
            continue
        last = text
        if seconds - start >= every and current:
            out.append(" ".join(current))
            current = []
        if not current:
            start = seconds
            current.append(_stamp(seconds))
        current.append(text)
    if current:
        out.append(" ".join(current))
    return "\n\n".join(out)


def _json3_cues(body: bytes) -> list[tuple[float, str]]:
    data = json.loads(body.decode("utf-8"))
    return [
        (event.get("tStartMs", 0) / 1000, "".join(seg.get("utf8", "") for seg in event["segs"]))
        for event in data.get("events", [])
        if event.get("segs")
    ]


_VTT_TIME = re.compile(r"(\d+):(\d{2}):(\d{2})[.,]\d{3}\s+-->|(\d{2}):(\d{2})[.,]\d{3}\s+-->")
_VTT_TAG = re.compile(r"<[^>]+>")


def _vtt_cues(body: bytes) -> list[tuple[float, str]]:
    """Cues of a WebVTT track. YouTube's automatic VTT is "rolling": each cue repeats the
    previous line and adds one, so only lines not in the previous cue are kept (review F6)."""
    cues: list[tuple[float, str]] = []
    previous: list[str] = []
    for block in body.decode("utf-8", errors="replace").replace("\r\n", "\n").split("\n\n"):
        lines = block.strip().split("\n")
        for i, line in enumerate(lines):
            match = _VTT_TIME.match(line)
            if match:
                h, m, s = (
                    (match.group(1), match.group(2), match.group(3))
                    if match.group(1)
                    else ("0", match.group(4), match.group(5))
                )
                current = [" ".join(_VTT_TAG.sub("", t).split()) for t in lines[i + 1 :]]
                current = [t for t in current if t]
                fresh = [t for t in current if t not in previous]
                previous = current
                cues.append((int(h) * 3600 + int(m) * 60 + int(s), " ".join(fresh)))
                break
    return cues


def ytdlp_fetch(url: str) -> bytes:
    """Fetch a caption track through yt-dlp's client (its headers and cookie handling), the
    same kind of client that obtained the track URL; video sites expect it."""
    try:
        import yt_dlp
    except ImportError as exc:
        raise ClipError(_missing("yt-dlp")) from exc
    try:
        with yt_dlp.YoutubeDL({"quiet": True, "no_warnings": True}) as ydl:
            body: bytes = ydl.urlopen(url).read()
    except Exception as exc:  # network and extractor errors: one failed link
        raise ClipError(f"caption download failed: {exc}") from exc
    return body


def video_markdown(
    url: str, info: dict[str, Any], langs: list[str], fetch_caption: CaptionFetch
) -> tuple[str, str, str]:
    """(title, markdown, detail) of one video: metadata, description and transcript."""
    title = str(info.get("title") or _name_from_url(url)).strip()
    track = _pick_track(info, langs)
    transcript, detail = "", "no captions available: metadata and description only"
    if track is not None:
        track_url, ext, kind = track
        body = fetch_caption(track_url)
        try:
            cues = _json3_cues(body) if ext == "json3" else _vtt_cues(body)
        except (ValueError, KeyError, TypeError, AttributeError):
            cues = []  # an empty or malformed track (review F2): keep the metadata
        transcript = _paragraphs(cues)
        detail = f"{kind} captions" if transcript else "captions unreadable: metadata only"
    upload = str(info.get("upload_date") or "")
    header = {
        "title": title,
        "url": url,
        "author": info.get("uploader") or info.get("channel"),
        "published": f"{upload[:4]}-{upload[4:6]}-{upload[6:]}" if len(upload) == 8 else None,
        "duration_seconds": info.get("duration"),
        "language": info.get("language"),
        "captions": detail,
        "kind": "video",
    }
    parts = [f"{_front(header)}\n# {title}\n"]
    if info.get("description"):
        parts.append(f"## Description\n\n{str(info['description']).strip()}\n")
    parts.append(f"## Transcript\n\n{transcript or '_No transcript available._'}\n")
    return title, "\n".join(parts), detail


# --- orchestration -------------------------------------------------------------------------


def content_digest(text: str) -> str:
    """sha256 of the captured content without its header (which holds the url and dates)."""
    body = text.split("\n---\n", 1)[1] if text.startswith("---\n") and "\n---\n" in text else text
    return hashlib.sha256(" ".join(body.split()).encode("utf-8")).hexdigest()


def known(vault: Vault) -> tuple[dict[str, str], dict[str, str]]:
    """(canonical url -> source id, content digest -> source id) of every stored source."""
    by_url: dict[str, str] = {}
    by_hash: dict[str, str] = {}
    for sid, meta in source_metas(vault).items():
        if isinstance(meta.get("url"), str):
            by_url[canonical_url(meta["url"])] = sid
        if isinstance(meta.get("content_sha256"), str):
            by_hash[meta["content_sha256"]] = sid
    return by_url, by_hash


def clip(
    vault: Vault,
    urls: Iterable[str],
    now: datetime,
    *,
    limit: int | None = None,
    langs: list[str] | None = None,
    fetch: Fetch = http_fetch,
    video_info: VideoInfo = ytdlp_info,
    fetch_caption: CaptionFetch = ytdlp_fetch,
) -> list[ClipOutcome]:
    """Capture each link unless the vault already has it; playlists expand to their videos."""
    langs = langs or ["pt", "en"]
    by_url, by_hash = known(vault)
    queue = [u.strip() for u in urls if u.strip()]
    outcomes: list[ClipOutcome] = []
    seen: set[str] = set()
    videos_done = 0
    while queue:
        raw = queue.pop(0)
        try:
            key = canonical_url(raw)  # identity only: never fetched as such (www/https may matter)
        except ValueError as exc:  # e.g. "[" in a list line: one bad link, not the batch
            detail = redact(f"not a valid link: {exc}")
            outcomes.append(ClipOutcome(redact(raw), "failed", "", detail))
            continue
        if key in seen:
            continue
        seen.add(key)
        if key in by_url:
            outcomes.append(ClipOutcome(key, "exists", by_url[key], "already in the vault"))
            continue
        url = key if is_video(key) or is_playlist(key) else fetchable_url(raw)
        try:
            single_video = False
            if is_playlist(url):
                flat = video_info(url, True)
                if flat.get("entries") or flat.get("_type") in {"playlist", "multi_video"}:
                    entries = _playlist_entries(flat, limit)
                    if not entries:
                        raise ClipError("the collection lists no videos (private or empty)")
                    detail = f"playlist: {len(entries)} video(s) queued"
                    outcomes.append(ClipOutcome(key, "expanded", "", detail))
                    queue[0:0] = [e for e in entries if e not in seen]
                    continue
                # The URL looked like a collection, yt-dlp says it is one video
                # (e.g. vimeo.com/ondemand/film): yt-dlp decides, the guess does not.
                single_video = True
            if single_video or is_video(url):
                if videos_done:
                    _sleep(PLAYLIST_PAUSE)  # consecutive caption requests trip rate limits (E5)
                videos_done += 1
                info = video_info(url, False)
                if info.get("entries") or info.get("_type") in {"playlist", "multi_video"}:
                    raise ClipError("a collection, not a video: pass its playlist or channel link")
                title, text, detail = video_markdown(url, info, langs, fetch_caption)
                kind = "video"
            else:
                body, ctype = fetch(full_text_url(url))
                title, text = page_markdown(url, body, ctype)
                kind = "pdf" if ctype == "application/pdf" or body[:5] == b"%PDF-" else "page"
                detail = kind
            # Without a transcript, a video's text is only title + description, which two
            # different videos can share (review F5): the link then joins the digest.
            has_body = kind != "video" or detail.endswith(" captions")
            digest = content_digest(text if has_body else f"{key}\n{text}")
            if digest in by_hash:
                detail = "same content already stored under another link"
                outcomes.append(ClipOutcome(key, "exists", by_hash[digest], detail))
                continue
            meta = {"url": url, "kind": kind, "content_sha256": digest}
            sid = capture_text(vault, title, text, now, meta)
        except (ClipError, VaultError) as exc:
            outcomes.append(ClipOutcome(redact(key), "failed", "", redact(str(exc))))
            continue
        except Exception as exc:  # third-party parsers raise anything: one link, not the batch
            detail = f"unexpected {type(exc).__name__}: {exc}"
            outcomes.append(ClipOutcome(redact(key), "failed", "", redact(detail)))
            continue
        by_url[key] = sid
        by_hash[digest] = sid
        outcomes.append(ClipOutcome(key, "captured", sid, detail))
    return outcomes


def _playlist_entries(info: dict[str, Any], limit: int | None) -> list[str]:
    entries = [e for e in info.get("entries") or [] if isinstance(e, dict)]
    links = []
    for entry in entries[: limit or COLLECTION_CAP]:
        link = entry.get("url") or entry.get("webpage_url") or entry.get("id")
        if link:
            links.append(
                canonical_url(
                    str(link) if "/" in str(link) else f"https://youtube.com/watch?v={link}"
                )
            )
    return links
