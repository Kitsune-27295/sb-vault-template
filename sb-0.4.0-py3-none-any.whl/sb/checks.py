"""Lint checks: pure functions from vault state to findings (ADR-007). Checks never write."""

from __future__ import annotations

import json
import re
import unicodedata
from collections import defaultdict
from collections.abc import Iterable
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Literal

from sb.logbook import index_text
from sb.pages import (
    LoadError,
    Page,
    data_uris,
    link_key,
    link_targets,
    link_values,
    load_all,
    mask_code,
)
from sb.sources import frozen_ids, inbox_ids, source_text, verify_hash
from sb.vault import Vault, VaultError, is_safe_name, read_text, read_text_or_none, secret_lines

TYPES = frozenset({"source", "concept", "entity", "analysis", "decision", "journal", "context"})
STATUSES = frozenset({"proposed", "accepted", "superseded", "rejected"})
# Zones whose pages must carry the ADR-006 frontmatter.
TYPED_ZONES = frozenset({"wiki", "memory", "context"})
LINKED_ZONES = TYPED_ZONES | {"notes"}
# Zones whose names share the wikilink namespace and so must be unique (ADR-006).
NAMED_ZONES = LINKED_ZONES | {"sources"}
UNTYPED_FILES = frozenset({"memory/hot.md", "memory/lessons.md"})

# Budgets, each with its provenance (see docs/decisions.md ADR-005/007).
HOT_MAX_LINES = 60  # practitioner budget for always-loaded working memory (B2 refs)
MEMORY_MAX_BYTES = 10_000  # practitioner per-file budget (B2 refs)
AGENTS_MAX_LINES = 200  # code.claude.com/docs/en/memory: "under 200 lines"
SKILL_MAX_LINES = 500  # agentskills.io: "Keep your main SKILL.md under 500 lines"
INLINE_DATA_MAX = 20_000  # characters of inline data: payload a page may carry before IMG001

# Characters a reader cannot see but a model reads: zero-width, bidirectional controls, invisible
# operators, the BOM inside text and the Unicode tag block ("Rules File Backdoor"). The joiner
# U+200D is left out because emoji sequences need it.
_HIDDEN_RANGES = (
    (0x200B, 0x200C),
    (0x200E, 0x200F),
    (0x202A, 0x202E),
    (0x2060, 0x2064),
    (0x2066, 0x2069),
    (0xFEFF, 0xFEFF),
    (0xE0000, 0xE007F),
)
HIDDEN = re.compile("[" + "".join(f"{chr(a)}-{chr(b)}" for a, b in _HIDDEN_RANGES) + "]")

# *"quoted"* marks a literal quote from a cited source (ASCII or typographic quotes).
# Closes only on `"*`, so inner quotes and *emphasis* stay inside; may span lines (italics wrap).
_QUOTE = re.compile(r"\*[\"“](.{1,1000}?)[\"”]\*", re.DOTALL)
_TIMESTAMP = re.compile(r"\[\d{1,2}:\d{2}(?::\d{2})?\]")  # [mm:ss] / [h:mm:ss]
_EMPHASIS = re.compile(r"[*_]+")  # markdown emphasis markers, stripped before comparing quotes
_TYPOGRAPHY = str.maketrans(  # curly quotes and non-breaking space compare as plain ASCII
    {chr(0x2018): "'", chr(0x2019): "'", chr(0x201C): '"', chr(0x201D): '"', chr(0xA0): " "}
)
_LOG_ENTRY = re.compile(r"## \[(\d{4}-\d{2}-\d{2})\] [a-z][a-z-]* \| .+")
PENDING_MARK = "[PENDING VALIDATION]"

Severity = Literal["error", "warn"]


@dataclass(frozen=True)
class Finding:
    check: str
    severity: Severity
    path: str
    line: int
    message: str

    def __str__(self) -> str:
        return f"{self.path}:{self.line}: {self.severity} {self.check} {self.message}"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def errors(findings: Iterable[Finding]) -> list[Finding]:
    return [f for f in findings if f.severity == "error"]


# --- structure -------------------------------------------------------------------------


def load_findings(errs: Iterable[LoadError]) -> list[Finding]:
    return [Finding("FM001", "error", e.rel, 1, e.message) for e in errs]


def duplicate_names(pages: Iterable[Page]) -> list[Finding]:
    groups: dict[str, list[Page]] = defaultdict(list)
    for page in pages:
        if page.zone in NAMED_ZONES:
            groups[link_key(page.name)].append(page)
    return [
        Finding(
            "NAM002",
            "error",
            p.rel,
            1,
            f"page name also used by {', '.join(o.rel for o in same if o is not p)}",
        )
        for same in groups.values()
        if len(same) > 1
        for p in same
    ]


def check_pages(targets: Iterable[Page], names: set[str], source_ids: set[str]) -> list[Finding]:
    """Names, frontmatter, source ids and wikilinks of `targets`."""
    out: list[Finding] = []
    folded_ids = {link_key(s) for s in source_ids}
    for page in targets:
        if page.zone == "sources":
            continue  # frozen sources are data: their frontmatter is the author's, not ours
        if not is_safe_name(page.path.name):
            out.append(
                Finding("NAM001", "error", page.rel, 1, f"unsafe file name {page.path.name!r}")
            )
        if page.zone in TYPED_ZONES and page.rel not in UNTYPED_FILES:
            kind = page.meta.get("type")
            if not (isinstance(kind, str) and kind in TYPES):
                out.append(
                    Finding("FM002", "error", page.rel, 1, f"type {kind!r} not in {sorted(TYPES)}")
                )
            if not str(page.meta.get("description") or "").strip():
                out.append(Finding("FM003", "error", page.rel, 1, "missing description"))
        for sid in page.source_ids():
            if sid not in source_ids:
                out.append(Finding("SRC001", "error", page.rel, 1, f"unknown source id {sid!r}"))
        if page.zone not in LINKED_ZONES:
            continue  # root files are generated or schema
        for target, line in page.links():
            key = link_key(target)
            if key not in names and key not in folded_ids:
                out.append(
                    Finding("LNK001", "error", page.rel, line, f"dead wikilink [[{target}]]")
                )
    return out


# --- provenance (S3) -----------------------------------------------------------------


def _norm_quote(text: str) -> str:
    """Compare words, not typography: NFKC, straight quotes, no markdown emphasis, one space."""
    text = unicodedata.normalize("NFKC", text).translate(_TYPOGRAPHY)
    text = _TIMESTAMP.sub(" ", text)  # transcript paragraph markers from `sb clip`
    return " ".join(_EMPHASIS.sub("", text).split())


def quotes(page: Page) -> list[tuple[str, int]]:
    """(quote, 1-based file line) for every *"…"* literal quote outside code, even if wrapped.

    Matches are found on the code-masked body (same length), but the quote text is taken
    from the original, so a quote that itself contains `inline code` is compared intact.
    """
    masked = mask_code(page.body)
    return [
        (page.body[m.start(1) : m.end(1)], page.body_offset + masked.count("\n", 0, m.start()) + 1)
        for m in _QUOTE.finditer(masked)
    ]


def check_quotes(vault: Vault, targets: Iterable[Page]) -> list[Finding]:
    """QUO001: each literal quote occurs verbatim (NFKC, whitespace-folded) in a cited source."""
    out: list[Finding] = []
    for page in targets:
        if page.zone != "wiki":
            continue  # memory and notes quote informally; only compiled knowledge must be exact
        found = quotes(page)
        if not found:
            continue
        texts = [t for t in (source_text(vault, s) for s in page.source_ids()) if t is not None]
        haystacks = [_norm_quote(t) for t in texts]
        for quote, line in found:
            needle = _norm_quote(quote)
            if not any(needle in h for h in haystacks):
                where = "no readable cited source" if not haystacks else "not in any cited source"
                out.append(Finding("QUO001", "error", page.rel, line, f"quote {where}: {quote!r}"))
    return out


def check_source_integrity(vault: Vault) -> list[Finding]:
    """SRC002: every frozen source still matches the sha256 recorded when it was frozen."""
    out: list[Finding] = []
    for sid in sorted(frozen_ids(vault)):
        rel = f"sources/{sid}.md"
        try:
            ok = verify_hash(vault, sid)
        except VaultError as exc:
            out.append(Finding("SRC002", "error", rel, 1, str(exc)))
            continue
        if not ok:
            out.append(Finding("SRC002", "error", rel, 1, "frozen source was modified (sha256)"))
    return out


# --- memory and supersede chains (S4, S7) ----------------------------------------------


def check_memory(vault: Vault, pages: Iterable[Page]) -> list[Finding]:
    out: list[Finding] = []
    hot = vault.root / "memory" / "hot.md"
    try:
        hot_text = read_text(hot) if hot.is_file() else ""
    except UnicodeDecodeError:
        hot_text = ""  # load_all already reports it as FM001
    if hot_text:
        lines = hot_text.rstrip("\n").count("\n") + 1
        if lines > HOT_MAX_LINES:
            msg = f"hot.md has {lines} lines (budget {HOT_MAX_LINES}); move done items to journal"
            out.append(Finding("MEM001", "error", "memory/hot.md", 1, msg))
    by_key = {link_key(p.name): p for p in pages}
    for page in pages:
        if page.zone not in TYPED_ZONES:
            continue  # frozen sources carry their author's frontmatter, not ours
        status = page.meta.get("status")
        valid = isinstance(status, str) and status in STATUSES
        if page.meta.get("type") == "decision" and not valid:
            msg = f"decision status {status!r} not in {sorted(STATUSES)}"
            out.append(Finding("DEC001", "error", page.rel, 1, msg))
        if status == "superseded":
            targets = link_values(page.meta.get("superseded_by"))
            if not targets:
                msg = "status superseded without superseded_by"
                out.append(Finding("SUP001", "error", page.rel, 1, msg))
            for target in targets:
                if link_key(target) not in by_key:
                    msg = f"superseded_by points to missing page {target!r}"
                    out.append(Finding("SUP001", "error", page.rel, 1, msg))
        for other in link_values(page.meta.get("contradicts")):
            msg = f"declared contradiction with [[{other}]] awaits reconciliation"
            out.append(Finding("CON001", "warn", page.rel, 1, msg))
        if PENDING_MARK in page.body:
            msg = f"{page.body.count(PENDING_MARK)} item(s) {PENDING_MARK}"
            out.append(Finding("CTX001", "warn", page.rel, 1, msg))
    return out


# --- hygiene: orphans, sizes, generated files, log --------------------------------------


def check_orphans(pages: Iterable[Page]) -> list[Finding]:
    """ORP001: a wiki page nothing links to (index.md does not count: it links everything)."""
    all_pages = list(pages)
    inbound: set[str] = set()
    for page in all_pages:
        if page.zone in {"wiki", "notes"}:  # memory/context links do not adopt a page
            inbound.update(
                link_key(t) for t, _ in page.links() if link_key(t) != link_key(page.name)
            )
    return [
        Finding("ORP001", "warn", p.rel, 1, "orphan: no page links here")
        for p in all_pages
        if p.zone == "wiki" and link_key(p.name) not in inbound
    ]


def check_sizes(vault: Vault) -> list[Finding]:
    out: list[Finding] = []
    for zone in ("memory", "context"):
        for path in (vault.root / zone).rglob("*.md"):
            size = path.stat().st_size
            if size > MEMORY_MAX_BYTES:
                msg = f"{size} bytes (budget {MEMORY_MAX_BYTES}); split or consolidate"
                out.append(Finding("SIZ001", "warn", vault.rel(path), 1, msg))
    agents = vault.root / "AGENTS.md"
    if agents.is_file():
        lines = (read_text_or_none(agents) or "").count("\n")
        if lines > AGENTS_MAX_LINES:
            msg = f"{lines} lines (budget {AGENTS_MAX_LINES}); it loads every session"
            out.append(Finding("SIZ002", "warn", "AGENTS.md", 1, msg))
    for skill in (vault.root / ".claude" / "skills").glob("*/SKILL.md"):
        lines = (read_text_or_none(skill) or "").count("\n")
        if lines > SKILL_MAX_LINES:
            msg = f"{lines} lines (budget {SKILL_MAX_LINES}); move detail to references"
            out.append(Finding("SIZ003", "warn", vault.rel(skill), 1, msg))
    return out


def check_index(vault: Vault, pages: Iterable[Page]) -> list[Finding]:
    index = vault.root / "index.md"
    expected = index_text(pages)
    wiki_exists = expected.count("\n- [[") > 0
    if not index.is_file():
        if wiki_exists:
            return [Finding("IDX001", "warn", "index.md", 1, "missing; run `sb index rebuild`")]
        return []
    current = read_text_or_none(index)
    if current is not None and current != expected:
        return [Finding("IDX001", "warn", "index.md", 1, "stale; run `sb index rebuild`")]
    return []


def check_secrets(pages: Iterable[Page]) -> list[Finding]:
    """SEC001: a credential anywhere in a page, frontmatter included (a vault may be pushed).

    An error everywhere the agent or curator can fix it; a warning in a frozen source,
    which is immutable: the curator must rotate the secret and rewrite that history.
    """
    out: list[Finding] = []
    for page in pages:
        severity: Severity = "warn" if page.zone == "sources" else "error"
        for number in secret_lines(read_text(page.path)):
            msg = "looks like a credential; remove it and rotate the secret"
            out.append(Finding("SEC001", severity, page.rel, number, msg))
    return out


def check_inline_data(pages: Iterable[Page]) -> list[Finding]:
    """IMG001: a page that carries a big inline `data:` payload (a pasted image).

    The search index already ignores it, but it makes the file heavy to open, diff and sync.
    Sources are skipped, frozen or still in the inbox: they are captured text, kept as it was.
    """
    out: list[Finding] = []
    for page in pages:
        if page.zone == "sources":
            continue
        matches = data_uris(page.body)
        total = sum(len(m.group("payload")) for m in matches)
        if total >= INLINE_DATA_MAX:
            line = page.body_offset + 1 + page.body.count("\n", 0, matches[0].start())
            msg = f"{total // 1000} KB of inline data: payloads; keep images as files"
            out.append(Finding("IMG001", "warn", page.rel, line, msg))
    return out


def check_hidden_unicode(pages: Iterable[Page]) -> list[Finding]:
    """UNI001: invisible characters in a page, where they can hide an instruction from a reviewer.

    Sources are skipped: captured web text carries zero-width characters by accident, and a frozen
    source is data to the skills, never instructions.
    """
    out: list[Finding] = []
    for page in pages:
        if page.zone == "sources":
            continue
        found = HIDDEN.search(page.body)
        line = page.body_offset + 1 + page.body.count("\n", 0, found.start()) if found else 1
        # str() of a dict would escape the character; the frontmatter is indexed too
        found = found or HIDDEN.search(json.dumps(page.meta, ensure_ascii=False, default=str))
        if found:
            name = unicodedata.name(found.group(), "unnamed character")
            msg = f"invisible character U+{ord(found.group()):04X} ({name}); remove it"
            out.append(Finding("UNI001", "warn", page.rel, line, msg))
    return out


def check_log(vault: Vault) -> list[Finding]:
    """LOG001: entries keep the `## [YYYY-MM-DD] op | title` shape; LOG002: dates never go back."""
    out: list[Finding] = []
    previous = ""
    for path in sorted((vault.root / "log").glob("*.md")):
        rel = vault.rel(path)
        for number, line in enumerate((read_text_or_none(path) or "").split("\n"), start=1):
            if not line.startswith("## "):
                continue
            match = _LOG_ENTRY.fullmatch(line)
            if not match:
                out.append(Finding("LOG001", "error", rel, number, f"malformed log entry {line!r}"))
                continue
            if match.group(1) < previous:
                msg = f"entry dated {match.group(1)} after {previous}"
                out.append(Finding("LOG002", "warn", rel, number, msg))
            previous = max(previous, match.group(1))
    return out


# --- entry point -----------------------------------------------------------------------


def vault_path(vault: Vault, raw: str) -> str:
    """Normalise a user-given path (absolute, `./x`, `x\\y`) to the vault-relative POSIX form."""
    path = Path(raw.replace("\\", "/"))
    full = (path if path.is_absolute() else vault.root / path).resolve()
    if not full.is_file():
        raise VaultError(f"{raw} is not a file in the vault")
    try:
        return vault.rel(full)
    except ValueError as exc:
        raise VaultError(f"{raw} is outside the vault {vault.root}") from exc


def run(vault: Vault, only: Iterable[str] | None = None) -> list[Finding]:
    """All checks. `only` restricts the report to these paths (refused if not in the vault)."""
    pages, errs = load_all(vault)
    known_ids = frozen_ids(vault) | inbox_ids(vault)
    findings = (
        load_findings(errs)
        + duplicate_names(pages)
        + check_pages(pages, link_targets(vault, pages), known_ids)
        + check_quotes(vault, pages)
        + check_source_integrity(vault)
        + check_memory(vault, pages)
        + check_orphans(pages)
        + check_sizes(vault)
        + check_index(vault, pages)
        + check_log(vault)
        + check_secrets(pages)
        + check_inline_data(pages)
        + check_hidden_unicode(pages)
    )
    if only is not None:
        wanted = {vault_path(vault, p) for p in only}
        findings = [f for f in findings if f.path in wanted]
    return sorted(findings, key=lambda f: (f.severity != "error", f.path, f.line, f.check))
