"""Loading markdown pages, wikilinks and link resolution."""

from __future__ import annotations

import re
from collections.abc import Iterable, Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from sb.frontmatter import Doc, FrontmatterError, parse
from sb.vault import BOM, Vault, read_text

# [[Target]], [[Target|Alias]], [[Target\|Alias]] (inside tables), [[Target#Heading]], ![[embed]]
_WIKILINK = re.compile(r"\[\[([^\]|#^\\]+)(?:[#^][^\]|\\]*)?(?:\\?\|[^\]]*)?\]\]")


# An inline `data:` payload (a base64 or percent-encoded image a web clipper pasted): never worth
# reading or searching. It ends at a space, a quote, `<`, `>` or an unbalanced `)`; a balanced
# `( )` group stays inside (percent-encoded SVG uses them). Every alternative starts with a
# different character, so a scan is linear however large the page is.
DATA_URI = re.compile(
    r"(?<!\w)data:[\w.+-]+/[\w.+-]+(?:;[\w=.+-]+)*,"
    r"(?P<payload>(?:[^()\s\"'<>]|\([^()\s\"'<>]*\))*)",
    re.IGNORECASE,
)
MIN_PAYLOAD = 200  # a shorter payload (a tiny icon) is harmless and left in place


def data_uris(text: str) -> list[re.Match[str]]:
    """The inline data: URIs in `text` that are big enough to matter."""
    return [m for m in DATA_URI.finditer(text) if len(m.group("payload")) >= MIN_PAYLOAD]


def strip_data_uris(text: str) -> str:
    """`text` without its inline data: payloads (an image keeps its alt text)."""
    return DATA_URI.sub(
        lambda m: "" if len(m.group("payload")) >= MIN_PAYLOAD else m.group(0), text
    )


_FENCE = re.compile(r"^(```|~~~).*?^\1[^\n]*$", re.MULTILINE | re.DOTALL)
_INLINE_CODE = re.compile(r"`[^`\n]+`")


def mask_code(body: str) -> str:
    """Blank out fenced blocks and inline code; length and newlines are kept, so offsets hold."""

    def blank(match: re.Match[str]) -> str:
        return re.sub(r"[^\n]", " ", match.group(0))

    return _INLINE_CODE.sub(blank, _FENCE.sub(blank, body))


@dataclass(frozen=True)
class Page:
    path: Path
    rel: str
    meta: dict[str, Any]
    body: str
    body_offset: int

    @property
    def name(self) -> str:
        return self.path.stem

    @property
    def title(self) -> str:
        """Frontmatter `title`, else the first `# ` heading, else the file name."""
        if self.meta.get("title"):
            return str(self.meta["title"])
        masked = mask_code(self.body).split("\n")  # a `# comment` inside code is not a heading
        original = self.body.split("\n")
        heading = next(
            (original[i][2:].strip() for i, ln in enumerate(masked) if ln.startswith("# ")), ""
        )
        return heading or self.name

    @property
    def zone(self) -> str:
        return self.rel.split("/", 1)[0]

    def source_ids(self) -> list[str]:
        raw = self.meta.get("sources") or []
        return [str(s) for s in raw] if isinstance(raw, list) else [str(raw)]

    def links(self) -> Iterator[tuple[str, int]]:
        """Yield (target, 1-based file line) for each wikilink in the body, outside code.

        Obsidian does not treat `[[x]]` inside inline code or a fenced block as a link, so
        neither does sb (a page documenting the syntax must not fail LNK001).
        """
        for i, line in enumerate(mask_code(self.body).split("\n")):
            for match in _WIKILINK.finditer(line):
                yield match.group(1).strip(), self.body_offset + i + 1


@dataclass(frozen=True)
class LoadError:
    rel: str
    message: str


def load_page(vault: Vault, path: Path) -> Page:
    """Parse one page. Sources are data: malformed frontmatter there is kept as body."""
    rel = vault.rel(path)
    text = read_text(path)
    try:
        doc = parse(text)
    except FrontmatterError:
        if not rel.startswith("sources/"):
            raise
        doc = Doc({}, text.removeprefix(BOM), 0)
    return Page(path, rel, doc.meta, doc.body, doc.body_offset)


def load_all(vault: Vault) -> tuple[list[Page], list[LoadError]]:
    """Every page that parses, plus one error per page that does not. Never raises on content."""
    pages: list[Page] = []
    errors: list[LoadError] = []
    for path in vault.markdown_files():
        try:
            pages.append(load_page(vault, path))
        except FrontmatterError as exc:
            errors.append(LoadError(vault.rel(path), str(exc)))
        except UnicodeDecodeError:
            errors.append(LoadError(vault.rel(path), "not valid UTF-8; re-save the file as UTF-8"))
    return pages, errors


def load_pages(vault: Vault) -> list[Page]:
    return load_all(vault)[0]


def link_values(value: object) -> list[str]:
    """Page names in a frontmatter link field: `Name`, `"[[Name|alias]]"`, a list of either,
    or the nested list YAML makes of an unquoted `[[Name]]`."""
    if value is None or value == "":
        return []
    if isinstance(value, list):
        return [name for item in value for name in link_values(item)]
    text = str(value).strip()
    match = _WIKILINK.search(text)
    return [match.group(1).strip() if match else text]


def link_key(target: str) -> str:
    """Normalise a link target the way Obsidian resolves it: case-insensitive, `.md` optional."""
    key = target.strip().casefold()
    return key.removesuffix(".md")


def link_targets(vault: Vault, pages: Iterable[Page]) -> set[str]:
    """Every name a wikilink may resolve to: page stems and any other file (embeds)."""
    names = {link_key(p.name) for p in pages}
    names.update(link_key(f.name) for f in vault.files() if f.suffix.lower() != ".md")
    return names
