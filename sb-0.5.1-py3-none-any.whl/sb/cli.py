"""Command-line surface. Thin: parse, call a module, print. Exit 0 ok, 1 refused/findings."""

from __future__ import annotations

import errno
import io
import json
import shutil
import sqlite3
import sys
from dataclasses import asdict, replace
from datetime import datetime
from pathlib import Path
from typing import Annotated, Any, NoReturn

import typer
import typer.core

from sb import (
    __version__,
    checks,
    evaluate,
    importer,
    ingest,
    logbook,
    memory,
    related,
    review,
    scaffold,
    search,
    sources,
    upgrade,
    vectors,
)
from sb.pages import load_pages
from sb.vault import Vault, VaultError, path_budget_warning, redact, sb_command


def _closed_pipe(exc: OSError) -> bool:
    """The reader of our output went away: a pipe, not a disk (Windows says so in `winerror`)."""
    broken = {109, 232}  # ERROR_BROKEN_PIPE, ERROR_NO_DATA
    return (
        isinstance(exc, BrokenPipeError)
        or exc.errno == errno.EPIPE
        or getattr(exc, "winerror", None) in broken
    )


class _Root(typer.core.TyperGroup):
    """The root group: a disk error half-way through a command is a message, not a traceback.

    Every write is atomic and every command can be run again (ADR-010), so the advice is true.
    """

    def invoke(self, ctx: Any) -> Any:
        try:
            return super().invoke(ctx)
        except OSError as exc:
            if _closed_pipe(exc):
                raise  # `sb search x | head`: click ends that quietly, as before
            _fail(f"{exc}; fix the cause and run the command again")


app = typer.Typer(no_args_is_help=True, add_completion=False, help=__doc__, cls=_Root)
ingest_app = typer.Typer(no_args_is_help=True, help="Ingest transactions.")
index_app = typer.Typer(no_args_is_help=True, help="The generated catalogue and search index.")
memory_app = typer.Typer(no_args_is_help=True, help="Working memory.")
hook_app = typer.Typer(no_args_is_help=True, help="Claude Code hook entry points.")
app.add_typer(ingest_app, name="ingest")
app.add_typer(index_app, name="index")
app.add_typer(memory_app, name="memory")
app.add_typer(hook_app, name="hook")

VaultOpt = Annotated[
    Path | None, typer.Option("--vault", help="Vault root (default: search upward from cwd).")
]
JsonOpt = Annotated[bool, typer.Option("--json", help="Machine-readable output.")]


def _version(show: bool) -> None:
    if show:
        typer.echo(f"sb {__version__}")
        raise typer.Exit()


@app.callback()
def _root(
    version: Annotated[
        bool,
        typer.Option("--version", callback=_version, is_eager=True, help="Show the version."),
    ] = False,
) -> None:
    """Emit UTF-8 even when piped on Windows, where the default is the ANSI code page."""
    for stream in (sys.stdout, sys.stderr):
        if isinstance(stream, io.TextIOWrapper):
            stream.reconfigure(encoding="utf-8")


def _vault(path: Path | None) -> Vault:
    try:
        return Vault.find(path or Path.cwd())
    except VaultError as exc:
        _fail(str(exc))


def _now() -> datetime:
    return datetime.now().astimezone()


def _fail(message: str) -> NoReturn:
    typer.echo(f"error: {message}", err=True)
    raise typer.Exit(1)


def _json(data: Any) -> None:
    typer.echo(json.dumps(data, ensure_ascii=False, indent=2))


def _warn_unreadable(report: search.SyncReport) -> None:
    """Say, on stderr, that some files were skipped and the index may be incomplete."""
    if report.unreadable:
        typer.echo(
            f"warning: {len(report.unreadable)} file(s) could not be read; "
            "results may be incomplete",
            err=True,
        )


@app.command()
def init(path: Annotated[Path, typer.Argument(help="Directory to turn into a vault.")]) -> None:
    """Create a vault skeleton with its skills and hooks (no questions asked)."""
    try:
        vault = Vault.init(path)
    except VaultError as exc:
        _fail(str(exc))
    typer.echo(f"vault created at {vault.root}")
    warning = path_budget_warning(vault.root)
    if warning:
        typer.echo(f"warning: {warning}", err=True)
    typer.echo("next: `git init` there, then `git config core.hooksPath .githooks`;")
    typer.echo("      open Claude Code in the vault and run the onboarding skill.")


@app.command("upgrade")
def upgrade_cmd(
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Show what would change; write nothing.")
    ] = False,
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """Refresh the framework's files in this vault (skills, rules, settings). Never touches data."""
    try:
        changes = upgrade.run(_vault(vault), dry_run=dry_run)
    except VaultError as exc:
        _fail(str(exc))
    if as_json:
        _json([asdict(c) for c in changes])
        return
    shown = [c for c in changes if c.action != upgrade.CURRENT]
    for c in shown:
        typer.echo(f"{c.action:<7} {c.path}" + (f"  ({c.detail})" if c.detail else ""))
    if not shown:
        typer.echo("already up to date")
    if dry_run:
        typer.echo("dry run: nothing was written")
    else:
        typer.echo("your notes, sources, memory and log were not touched; review with `git diff`")


@app.command()
def capture(
    file: Annotated[Path, typer.Argument(exists=True, dir_okay=False)],
    url: Annotated[
        str | None, typer.Option("--url", help="The link this file was clipped from.")
    ] = None,
    vault: VaultOpt = None,
) -> None:
    """Give a text/markdown file a source id in sources/inbox/ and print the id."""
    try:
        typer.echo(sources.capture(_vault(vault), file, _now(), url=url))
    except VaultError as exc:
        _fail(str(exc))


@app.command("related")
def related_cmd(
    page: Annotated[str, typer.Argument(help="Page name (or vault path).")],
    limit: Annotated[int, typer.Option("-k", min=1, help="Most items per list.")] = 10,
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """What a page relates to: links in and out, shared sources, similar text and meaning."""
    try:
        data = related.report(_vault(vault), page, limit)
    except VaultError as exc:
        _fail(str(exc))
    if as_json:
        _json(data)
        return
    typer.echo(related.render(data))


@app.command("import")
def import_cmd(
    folder: Annotated[
        Path,
        typer.Argument(
            exists=True, file_okay=False, help="Folder of documents: md, txt, html, pdf."
        ),
    ],
    label: Annotated[
        str | None,
        typer.Option("--label", help="Names this collection (default: the folder name)."),
    ] = None,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Show what would happen; write nothing.")
    ] = False,
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """Mirror a folder into sources/inbox/: new files, changed ones as versions, gone listed."""
    try:
        outcomes = importer.run(_vault(vault), folder, label, _now(), dry_run=dry_run)
    except VaultError as exc:
        _fail(str(exc))
    if as_json:
        _json([asdict(o) for o in outcomes])
    else:
        _echo_import(outcomes, dry_run)
    if any(o.status == "failed" for o in outcomes):
        raise typer.Exit(1)


def _echo_import(outcomes: list[importer.ImportOutcome], dry_run: bool = False) -> None:
    counts: dict[str, int] = {}
    for o in outcomes:
        counts[o.status] = counts.get(o.status, 0) + 1
        if o.status in {"skipped", "unchanged"}:
            continue  # a folder export holds many files that need no line each
        ident = f" {o.source_id}" if o.source_id else ""
        note = f"  ({o.detail})" if o.detail else ""
        typer.echo(f"{o.status:<9}{ident} {o.path}{note}")
        if o.pages:
            typer.echo(f"          cited by: {', '.join(f'[[{n}]]' for n in o.pages)}; update them")
    summary = ", ".join(f"{n} {status}" for status, n in sorted(counts.items()))
    typer.echo(summary or "nothing to import")
    if counts.get("skipped"):
        typer.echo("skipped files are of an unsupported type or too large; --json lists them")
    if dry_run:
        typer.echo("dry run: nothing was written")


@ingest_app.command("plan")
def ingest_plan(source_id: str, vault: VaultOpt = None) -> None:
    """Print (JSON) the source and the wiki pages an ingest of SOURCE_ID may touch."""
    try:
        _json(ingest.plan(_vault(vault), source_id))
    except VaultError as exc:
        _fail(str(exc))


@ingest_app.command("pending")
def ingest_pending(as_json: JsonOpt = False, vault: VaultOpt = None) -> None:
    """List the sources nobody has compiled yet: the inbox, and frozen sources no page cites."""
    try:
        todo = ingest.pending(_vault(vault))
    except VaultError as exc:
        _fail(str(exc))
    if as_json:
        _json([asdict(p) for p in todo])
        return
    for item in todo:
        todo_hint = (
            "" if sources.SOURCE_ID.fullmatch(item.source_id) else "  (no id yet: run `sb capture`)"
        )
        typer.echo(f"{item.status:<7} {item.source_id}  {item.title}{todo_hint}")
    if not todo:
        typer.echo("nothing pending")


@ingest_app.command("skip")
def ingest_skip(
    source_id: str,
    reason: Annotated[str, typer.Option("--reason", help="Why this source is not compiled.")],
    vault: VaultOpt = None,
) -> None:
    """Record that SOURCE_ID is deliberately not compiled, so it stops being pending."""
    try:
        recorded = ingest.skip(_vault(vault), source_id, reason, _now())
    except VaultError as exc:
        _fail(str(exc))
    typer.echo(f"skipped {source_id}" if recorded else f"{source_id} is already skipped")


@ingest_app.command("close")
def ingest_close(
    source_id: str,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Only validate; write nothing.")
    ] = False,
    vault: VaultOpt = None,
) -> None:
    """Validate the pages citing SOURCE_ID, then freeze the source, log and index."""
    try:
        report = ingest.close(_vault(vault), source_id, _now(), dry_run=dry_run)
    except VaultError as exc:
        _fail(str(exc))
    for finding in report.findings:
        typer.echo(str(finding), err=True)
    if dry_run:
        if checks.errors(report.findings):
            _fail(f"dry run: close of {source_id} would be refused")
        typer.echo(
            f"dry run: {source_id} would close ({len(report.pages)} page(s), "
            f"{report.quotes_checked} quote(s) verified); nothing written"
        )
        return
    if not report.ok:
        _fail(f"ingest of {source_id} refused; nothing was written")
    verb = "resumed and closed" if report.resumed else "closed"
    typer.echo(
        f"{verb} {source_id} ({len(report.pages)} page(s), {report.quotes_checked} quote(s) "
        f"verified) sha256={report.sha256[:12]}"
    )


@app.command("search")
def search_cmd(
    text: str,
    limit: Annotated[int, typer.Option("-k", min=1)] = 5,
    page_type: Annotated[
        str | None, typer.Option("--type", help="Only pages with this frontmatter type.")
    ] = None,
    zone: Annotated[
        str | None, typer.Option("--zone", help="Only this zone: wiki, notes, context, ...")
    ] = None,
    explain: Annotated[
        bool, typer.Option("--explain", help="Show the raw bm25 score and the zone weight.")
    ] = False,
    semantic: Annotated[
        bool,
        typer.Option(
            "--semantic", help="Also rank by meaning (the `vector` extra; loads a model, ADR-026)."
        ),
    ] = False,
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """Ranked full-text search; each hit carries a path:line citation."""
    try:
        v = _vault(vault)
        if semantic:
            if explain:
                raise VaultError("--semantic cannot be combined with --explain")
            search.narrow(zone, page_type)  # a bad filter must not cost a model load
            embed = vectors.load_model()
            skipped = vectors.sync(v, embed).unreadable
            hits, report = vectors.hybrid(v, embed, text, limit, zone=zone, page_type=page_type)
            report = replace(report, unreadable=tuple(sorted({*report.unreadable, *skipped})))
        else:
            hits, report = search.query_report(v, text, limit, zone=zone, page_type=page_type)
    except VaultError as exc:
        _fail(str(exc))
    _warn_unreadable(report)
    if as_json:
        extra = set() if explain else {"raw", "weight"}  # `--explain` is how they are asked for
        _json(
            [
                {k: v for k, v in asdict(h).items() if k not in extra} | {"citation": h.citation}
                for h in hits
            ]
        )
        return
    for hit in hits:
        typer.echo(f"{hit.citation}  {hit.title}\n    {hit.snippet}")
        if explain:
            typer.echo(f"    raw={hit.raw:.4g} weight={hit.weight} score={hit.score:.4g}")
    if not hits:
        narrowed = [f"{k}={v}" for k, v in (("zone", zone), ("type", page_type)) if v is not None]
        where = f" ({', '.join(narrowed)})" if narrowed else ""
        hint = "try other words, the English term, or a prefix such as `recupera*`"
        if narrowed:
            hint = "check the filter, or " + hint
        typer.echo(f"no hits for {text!r}{where}: {hint}", err=True)


@index_app.command("vectors")
def index_vectors(vault: VaultOpt = None) -> None:
    """Embed the pages for `--semantic` (the `vector` extra); only changed pages are redone."""
    v = _vault(vault)
    try:
        report = vectors.sync(v, vectors.load_model())
    except VaultError as exc:
        _fail(str(exc))
    _warn_unreadable(report)
    typer.echo(f"embedded {report.changed} page(s) with {vectors.MODEL}")


@index_app.command("rebuild")
def index_rebuild(vault: VaultOpt = None) -> None:
    """Regenerate index.md and .sb/index.sqlite from the files."""
    v = _vault(vault)
    pages = load_pages(v)
    logbook.render_index(v, pages)
    try:
        report = search.rebuild(v)
    except VaultError as exc:
        _fail(str(exc))
    typer.echo(f"index.md regenerated; indexed {report.changed} page(s)")
    _warn_unreadable(report)


@app.command()
def lint(
    path: Annotated[
        list[str] | None, typer.Option("--path", help="Only report on this file (repeatable).")
    ] = None,
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """Run the deterministic checks; exit 1 on any error."""
    try:
        findings = checks.run(_vault(vault), only=path, today=_now().date())
    except VaultError as exc:
        _fail(str(exc))
    if as_json:
        _json([f.to_dict() for f in findings])
    else:
        for finding in findings:
            typer.echo(str(finding))
    if checks.errors(findings):
        raise typer.Exit(1)
    if not as_json:
        typer.echo(f"ok ({len(findings)} warning(s))")


@app.command("clip")
def clip_cmd(
    urls: Annotated[
        list[str] | None, typer.Argument(help="Links: pages, PDFs, videos, playlists.")
    ] = None,
    from_file: Annotated[
        Path | None, typer.Option("--from", help="A text file with one link per line.")
    ] = None,
    limit: Annotated[int | None, typer.Option(min=1, help="At most N videos per playlist.")] = None,
    lang: Annotated[str, typer.Option(help="Caption languages, in order of preference.")] = "pt,en",
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """Capture links into sources/inbox/, skipping any the vault already has (ADR-014)."""
    from sb import clip  # the only networked module: imported by this command alone

    links = list(urls or [])
    if from_file is not None:
        try:
            lines = from_file.read_text(encoding="utf-8").splitlines()
        except (OSError, UnicodeDecodeError) as exc:
            _fail(f"cannot read {from_file}: {exc}")
        links += [ln.strip() for ln in lines if ln.strip() and not ln.lstrip().startswith("#")]
    if not links:
        _fail("give at least one link, or --from FILE")
    langs = [code.strip() for code in lang.split(",") if code.strip()]
    # What is stored keeps the link as given (it is the dedup key); what is printed is masked.
    outcomes = [
        replace(o, url=redact(o.url), detail=redact(o.detail))
        for o in clip.clip(_vault(vault), links, _now(), limit=limit, langs=langs)
    ]
    if as_json:
        _json([asdict(o) for o in outcomes])
    else:
        for o in outcomes:
            ident = f" {o.source_id}" if o.source_id else ""
            typer.echo(f"{o.status:<9}{ident} {o.url}  ({o.detail})")
    if any(o.status == "failed" for o in outcomes):
        raise typer.Exit(1)


@app.command("log")
def log_cmd(
    op: Annotated[str, typer.Argument(help="Operation: query, analysis, wrapup, consolidate…")],
    title: Annotated[str, typer.Argument(help="What it was about, one line.")],
    vault: VaultOpt = None,
) -> None:
    """Append `## [date] OP | TITLE` to the append-only log."""
    try:
        typer.echo(logbook.append(_vault(vault), op, title, _now()))
    except ValueError as exc:
        _fail(str(exc))


@memory_app.command("brief")
def memory_brief(vault: VaultOpt = None) -> None:
    """Working memory, open decisions, inbox and health: what a session starts from."""
    typer.echo(memory.brief(_vault(vault), today=_now().date()), nl=False)


@app.command()
def candidates(as_json: JsonOpt = False, vault: VaultOpt = None) -> None:
    """Consolidation leads (possible duplicates, stale links, contradictions) to judge."""
    leads = review.candidates(_vault(vault))
    if as_json:
        _json(leads)
        return
    for lead in leads:
        typer.echo(f"{lead['kind']:<14} {' <-> '.join(lead['pages'])}  ({lead['reason']})")
    typer.echo(f"{len(leads)} lead(s)")


@app.command("eval")
def eval_cmd(
    queries: Annotated[Path, typer.Option(help="Golden queries YAML.")] = Path("eval/queries.yaml"),
    record: Annotated[
        bool, typer.Option("--record", help=f"Append this run to {evaluate.RUNS}.")
    ] = False,
    compare: Annotated[
        bool,
        typer.Option("--baseline", help="Compare with the last recorded run of these queries."),
    ] = False,
    semantic: Annotated[
        bool, typer.Option("--semantic", help="Measure the hybrid search (the `vector` extra).")
    ] = False,
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """Measure retrieval (recall, MRR, hit rate, NDCG, p95 latency); report the ADR-003 trigger."""
    v = _vault(vault)
    try:
        golden = evaluate.load_queries(v.root / queries)  # before the model: refuse cheaply
        embed = vectors.load_model() if semantic and golden else None
        if embed is not None:
            vectors.sync(v, embed)
        report = evaluate.run(v, golden, semantic=embed)
        previous = evaluate.baseline(v, report) if compare and report.queries else None
        if record and report.queries:
            evaluate.record(v, report, _now())
    except VaultError as exc:
        _fail(str(exc))
    data: dict[str, Any] = asdict(report) | {"trigger_hybrid": report.trigger_hybrid}
    if compare:
        data["baseline"] = previous
    if as_json:
        _json(data)
        return
    if not report.queries:
        typer.echo(f"no queries in {queries} yet; add `- query: ...` / `expect: [Page]` items")
        return
    k = evaluate.K
    typer.echo(
        f"queries={report.queries} recall@{k}={report.recall_at_k:.2f} mrr={report.mrr:.2f} "
        f"hit@{k}={report.hit_rate:.2f} ndcg@{k}={report.ndcg_at_k:.2f} p95={report.p95_ms:.1f}ms"
    )
    for kind, row in report.by_kind.items():
        typer.echo(
            f"  kind {kind}: queries={row['queries']:.0f} recall@{k}={row['recall_at_k']:.2f}"
        )
    for miss in report.misses:
        typer.echo(f"  miss: {miss['query']!r} missing {miss['missing']}")
    if compare:
        _echo_baseline(previous)
    if report.trigger_hybrid:
        typer.echo(f"recall below {evaluate.RECALL_TRIGGER}: evaluate hybrid retrieval (ADR-003)")


def _echo_baseline(previous: dict[str, Any] | None) -> None:
    if previous is None:
        typer.echo("no comparable baseline: record a run of these queries with --record")
        return
    changes = " ".join(
        f"{name}={previous[name]:+.3f}"
        for name in ("recall_at_k", "mrr", "hit_rate", "ndcg_at_k", "p95_ms")
        if name in previous
    )
    mode = "hybrid" if previous["semantic"] else "lexical"
    typer.echo(f"baseline {previous['at']} ({mode} run): {changes}")
    for kind, change in previous.get("kinds", {}).items():
        if change < -1e-9:
            typer.echo(f"  kind {kind}: recall fell by {-change:.2f}")
    if previous["regressed"]:
        typer.echo("regression: a quality metric fell against the baseline")


@app.command()
def doctor(vault: VaultOpt = None) -> None:
    """Check the environment: Python, SQLite FTS5 with accent folding, the vault."""
    problems = 0
    typer.echo(
        f"sb {__version__} on Python {sys.version.split()[0]}, SQLite {sqlite3.sqlite_version}"
    )
    try:
        conn = sqlite3.connect(":memory:")
        conn.execute(
            "CREATE VIRTUAL TABLE t USING fts5(x, tokenize='unicode61 remove_diacritics 2')"
        )
        conn.close()
        typer.echo("ok   FTS5 with accent folding")
    except sqlite3.OperationalError as exc:
        problems += 1
        typer.echo(f"FAIL FTS5 unavailable ({exc}); search cannot work")
    try:
        found = Vault.find(vault or Path.cwd())
        typer.echo(f"ok   vault at {found.root}")
        warning = path_budget_warning(found.root)
        if warning:
            typer.echo(f"warn {warning}")
        _doctor_index(found)
        _doctor_framework(found)
        for rel in (".claude/settings.local.json", ".githooks/pre-commit"):
            current = sb_command() in _hook_commands(found.root / rel)
            label = "ok  " if current else "warn"
            hint = "" if current else " (missing or from another machine: run `sb hook install`)"
            typer.echo(f"{label} {rel}{hint}")
        if "hooks" in _json_or_empty(found.root / ".claude" / "settings.json"):
            typer.echo(
                "warn .claude/settings.json holds hooks (pre-ADR-011): run `sb hook install`"
            )
        on_path = shutil.which("sb") is not None
        typer.echo(f"{'ok  ' if on_path else 'warn'} `sb` on PATH (skills call `sb` directly)")
    except VaultError as exc:
        typer.echo(f"info {exc}")
    if problems:
        raise typer.Exit(1)


def _doctor_index(vault: Vault) -> None:
    state = search.health(vault)
    if state.status == "ok":
        typer.echo(f"ok   search index ({state.pages} page(s) as of the last search)")
    elif state.status == "absent":
        typer.echo("ok   search index: not built yet (the first search builds it)")
    elif state.status == "busy":
        typer.echo("ok   search index: in use by another program right now")
    elif state.status == "recipe":
        typer.echo("ok   search index: built by another recipe; the next search rebuilds it")
    else:
        typer.echo(
            f"warn search index {state.detail}; the next search rebuilds it, "
            "or run `sb index rebuild`"
        )


def _doctor_framework(vault: Vault) -> None:
    """Warn when the vault's skills and rules differ from what this `sb` ships (a dry run)."""
    created = str(_json_or_empty(vault.state / "config.json").get("created_with", ""))
    last = scaffold.recorded_version(vault.state / scaffold.MANIFEST)
    newer = [v for v in (last, created) if scaffold.is_newer(v)]
    if newer:
        typer.echo(
            f"warn this vault was made by a newer sb ({newer[0]}); update sb, do not upgrade"
        )
        return  # `sb upgrade` would put older files over newer ones
    try:
        drift = [
            c
            for c in upgrade.run(vault, dry_run=True)
            if c.action in {"create", "update", "append"}
        ]
    except VaultError as exc:
        typer.echo(f"warn framework files could not be checked: {exc}")
        return
    if drift:
        typer.echo(
            f"warn {len(drift)} framework file(s) differ from this sb: "
            "see `sb upgrade --dry-run`, then run `sb upgrade`"
        )


def _json_or_empty(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _hook_commands(path: Path) -> str:
    """The hook command text of a generated file: parsed JSON commands, or the script."""
    if path.suffix == ".json":
        events = _json_or_empty(path).get("hooks")
        commands = [
            str(h.get("command", ""))
            for event in (events.values() if isinstance(events, dict) else [])
            for group in (event if isinstance(event, list) else [])
            for h in ((group.get("hooks") if isinstance(group, dict) else None) or [])
            if isinstance(h, dict)
        ]
        return "\n".join(commands)
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return ""


@hook_app.command("session-start")
def hook_session_start(vault: VaultOpt = None) -> None:
    """SessionStart hook: print the brief (Claude Code adds stdout to the context)."""
    try:
        found = Vault.find(vault or Path.cwd())
    except VaultError:
        return  # not in a vault: stay silent
    typer.echo(memory.brief(found, today=_now().date()), nl=False)
    if shutil.which("sb") is None:  # skills say `sb`; tell the agent how to reach it here
        typer.echo(f"\nNote: `sb` is not on PATH in this environment; run it as: {sb_command()}")


@hook_app.command("install")
def hook_install(vault: VaultOpt = None) -> None:
    """(Re)write this machine's Claude Code hooks and git pre-commit (once per clone)."""
    v = _vault(vault)
    try:
        written = v.install_hooks()
    except VaultError as exc:
        _fail(str(exc))
    for rel in written:
        typer.echo(f"updated {rel}")
    typer.echo("enable the pre-commit hook once per clone: git config core.hooksPath .githooks")
    typer.echo("if .githooks/ was committed before (pre-ADR-011): git rm -r --cached .githooks")


@hook_app.command("post-edit")
def hook_post_edit(vault: VaultOpt = None) -> None:
    """PostToolUse hook: lint the edited file; exit 2 shows its errors to Claude."""
    try:
        payload = json.loads(sys.stdin.buffer.read().decode("utf-8") or "{}")
    except (json.JSONDecodeError, UnicodeDecodeError):
        return
    raw = (payload.get("tool_input") or {}).get("file_path")
    if not raw or not str(raw).endswith(".md"):
        return
    edited = Path(raw)
    try:
        found = Vault.find(vault or edited.parent)
        rel = found.rel(edited.resolve())
    except (VaultError, ValueError):
        return  # outside any vault
    if rel.startswith("wiki/"):
        logbook.render_index(found, load_pages(found))  # keep the generated catalogue current
    try:
        errs = checks.errors(checks.run(found, only=[rel]))
    except VaultError:
        return  # the edited file is gone (moved or deleted since): nothing to check
    if errs:
        for finding in errs:
            typer.echo(str(finding), err=True)
        raise typer.Exit(2)
