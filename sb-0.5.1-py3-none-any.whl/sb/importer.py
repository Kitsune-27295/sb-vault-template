"""Offline import of a folder of exported documents into the inbox (ADR-029).

`sb import <folder>` mirrors a folder (a space exported as HTML or markdown, the output of a bucket
sync, a directory of PDFs and texts) into `sources/inbox/`, one source per file. It can be run
again and again: a file whose content did not change writes nothing, a file that changed becomes a
new source that `supersedes` the old one (a frozen source never changes), and a file that
disappeared from the folder is reported and left alone, because a source is evidence.

The state is the sidecars that already exist: `origin` (label and path in the folder) and
`content_sha256`. No network, no database.
"""

from __future__ import annotations

import os
import unicodedata
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Literal

from sb import extract, ingest, logbook
from sb.pages import load_pages
from sb.sources import capture_text, normalize, source_metas
from sb.vault import Vault, VaultError, secret_lines, slugify

MAX_BYTES = 25_000_000  # the same ceiling as `sb clip`: a knowledge source, not a dataset
TEXT_SUFFIXES = frozenset({".md", ".markdown", ".txt"})
HTML_SUFFIXES = frozenset({".html", ".htm"})
PDF_SUFFIXES = frozenset({".pdf"})

Status = Literal["captured", "updated", "unchanged", "exists", "gone", "skipped", "failed"]


@dataclass(frozen=True)
class ImportOutcome:
    path: str  # where the file is in the folder
    status: Status
    source_id: str = ""
    detail: str = ""
    pages: tuple[str, ...] = ()  # `updated`: the wiki pages that cite the version it replaces


def _files(folder: Path) -> list[tuple[str, Path]]:
    """(path relative to the folder, absolute path) of every file, sorted; links and dot-names
    are not followed. A folder that cannot be listed refuses the whole import, before any write."""
    out: list[tuple[str, Path]] = []
    pending = [("", folder)]
    while pending:
        prefix, current = pending.pop()
        try:
            with os.scandir(current) as listing:
                for entry in listing:
                    if entry.name.startswith(".") or entry.is_symlink():
                        continue
                    rel = unicodedata.normalize("NFC", f"{prefix}{entry.name}")
                    if entry.is_dir(follow_symlinks=False):
                        if not entry.is_junction():
                            pending.append((f"{rel}/", Path(entry.path)))
                    elif entry.is_file(follow_symlinks=False):
                        out.append((rel, Path(entry.path)))
        except OSError as exc:
            raise VaultError(f"cannot list {current}: {exc.strerror or exc}") from exc
    return sorted(out)


def _read(rel: str, path: Path) -> tuple[str, str]:
    """(title, markdown) of one file, normalised; `VaultError` when it cannot be imported.

    This is also where a credential is refused, so a dry run reports it exactly as the real run.
    """
    body = path.read_bytes()
    suffix = path.suffix.lower()
    if suffix in TEXT_SUFFIXES:
        try:
            text = normalize(body.decode("utf-8"))
        except UnicodeDecodeError as exc:
            raise VaultError("not valid UTF-8; re-save the file as UTF-8") from exc
        title = next((ln[2:].strip() for ln in text.split("\n") if ln.startswith("# ")), "")
    else:
        ctype = "application/pdf" if suffix in PDF_SUFFIXES else "text/html"
        title, text = extract.page_markdown(f"file:///{rel}", body, ctype)
        text = normalize(text)
    found = secret_lines(text)
    if found:
        raise VaultError(f"line {found[0]} looks like a credential; remove it first")
    return title or path.stem, text


def _latest_by_origin(metas: dict[str, dict[str, Any]]) -> dict[str, tuple[str, dict[str, Any]]]:
    """The newest source of each origin: the one no other source `supersedes`."""
    superseded = {m["supersedes"] for m in metas.values() if isinstance(m.get("supersedes"), str)}
    latest: dict[str, tuple[str, dict[str, Any]]] = {}
    for sid, meta in sorted(metas.items()):
        origin = meta.get("origin")
        if isinstance(origin, str) and sid not in superseded:
            latest[origin] = (sid, meta)
    return latest


def _label(folder: Path, label: str | None) -> str:
    raw = (label or folder.name).strip()
    name = slugify(raw)
    if name == "untitled" and raw.casefold() != "untitled":
        raise VaultError(
            f"{raw!r} has no letters or digits to name the collection; give one with --label"
        )
    return name


def run(
    vault: Vault, folder: Path, label: str | None, now: datetime, dry_run: bool = False
) -> list[ImportOutcome]:
    """Mirror `folder` into the inbox; one outcome per file, then one per file that went away.

    Everything is validated before anything is written. A file that cannot be imported (a
    credential in it, bad UTF-8, a PDF with no text, a file another program holds open) is a
    `failed` outcome and the rest go on. A dry run reaches the same outcomes and writes nothing.
    """
    folder = folder.resolve()
    if not folder.is_dir():
        raise VaultError(f"{folder} is not a folder")
    root = vault.root.resolve()
    if folder == root or folder.is_relative_to(root) or root.is_relative_to(folder):
        raise VaultError("import a folder that is neither inside the vault nor holding it")
    label = _label(folder, label)
    files = _files(folder)

    metas = source_metas(vault)
    latest = _latest_by_origin(metas)
    owner = {
        m["content_sha256"]: (sid, m.get("origin"))
        for sid, m in sorted(metas.items())
        if isinstance(m.get("content_sha256"), str)
    }
    pages = None  # loaded only if some file turns out to replace a source
    outcomes: list[ImportOutcome] = []
    seen: set[str] = set()
    for rel, path in files:
        origin = f"{label}/{rel}"
        seen.add(origin)
        suffix = path.suffix.lower()
        if suffix not in TEXT_SUFFIXES | HTML_SUFFIXES | PDF_SUFFIXES:
            outcomes.append(
                ImportOutcome(rel, "skipped", detail=f"unsupported type {suffix or '-'}")
            )
            continue
        try:
            if path.stat().st_size > MAX_BYTES:
                detail = f"larger than {MAX_BYTES // 1_000_000} MB; not a knowledge source"
                outcomes.append(ImportOutcome(rel, "skipped", detail=detail))
                continue
            title, text = _read(rel, path)
        except (VaultError, extract.ExtractError) as exc:
            outcomes.append(ImportOutcome(rel, "failed", detail=str(exc)))
            continue
        except OSError as exc:
            outcomes.append(
                ImportOutcome(rel, "failed", detail=f"cannot read: {exc.strerror or exc}")
            )
            continue
        except Exception as exc:  # a converter can fail in ways of its own; the rest go on
            outcomes.append(ImportOutcome(rel, "failed", detail=f"unreadable: {exc}"))
            continue
        digest = extract.content_digest(text)
        previous = latest.get(origin)
        meta: dict[str, Any] = {"origin": origin, "kind": "import", "content_sha256": digest}
        status: Status = "captured"
        replaced: tuple[str, ...] = ()
        if previous is not None:
            if previous[1].get("content_sha256") == digest:
                outcomes.append(ImportOutcome(rel, "unchanged", previous[0]))
                continue
            status, meta["supersedes"] = (
                "updated",
                previous[0],
            )  # even if it now equals another file
            if pages is None:
                pages = load_pages(vault)
            replaced = tuple(p.name for p in ingest.citing_pages(pages, previous[0]))
        else:
            holder = owner.get(digest)
            if holder is not None and holder[1] != origin:
                detail = "same content already stored under another path"
                outcomes.append(ImportOutcome(rel, "exists", holder[0], detail))
                continue
        sid = ""
        if not dry_run:
            try:
                sid = capture_text(vault, title, text, now, meta)
            except VaultError as exc:
                outcomes.append(ImportOutcome(rel, "failed", detail=str(exc)))
                continue
        outcomes.append(ImportOutcome(rel, status, sid, pages=replaced))
        owner[digest] = (
            sid,
            origin,
        )  # a second copy in this run is `exists`, a second edit updates
        latest[origin] = (sid, meta)

    prefix = f"{label}/"
    outcomes += [
        ImportOutcome(origin.removeprefix(prefix), "gone", sid, "no longer in the folder")
        for origin, (sid, _) in sorted(latest.items())
        if origin.startswith(prefix) and origin not in seen
    ]
    new = sum(o.status == "captured" for o in outcomes)
    changed = sum(o.status == "updated" for o in outcomes)
    if (new or changed) and not dry_run:
        logbook.append(vault, "import", f"{label} — {new} new, {changed} updated", now)
    return outcomes
