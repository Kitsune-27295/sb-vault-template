"""YAML frontmatter parsing and serialisation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import yaml

from sb.vault import BOM

_FENCE = "---"


class FrontmatterError(ValueError):
    """Frontmatter is present but malformed."""


@dataclass
class Doc:
    meta: dict[str, Any] = field(default_factory=dict)
    body: str = ""
    body_offset: int = 0  # 0-based line index where the body starts


def parse(text: str) -> Doc:
    lines = text.removeprefix(BOM).split("\n")
    if not lines or lines[0].strip() != _FENCE:
        return Doc({}, text, 0)
    for end in range(1, len(lines)):
        if lines[end].strip() == _FENCE:
            raw = "\n".join(lines[1:end])
            try:
                meta = yaml.safe_load(raw) if raw.strip() else {}
            except (
                yaml.YAMLError,
                ValueError,
            ) as exc:  # ValueError: an impossible date, 2026-13-40
                raise FrontmatterError(f"invalid YAML frontmatter: {exc}") from exc
            if not isinstance(meta, dict):
                raise FrontmatterError("frontmatter must be a mapping")
            return Doc(meta, "\n".join(lines[end + 1 :]), end + 1)
    raise FrontmatterError("frontmatter opened with '---' but never closed")


def dump(doc: Doc) -> str:
    meta = yaml.safe_dump(doc.meta, sort_keys=False, allow_unicode=True).rstrip("\n")
    return f"{_FENCE}\n{meta}\n{_FENCE}\n{doc.body}"
