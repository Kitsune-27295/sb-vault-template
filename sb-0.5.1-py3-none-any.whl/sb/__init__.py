"""sb: local-first LLM Wiki with operational memory."""

__version__ = "0.5.1"
