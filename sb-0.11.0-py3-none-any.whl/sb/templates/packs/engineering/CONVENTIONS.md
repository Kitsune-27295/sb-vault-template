## Engineering vault

- A way of doing something is a `procedure` page with a review date: `sb new procedure "<title>"`.
- An outage or a near miss is an `incident` page, written within a week: what happened, why, and what changes. It describes systems and decisions, not people.
- A choice that will be argued about again is a `decision` in `memory/decisions/`: context, decision, consequences, alternatives.
- [[Runbook index]] and [[Incident index]] list them; add a line when you add a page.
