---
type: concept
description: Every incident of this vault, newest first, with the change it caused.
---
# Incident index

One line per incident: the date, what broke, and the page that says what changed.

- _none yet_

The procedures they changed are in [[Runbook index]].
