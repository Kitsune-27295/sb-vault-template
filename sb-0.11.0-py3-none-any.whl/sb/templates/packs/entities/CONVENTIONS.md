## People, teams and systems

- One page per entity, named the way people say it: `sb new entity "<name>"`.
- **Summary** is what is true now and is rewritten when it changes; **Timeline** is dated lines, newest last, and is never edited.
- Write what an entity or its work has said or done, with the source. Do not infer anything about private life.
- [[People directory]] and [[Teams and systems]] list the entities by kind.
