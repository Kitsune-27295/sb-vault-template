---
type: concept
description: The people this vault has a page for, with their role.
---
# People directory

One line per person: the name as people say it, the role, the page.

- _none yet_

Teams and systems are in [[Teams and systems]].
