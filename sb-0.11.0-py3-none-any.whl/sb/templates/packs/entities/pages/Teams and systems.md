---
type: concept
description: The teams and systems this vault has a page for, with what each does.
---
# Teams and systems

One line per team or system: the name, what it does, who owns it, the page.

- _none yet_

People are in [[People directory]].
