## Research vault

- One idea per page. A page answers "what is X?" or "what do we know about Y?"; if it answers two, split it.
- A claim carries its source. Cite it in `sources:` and quote it literally; a claim with no source says so.
- A term with a fixed meaning is defined once, in [[Glossary]]. A question the vault cannot answer yet is listed in [[Open questions]] and removed when it is answered.
- Search before you add: extend the page that exists, and create a page only for a new idea.
