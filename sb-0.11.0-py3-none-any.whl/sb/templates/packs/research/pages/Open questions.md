---
type: analysis
description: What this vault cannot answer yet, each with what would settle it.
---
# Open questions

One entry per question, with what would settle it (a source to find, an experiment, a person to ask). Remove an entry when a page answers it, and link that page.

- _none yet_

See also [[Glossary]].
