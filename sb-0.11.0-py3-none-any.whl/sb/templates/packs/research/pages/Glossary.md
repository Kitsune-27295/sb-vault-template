---
type: concept
description: The terms this vault uses with one fixed meaning, and where each is explained.
---
# Glossary

One entry per term: the term, its meaning in this vault, and the page that explains it. Add a term the first time two pages would define it differently.

- _none yet_

See also [[Open questions]].
