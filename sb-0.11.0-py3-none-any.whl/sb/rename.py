"""Rename or move a page and let every link follow, with a journal that can undo it (ADR-039).

The plan is pure: it reads the vault and says which lines change. `apply` writes the journal
first, then moves the file, then rewrites each line, so an interrupted run leaves a journal that
`undo` can read. Only whole lines are recorded (before and after), which is all an exact undo
needs and keeps the journal small.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from sb import logbook, related
from sb.checks import TYPES, UNTYPED_FILES
from sb.frontmatter import parse
from sb.pages import (
    LINKED_ZONES,
    Page,
    link_key,
    link_path_key,
    load_pages,
    mask_code,
    name_in_use,
    path_suffixes,
)
from sb.sources import frozen_ids, inbox_ids
from sb.vault import BOM, Vault, VaultError, is_safe_name, secret_lines, write_text_atomic

JOURNAL = "journal"
_LINK = re.compile(r"(!?\[\[)([^\]|#^\\]+)((?:[#^][^\]|\\]*)?(?:\\?\|[^\]]*)?\]\])")
_KEYS = re.compile(r"^(superseded_by|contradicts)\s*:")


@dataclass(frozen=True)
class Edit:
    path: str
    line: int  # 1-based, in the file as it is after the move
    before: str
    after: str


@dataclass(frozen=True)
class Plan:
    source: str
    dest: str
    edits: list[Edit]


def plan(vault: Vault, name: str, dest_arg: str) -> Plan:
    """What `sb mv` would do. Raises `VaultError` for anything it would refuse to do."""
    pages = load_pages(vault)
    ids = frozen_ids(vault) | inbox_ids(vault)
    if link_key(name) in {link_key(i) for i in ids}:
        raise VaultError(f"{name} is a source in sources/: data, never moved or renamed")
    page = related.find(pages, name)
    if page.zone not in LINKED_ZONES:
        raise VaultError(f"{page.rel} is in {page.zone}/, which holds data: only pages are moved")
    if page.rel in UNTYPED_FILES:
        raise VaultError(f"{page.rel} is working memory, loaded by name every session; keep it")
    dest = _destination(page, dest_arg)
    _check_destination(vault, pages, ids, page, dest)
    old_rel_key = page.rel.removesuffix(".md")
    old_suffixes = set(path_suffixes(page.rel))
    new_name = Path(dest).stem
    same_folder = Path(dest).parent == Path(page.rel).parent
    edits: list[Edit] = []
    for other in pages:
        if other.zone not in LINKED_ZONES:
            continue
        shown = dest if other.rel == page.rel else other.rel
        text = (vault.root / other.rel).read_bytes().decode("utf-8")
        edits += _rewrite_page(
            shown,
            text,
            link_key(page.name),
            old_suffixes,
            old_rel_key,
            new_name,
            dest.removesuffix(".md"),
            same_folder,
        )
    if secret_lines("\n".join(f"{e.before}\n{e.after}" for e in edits)):
        raise VaultError(
            "a line that would be rewritten looks like a credential, and the journal is kept in "
            "git: remove it first, then move the page"
        )
    return Plan(page.rel, dest, edits)


def _destination(page: Page, dest_arg: str) -> str:
    text = dest_arg.strip().replace("\\", "/")
    if not text:
        raise VaultError("say where the page goes: a new name, or a path under wiki/, notes/…")
    if text.endswith("/"):
        raise VaultError(f"{dest_arg!r} names a folder: add the page's file name")
    if "/" in text:
        rel = text if text.lower().endswith(".md") else f"{text}.md"
    else:
        folder = str(Path(page.rel).parent).replace("\\", "/")
        rel = f"{folder}/{text.removesuffix('.md') if text.lower().endswith('.md') else text}.md"
    if rel.rsplit("/", 1)[-1].removesuffix(".md").strip(". ") == "":
        raise VaultError(f"{dest_arg!r} has no name for the page")
    return rel


def _check_destination(
    vault: Vault, pages: list[Page], ids: set[str], page: Page, dest: str
) -> None:
    zone = dest.split("/", 1)[0]
    if "/" not in dest or zone not in LINKED_ZONES:
        raise VaultError(
            f"{dest}: not a page zone; pages live in {', '.join(sorted(LINKED_ZONES))}"
        )
    if dest == page.rel:
        raise VaultError(f"{dest} is the same page: nothing to move")
    case_only = dest.casefold() == page.rel.casefold()
    if dest in UNTYPED_FILES:
        raise VaultError(f"{dest} is a working memory file name; pick another")
    file_name = dest.rsplit("/", 1)[-1]
    if not is_safe_name(file_name) or ".." in dest.split("/"):
        raise VaultError(f"unsafe file name {file_name!r} (not allowed on every system)")
    if (vault.root / dest).exists() and not case_only:
        raise VaultError(f"{dest} already exists")
    if not _inside(vault, dest):
        raise VaultError(f"{dest} would leave the vault (a link or junction on the way)")
    key = link_key(Path(dest).stem)
    clash = name_in_use(pages, ids, key, ignore=page)
    if clash:
        raise VaultError(f"a page or source named {Path(dest).stem!r} already exists: {clash}")
    if zone in {"wiki", "memory", "context"}:
        kind, desc = page.meta.get("type"), str(page.meta.get("description") or "").strip()
        typed = isinstance(kind, str) and kind in TYPES
        if page.zone not in {"wiki", "memory", "context"} and not (typed and desc):
            raise VaultError(f"{page.rel} has no type and description, which {zone}/ requires")


def _inside(vault: Vault, rel: str) -> bool:
    """True when `rel` resolves under the vault: no link or junction takes it somewhere else."""
    top = vault.root.resolve()
    probe = vault.root / rel
    while not probe.exists() and probe != vault.root:
        probe = probe.parent
    return probe.resolve().is_relative_to(top)


def _new_target(target: str, old_rel: str, new_name: str, new_rel: str, same_folder: bool) -> str:
    lead = target[: len(target) - len(target.lstrip())]
    trail = target[len(target.rstrip()) :]
    core = target.strip()
    has_md = core.lower().endswith(".md")
    if "/" not in core.replace("\\", "/"):
        new = new_name
    elif same_folder:
        folder = core.replace("\\", "/").rsplit("/", 1)[0]
        new = f"{folder}/{new_name}"
    else:
        new = new_rel
    return f"{lead}{new}{'.md' if has_md else ''}{trail}"


def _rewrite_page(
    rel: str,
    text: str,
    old_key: str,
    old_suffixes: set[str],
    old_rel: str,
    new_name: str,
    new_rel: str,
    same_folder: bool,
) -> list[Edit]:
    masked = mask_code(text).split("\n")
    lines = text.split("\n")
    try:
        frontier = parse(text.removeprefix(BOM)).body_offset
    except Exception:  # an unparsable page is lint's business; its links are still rewritten
        frontier = 0
    edits: list[Edit] = []
    in_keyed_list = False
    for index, (line, masked_line) in enumerate(zip(lines, masked, strict=True)):
        replaced = line
        for match in reversed(list(_LINK.finditer(masked_line))):
            target = line[match.start(2) : match.end(2)]
            core = target.strip()
            if link_key(core) != old_key:
                continue
            if "/" in core.replace("\\", "/") and link_path_key(core) not in old_suffixes:
                continue  # a path that names a different page that happens to share the name
            new = _new_target(target, old_rel, new_name, new_rel, same_folder)
            replaced = replaced[: match.start(2)] + new + replaced[match.end(2) :]
        if index < frontier:
            replaced, in_keyed_list = _frontmatter_scalar(
                replaced, in_keyed_list, old_key, new_name
            )
        if replaced != line:
            edits.append(Edit(rel, index + 1, line, replaced))
    return edits


def _frontmatter_scalar(line: str, in_list: bool, old_key: str, new_name: str) -> tuple[str, bool]:
    """`superseded_by: Name`, `contradicts: [A, Name]` and `- Name` under it hold page names with
    no brackets. An item is rewritten only when the whole item is the old name."""
    key = _KEYS.match(line)
    item = in_list and line.lstrip().startswith("- ")
    if key is None and not item:
        return line, in_list and line.startswith((" ", "-"))
    head, sep, value = line.partition(":") if key else ("", "", line)
    if "[[" in value:
        return line, True  # wikilink forms are the link rewrite's

    def one(match: re.Match[str]) -> str:
        parts = re.fullmatch(r"(\s*(?:-\s+)?)([\'\"]?)(.*?)([\'\"]?)(\s*(?:#.*)?)", match.group(0))
        if parts is None or link_key(parts[3]) != old_key:
            return match.group(0)
        return f"{parts[1]}{parts[2]}{new_name}{parts[4]}{parts[5]}"

    return head + sep + re.sub(r"[^,\[\]]+", one, value), True


def apply(vault: Vault, plan_: Plan, now: datetime) -> Path:
    """Journal, move, rewrite, log, index. Any failure says how to put things back."""
    stamp, counter = f"{now:%Y%m%dT%H%M%S}", 0
    journal = vault.state / JOURNAL / f"{stamp}-{counter:02d}-mv.json"
    while journal.exists():  # two moves in one second keep both journals, in order
        counter += 1
        journal = vault.state / JOURNAL / f"{stamp}-{counter:02d}-mv.json"
    record: dict[str, Any] = {
        "from": plan_.source,
        "to": plan_.dest,
        "at": now.isoformat(timespec="seconds"),
        "state": "pending",
        "edits": [
            {"path": e.path, "line": e.line, "before": e.before, "after": e.after}
            for e in plan_.edits
        ],
    }
    try:
        write_text_atomic(journal, json.dumps(record, ensure_ascii=False, indent=2) + "\n")
    except OSError as exc:
        raise VaultError(f"cannot write the journal ({exc}); nothing was moved") from exc
    try:
        target = vault.root / plan_.dest
        target.parent.mkdir(parents=True, exist_ok=True)
        (vault.root / plan_.source).replace(target)
        _write_lines(vault, plan_.edits, forward=True)
        logbook.append(vault, "mv", f"{plan_.source} -> {plan_.dest}", now)
        logbook.render_index(vault, load_pages(vault))
        record["state"] = "applied"
        write_text_atomic(journal, json.dumps(record, ensure_ascii=False, indent=2) + "\n")
    except (OSError, VaultError, IndexError, UnicodeDecodeError) as exc:
        raise VaultError(
            f"the move was interrupted ({exc}); run `sb mv --undo` to put everything back"
        ) from exc
    return journal


def _write_lines(vault: Vault, edits: list[Edit], forward: bool) -> None:
    by_path: dict[str, list[Edit]] = {}
    for edit in edits:
        by_path.setdefault(edit.path, []).append(edit)
    for rel, items in by_path.items():
        path = vault.root / rel
        lines = path.read_bytes().decode("utf-8").split("\n")
        for e in items:
            old, new = (e.before, e.after) if forward else (e.after, e.before)
            if e.line <= len(lines) and lines[e.line - 1] == old:
                lines[e.line - 1] = new
        write_text_atomic(path, "\n".join(lines))


def _require_page_path(vault: Vault, rel: str) -> None:
    parts = rel.replace("\\", "/").split("/")
    if rel.startswith(("/", "\\")) or ".." in parts or parts[0] not in LINKED_ZONES or ":" in rel:
        raise VaultError(f"the journal names {rel!r}, which is not a page path of this vault")
    if not _inside(vault, rel):
        raise VaultError(f"the journal names {rel!r}, which leaves the vault")


def undo(vault: Vault, now: datetime) -> Plan:
    """Put back the newest move that is not undone; refuse, writing nothing, if a line moved on."""
    folder = vault.state / JOURNAL
    journals = sorted(folder.glob("*-mv.json")) if folder.is_dir() else []
    for path in reversed(journals):
        data = json.loads(path.read_text(encoding="utf-8"))
        if data.get("state") in {"pending", "applied"}:
            break
    else:
        raise VaultError("nothing to undo: no move is recorded as applied")
    source, dest = str(data["from"]), str(data["to"])
    for rel in (source, dest, *(str(e["path"]) for e in data["edits"])):
        _require_page_path(vault, rel)
    moved = (vault.root / dest).is_file()  # an interrupted run may not have moved the file yet
    if moved and (vault.root / source).exists():
        raise VaultError(f"{source} exists again; undoing would overwrite it")
    if not moved and not (vault.root / source).is_file():
        raise VaultError(f"neither {source} nor {dest} is there; the move cannot be undone")

    def where(rel: str) -> str:
        return rel if moved or rel != dest else source

    edits = [Edit(where(e["path"]), int(e["line"]), e["before"], e["after"]) for e in data["edits"]]
    for e in edits:  # check everything first: one line that moved on refuses the whole undo
        target = vault.root / e.path
        if not target.is_file():
            raise VaultError(f"{e.path} is gone; the move cannot be undone safely")
        lines = target.read_bytes().decode("utf-8").split("\n")
        current = lines[e.line - 1] if e.line <= len(lines) else None
        if current not in (e.after, e.before):
            raise VaultError(
                f"{e.path}:{e.line} was edited since the move; put that line back by hand, "
                "then run `sb mv --undo` again"
            )
    _write_lines(vault, edits, forward=False)
    if moved:
        (vault.root / source).parent.mkdir(parents=True, exist_ok=True)
        (vault.root / dest).replace(vault.root / source)
    data["state"] = "undone"
    write_text_atomic(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    logbook.append(vault, "mv", f"undo {source} -> {dest}", now)
    logbook.render_index(vault, load_pages(vault))
    return Plan(dest, source, edits)
