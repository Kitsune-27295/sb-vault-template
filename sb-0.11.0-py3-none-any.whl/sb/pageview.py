"""What an agent needs to know about one page before it opens the file (ADR-038).

One call instead of four: the page's own header, where it sits in the link graph, how old it is,
which sources it draws on (and whether a newer version replaced one), which pages draw on the
same sources, and what `sb lint` says about it. Read-only, no model, nothing stored.
"""

from __future__ import annotations

from datetime import date
from typing import Any

from sb import checks, graph, related, search
from sb.pages import Page, as_date, link_key, load_pages
from sb.sources import frozen_ids, inbox_ids, source_metas
from sb.vault import Vault

LISTED = 5  # inbound pages and shared-source pages named; the count is always the true one
_SHOWN_ABOVE = ("type", "description")  # not repeated in the frontmatter block


def view(vault: Vault, name: str, today: date) -> dict[str, Any]:
    pages = [p for p in load_pages(vault) if p.zone != "sources"]
    page = related.find(pages, name)
    built = graph.build(vault)
    node = next((n for n in built.nodes if n.path == page.rel), None)
    members = {n.path for n in built.nodes}  # counted as the graph counts them
    inbound = [
        (src, line)
        for src, line in search.inbound(vault, link_key(page.name))
        if src != page.rel and src in members
    ]
    path_of = {link_key(n.name): n.path for n in built.nodes}
    links_to: list[dict[str, Any]] = []
    dead: list[dict[str, Any]] = []
    for target, line in page.links():
        key = link_key(target)
        if key in path_of and path_of[key] != page.rel:
            links_to.append({"path": path_of[key], "line": line})
        elif key in built.dead:
            dead.append({"target": key, "line": line})
    cited = page.source_ids()
    frozen, inbox = frozen_ids(vault), inbox_ids(vault)
    replaced_by = {
        str(meta["supersedes"]): sid
        for sid, meta in sorted(source_metas(vault).items())
        if isinstance(meta.get("supersedes"), str)
    }
    sources = [
        {
            "id": sid,
            "status": "frozen" if sid in frozen else "inbox" if sid in inbox else "missing",
            "replaced_by": replaced_by.get(sid),
        }
        for sid in cited
    ]
    shares = [
        {"path": other.rel, "shared": sorted(set(cited) & set(other.source_ids()))}
        for other in pages
        if other is not page and set(cited) & set(other.source_ids())
    ]
    shares.sort(key=lambda s: (-len(s["shared"]), s["path"]))
    return {
        "path": page.rel,
        "title": page.title,
        "type": page.meta.get("type"),
        "description": str(page.meta.get("description") or ""),
        "frontmatter": {k: _plain(v) for k, v in page.meta.items() if k not in _SHOWN_ABOVE},
        "role": node.role if node else None,
        "inbound": {
            "count": len(inbound),
            "pages": [{"path": p, "line": n} for p, n in inbound[:LISTED]],
        },
        "links_to": links_to,
        "dead_links": dead,
        "age": _age(page, today),
        "sources": sources,
        "shares_sources_with": shares[:LISTED],
        "findings": [f.to_dict() for f in checks.run(vault, only=[page.rel], today=today)],
    }


def _plain(value: object) -> object:
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, list):
        return [_plain(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _plain(v) for k, v in value.items()}
    return value


def _age(page: Page, today: date) -> dict[str, Any]:
    updated, review = as_date(page.meta.get("updated")), as_date(page.meta.get("review_by"))
    return {
        "updated": updated.isoformat() if updated else None,
        "days": (today - updated).days if updated else None,
        "review_by": review.isoformat() if review else None,
        "review_overdue": bool(review and review < today),
    }


def render(data: dict[str, Any]) -> str:
    """The view as a few lines: what to read first, and where the trouble is."""
    age = data["age"]
    out = [f"{data['path']}  {data['title']}"]
    counts = f"in {data['inbound']['count']} · out {len(data['links_to'])}"
    dead = f" · dead {len(data['dead_links'])}" if data["dead_links"] else ""
    out.append(f"type {data['type']} · role {data['role']} · {counts}{dead}")
    if data["description"]:
        out.append(f"description: {data['description']}")
    if age["updated"] or age["review_by"]:
        parts = []
        if age["updated"]:
            parts.append(f"updated {age['updated']} ({age['days']} days)")
        if age["review_by"]:
            parts.append(
                f"review by {age['review_by']}" + (" (past)" if age["review_overdue"] else "")
            )
        out.append(" · ".join(parts))
    if data["sources"]:
        cited = []
        for source in data["sources"]:
            text = source["id"] + ("" if source["status"] == "frozen" else f" ({source['status']})")
            if source["replaced_by"]:
                text += f" -> replaced by {source['replaced_by']}"
            cited.append(text)
        out.append("sources: " + " · ".join(cited))
    if data["inbound"]["pages"]:
        places = ", ".join(f"{p['path']}:{p['line']}" for p in data["inbound"]["pages"])
        more = data["inbound"]["count"] - len(data["inbound"]["pages"])
        out.append("linked from: " + places + (f" (+{more})" if more > 0 else ""))
    if data["links_to"]:
        out.append("links to: " + ", ".join(f"{p['path']}:{p['line']}" for p in data["links_to"]))
    out += [f"dead link [[{d['target']}]] at line {d['line']}" for d in data["dead_links"]]
    if data["shares_sources_with"]:
        shared = ", ".join(f"{s['path']} ({len(s['shared'])})" for s in data["shares_sources_with"])
        out.append("same sources as: " + shared)
    out += [
        f"lint {f['severity']} {f['check']} line {f['line']}: {f['message']}"
        for f in data["findings"]
    ]
    return "\n".join(out) + "\n"
