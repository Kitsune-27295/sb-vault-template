"""The link graph of a vault, read from the `links` table of the derived index (ADR-038).

Nothing here parses a page: `search.sync` fills the table from the bodies, and this module only
counts. A page is a node when it lives in a linked zone; a link is dead when no page, source or
file carries its name.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from sb import search
from sb.checks import UNTYPED_FILES
from sb.pages import link_key
from sb.sources import frozen_ids, inbox_ids
from sb.vault import Vault

HUB_MIN = 5  # inbound links from this many distinct pages make a hub
Role = Literal["hub", "connector", "leaf", "orphan"]
Direction = Literal["incoming", "outgoing", "both"]


@dataclass(frozen=True)
class Node:
    path: str
    name: str
    inbound: int  # distinct pages that link here
    outbound: int  # distinct pages (that exist) linked from here
    role: Role


@dataclass(frozen=True)
class Graph:
    nodes: list[Node]
    dead: dict[str, list[tuple[str, int]]]  # target name -> (page, line) of each mention
    links: int

    def orphans(self, direction: Direction = "both") -> list[Node]:
        """Pages nobody links to (`incoming`), that link to nothing (`outgoing`), or both."""
        if direction == "incoming":
            return [n for n in self.nodes if n.inbound == 0]
        if direction == "outgoing":
            return [n for n in self.nodes if n.outbound == 0]
        return [n for n in self.nodes if n.inbound == 0 and n.outbound == 0]

    def hubs(self, count: int) -> list[Node]:
        """The `count` most linked pages (ties by name); a page nobody links to is not one."""
        ranked = sorted((n for n in self.nodes if n.inbound), key=lambda n: (-n.inbound, n.name))
        return ranked[:count]


def _role(inbound: int, outbound: int) -> Role:
    if inbound >= HUB_MIN:
        return "hub"
    if inbound == 0 and outbound == 0:
        return "orphan"
    if inbound and outbound:
        return "connector"
    return "leaf"


def build(vault: Vault) -> Graph:
    pages, edges, files = search.link_rows(vault)
    ids = frozen_ids(vault) | inbox_ids(vault)  # a source is linked by its id, frozen or not
    known = {link_key(_stem(path)) for path in pages} | {link_key(n) for n in (*files, *ids)}
    # working memory (`hot.md`, `lessons.md`) is read whole every session, not navigated
    names = {
        path: link_key(_stem(path))
        for path in pages
        if search.is_linked(path) and path not in UNTYPED_FILES
    }
    inbound: dict[str, set[str]] = {key: set() for key in names.values()}
    outbound: dict[str, set[str]] = {key: set() for key in names.values()}
    dead: dict[str, list[tuple[str, int]]] = {}
    for src, dst, line in edges:
        me = names.get(src)
        if dst not in known:  # lint reports a dead link in `hot.md` too
            dead.setdefault(dst, []).append((src, line))
        elif me is not None and dst != me and dst in inbound:
            inbound[dst].add(me)
            outbound[me].add(dst)
    nodes = [
        Node(
            path,
            _stem(path),
            len(inbound[key]),
            len(outbound[key]),
            _role(len(inbound[key]), len(outbound[key])),
        )
        for path, key in sorted(names.items())
    ]
    return Graph(nodes, {k: sorted(v) for k, v in sorted(dead.items())}, len(edges))


def _stem(path: str) -> str:
    """The file name without its folders and `.md` (a page's name)."""
    return path.rsplit("/", 1)[-1].removesuffix(".md")
