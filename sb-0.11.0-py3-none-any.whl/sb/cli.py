"""Command-line surface. Thin: parse, call a module, print. Exit 0 ok, 1 refused/findings."""

from __future__ import annotations

import errno
import io
import json
import platform
import shutil
import sqlite3
import sys
from collections import Counter
from dataclasses import asdict, replace
from datetime import datetime
from pathlib import Path
from typing import Annotated, Any, NoReturn

import typer
import typer.core

from sb import (
    __version__,
    blueprint,
    checks,
    evaluate,
    graph,
    importer,
    ingest,
    logbook,
    memory,
    pageview,
    related,
    rename,
    review,
    scaffold,
    search,
    sources,
    upgrade,
    vectors,
)
from sb import (
    pack as packs,
)
from sb.pages import load_pages
from sb.vault import (
    Vault,
    VaultError,
    path_budget_warning,
    redact,
    sb_command,
    write_text_atomic,
)


def _closed_pipe(exc: OSError) -> bool:
    """The reader of our output went away: a pipe, not a disk (Windows says so in `winerror`)."""
    broken = {109, 232}  # ERROR_BROKEN_PIPE, ERROR_NO_DATA
    return (
        isinstance(exc, BrokenPipeError)
        or exc.errno == errno.EPIPE
        or getattr(exc, "winerror", None) in broken
    )


class _Root(typer.core.TyperGroup):
    """The root group: a disk error half-way through a command is a message, not a traceback.

    Every write is atomic and every command can be run again (ADR-010), so the advice is true.
    """

    def invoke(self, ctx: Any) -> Any:
        try:
            return super().invoke(ctx)
        except OSError as exc:
            if _closed_pipe(exc):
                raise  # `sb search x | head`: click ends that quietly, as before
            _fail(f"{exc}; fix the cause and run the command again")


app = typer.Typer(no_args_is_help=True, add_completion=False, help=__doc__, cls=_Root)
ingest_app = typer.Typer(no_args_is_help=True, help="Ingest transactions.")
index_app = typer.Typer(no_args_is_help=True, help="The generated catalogue and search index.")
memory_app = typer.Typer(no_args_is_help=True, help="Working memory.")
hook_app = typer.Typer(no_args_is_help=True, help="Claude Code hook entry points.")
HOOK_NOTES = 5  # findings named in the advice a hook gives the model (the rest are counted)
HOOK_NOTE_CHARS = 1_500
app.add_typer(ingest_app, name="ingest")
app.add_typer(index_app, name="index")
app.add_typer(memory_app, name="memory")
app.add_typer(hook_app, name="hook")

VaultOpt = Annotated[
    Path | None, typer.Option("--vault", help="Vault root (default: search upward from cwd).")
]
JsonOpt = Annotated[bool, typer.Option("--json", help="Machine-readable output.")]


def _version(show: bool) -> None:
    if show:
        typer.echo(f"sb {__version__}")
        raise typer.Exit()


@app.callback()
def _root(
    version: Annotated[
        bool,
        typer.Option("--version", callback=_version, is_eager=True, help="Show the version."),
    ] = False,
) -> None:
    """Emit UTF-8 even when piped on Windows, where the default is the ANSI code page."""
    for stream in (sys.stdout, sys.stderr):
        if isinstance(stream, io.TextIOWrapper):
            stream.reconfigure(encoding="utf-8")


def _vault(path: Path | None) -> Vault:
    try:
        found = Vault.find(path or Path.cwd())
        found.require_known_format()
        return found
    except VaultError as exc:
        _fail(str(exc))


def _now() -> datetime:
    return datetime.now().astimezone()


def _fail(message: str) -> NoReturn:
    typer.echo(f"error: {message}", err=True)
    raise typer.Exit(1)


def _json(data: Any) -> None:
    typer.echo(json.dumps(data, ensure_ascii=False, indent=2))


def _warn_unreadable(report: search.SyncReport) -> None:
    """Say, on stderr, that some files were skipped and the index may be incomplete."""
    if report.unreadable:
        typer.echo(
            f"warning: {len(report.unreadable)} file(s) could not be read; "
            "results may be incomplete",
            err=True,
        )


@app.command()
def init(
    path: Annotated[Path, typer.Argument(help="Directory to turn into a vault.")],
    agents: Annotated[
        bool,
        typer.Option("--agents", help="Also install the skills at .agents/skills/ (Antigravity)."),
    ] = False,
    pack: Annotated[
        str | None,
        typer.Option("--pack", help="Start with a pack: research, engineering or entities."),
    ] = None,
) -> None:
    """Create a vault skeleton with its skills and hooks (no questions asked)."""
    try:
        if pack is not None and pack not in packs.names():
            raise VaultError(f"unknown pack {pack!r}; the packs are {', '.join(packs.names())}")
        vault = Vault.init(path, agents=agents)
    except VaultError as exc:
        _fail(str(exc))
    if pack is not None:
        try:
            packs.apply(vault, pack, _now().date())
        except (VaultError, OSError) as exc:
            _fail(
                f"vault created at {vault.root}, but the pack was not applied ({exc}); "
                f"run `sb pack {pack}` inside it"
            )
    typer.echo(f"vault created at {vault.root}")
    warning = path_budget_warning(vault.root)
    if warning:
        typer.echo(f"warning: {warning}", err=True)
    typer.echo("next: `git init` there, then `git config core.hooksPath .githooks`;")
    typer.echo("      open Claude Code in the vault and run the onboarding skill.")


@app.command("upgrade")
def upgrade_cmd(
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Show what would change; write nothing.")
    ] = False,
    agents: Annotated[
        bool,
        typer.Option("--agents", help="Also keep the skills at .agents/skills/ (Antigravity)."),
    ] = False,
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """Refresh the framework's files in this vault (skills, rules, settings). Never touches data."""
    try:
        changes = upgrade.run(_vault(vault), dry_run=dry_run, agents=agents)
    except VaultError as exc:
        _fail(str(exc))
    if as_json:
        _json([asdict(c) for c in changes])
        return
    shown = [c for c in changes if c.action != upgrade.CURRENT]
    for c in shown:
        typer.echo(f"{c.action:<7} {c.path}" + (f"  ({c.detail})" if c.detail else ""))
    if not shown:
        typer.echo("already up to date")
    if dry_run:
        typer.echo("dry run: nothing was written")
    else:
        typer.echo("your notes, sources, memory and log were not touched; review with `git diff`")


@app.command()
def capture(
    file: Annotated[Path, typer.Argument(exists=True, dir_okay=False)],
    url: Annotated[
        str | None, typer.Option("--url", help="The link this file was clipped from.")
    ] = None,
    vault: VaultOpt = None,
) -> None:
    """Give a text/markdown file a source id in sources/inbox/ and print the id."""
    try:
        typer.echo(sources.capture(_vault(vault), file, _now(), url=url))
    except VaultError as exc:
        _fail(str(exc))


@app.command("new")
def new_cmd(
    kind: Annotated[
        str, typer.Argument(help="concept, entity, analysis, procedure, incident or decision.")
    ],
    title: Annotated[str, typer.Argument(help="The page's title; it becomes the file name.")],
    vault: VaultOpt = None,
) -> None:
    """Create a page of a type with its sections, ready to fill (every gap says so)."""
    found = _vault(vault)
    try:
        rel = blueprint.create(found, kind, title, _now().date())
    except VaultError as exc:
        _fail(str(exc))
    typer.echo(rel)


@app.command("pack")
def pack_cmd(
    name: Annotated[str | None, typer.Argument(help="research, engineering or entities.")] = None,
    list_: Annotated[bool, typer.Option("--list", help="List the packs.")] = False,
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """Add a starter pack's conventions and seed pages to this vault (idempotent)."""
    if list_ or name is None:
        listing = [
            {"name": n, "about": packs.describe(n), "pages": packs.seeds(n)} for n in packs.names()
        ]
        if as_json:
            _json(listing)
        else:
            for item in listing:
                typer.echo(f"{item['name']:<12}{item['about']}")
        return
    found = _vault(vault)
    try:
        changed = packs.apply(found, name, _now().date())
    except VaultError as exc:
        _fail(str(exc))
    for rel in changed:
        typer.echo(f"wrote {rel}")
    if not changed:
        typer.echo("already applied; nothing changed")


@app.command("mv")
def mv_cmd(
    source: Annotated[str | None, typer.Argument(help="Page name or vault path.")] = None,
    dest: Annotated[
        str | None,
        typer.Argument(help="New name (same folder) or new path (under wiki/, notes/…)."),
    ] = None,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Show every line that would change; write nothing.")
    ] = False,
    undo: Annotated[
        bool, typer.Option("--undo", help="Put back the newest move recorded in .sb/journal/.")
    ] = False,
    vault: VaultOpt = None,
) -> None:
    """Rename or move a page; every link to it follows. Journalled, so `--undo` puts it back."""
    found = _vault(vault)
    try:
        if undo:
            if source or dest or dry_run:
                raise VaultError("--undo takes no page and no other option")
            done = rename.undo(found, _now())
            typer.echo(f"undone: {done.source} is back as {done.dest}")
            return
        if not source or not dest:
            raise VaultError("give the page and where it goes: sb mv <page> <new name or path>")
        plan = rename.plan(found, source, dest)
        typer.echo(f"{plan.source} -> {plan.dest}")
        for edit in plan.edits:
            typer.echo(
                f"  {edit.path}:{edit.line}  {edit.before.strip()}  ->  {edit.after.strip()}"
            )
        if dry_run:
            typer.echo("dry run: nothing was written")
            return
        rename.apply(found, plan, _now())
        typer.echo(f"moved; {len(plan.edits)} line(s) rewritten; undo with `sb mv --undo`")
    except VaultError as exc:
        _fail(str(exc))


@app.command("page")
def page_cmd(
    name: Annotated[str, typer.Argument(help="Page name (or vault path).")],
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """One page's header: type, role in the graph, age, sources, inbound links and lint."""
    try:
        data = pageview.view(_vault(vault), name, _now().date())
    except VaultError as exc:
        _fail(str(exc))
    if as_json:
        _json(data)
    else:
        typer.echo(pageview.render(data), nl=False)


@app.command("graph")
def graph_cmd(
    orphans: Annotated[
        str | None,
        typer.Option(
            "--orphans",
            help="List pages nobody links to (incoming), that link nowhere (outgoing), or both.",
        ),
    ] = None,
    hubs: Annotated[
        int | None, typer.Option("--hubs", min=1, help="List the N most linked pages.")
    ] = None,
    dead: Annotated[
        bool, typer.Option("--dead", help="List links to nothing, grouped by target.")
    ] = False,
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """The link graph from the index: roles, orphans, hubs and dead links (read-only)."""
    if orphans is not None and orphans not in {"incoming", "outgoing", "both"}:
        _fail("--orphans takes incoming, outgoing or both")
    try:
        built = graph.build(_vault(vault))
    except VaultError as exc:
        _fail(str(exc))
    chosen = orphans is not None or hubs is not None or dead
    sections: dict[str, Any] = {}
    if orphans is not None:
        sections["orphans"] = [asdict(n) for n in built.orphans(orphans)]  # type: ignore[arg-type]
    if hubs is not None:
        sections["hubs"] = [asdict(n) for n in built.hubs(hubs)]
    if dead:
        sections["dead"] = [
            {"target": target, "sources": [{"path": p, "line": n} for p, n in places]}
            for target, places in built.dead.items()
        ]
    if as_json:
        _json(sections if chosen else _graph_summary(built))
        return
    if not chosen:
        summary = _graph_summary(built)
        typer.echo(
            f"{summary['pages']} page(s), {summary['links']} link(s); "
            f"{summary['orphans']} orphan(s), {summary['dead']} dead target(s)"
        )
        for n in built.hubs(5):
            typer.echo(f"hub {n.inbound:>3} in  {n.path}")
        return
    for n in sections.get("orphans", []):
        typer.echo(f"orphan  {n['path']}  (in {n['inbound']}, out {n['outbound']})")
    for n in sections.get("hubs", []):
        typer.echo(f"hub     {n['path']}  (in {n['inbound']}, out {n['outbound']})")
    for item in sections.get("dead", []):
        places = ", ".join(f"{s['path']}:{s['line']}" for s in item["sources"])
        typer.echo(f"dead    [[{item['target']}]]  <- {places}")


def _graph_summary(built: graph.Graph) -> dict[str, Any]:
    return {
        "pages": len(built.nodes),
        "links": built.links,
        "orphans": len(built.orphans("both")),
        "dead": len(built.dead),
        "hubs": [asdict(n) for n in built.hubs(5)],
    }


@app.command("related")
def related_cmd(
    page: Annotated[str, typer.Argument(help="Page name (or vault path).")],
    limit: Annotated[int, typer.Option("-k", min=1, help="Most items per list.")] = 10,
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """What a page relates to: links in and out, shared sources, similar text and meaning."""
    try:
        data = related.report(_vault(vault), page, limit)
    except VaultError as exc:
        _fail(str(exc))
    if as_json:
        _json(data)
        return
    typer.echo(related.render(data))


@app.command("import")
def import_cmd(
    folder: Annotated[
        Path,
        typer.Argument(
            exists=True, file_okay=False, help="Folder of documents: md, txt, html, pdf."
        ),
    ],
    label: Annotated[
        str | None,
        typer.Option("--label", help="Names this collection (default: the folder name)."),
    ] = None,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Show what would happen; write nothing.")
    ] = False,
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """Mirror a folder into sources/inbox/: new files, changed ones as versions, gone listed."""
    try:
        outcomes = importer.run(_vault(vault), folder, label, _now(), dry_run=dry_run)
    except VaultError as exc:
        _fail(str(exc))
    if as_json:
        _json([asdict(o) for o in outcomes])
    else:
        _echo_import(outcomes, dry_run)
    if any(o.status == "failed" for o in outcomes):
        raise typer.Exit(1)


def _echo_import(outcomes: list[importer.ImportOutcome], dry_run: bool = False) -> None:
    counts: dict[str, int] = {}
    for o in outcomes:
        counts[o.status] = counts.get(o.status, 0) + 1
        if o.status in {"skipped", "unchanged"}:
            continue  # a folder export holds many files that need no line each
        ident = f" {o.source_id}" if o.source_id else ""
        note = f"  ({o.detail})" if o.detail else ""
        typer.echo(f"{o.status:<9}{ident} {o.path}{note}")
        if o.pages:
            typer.echo(f"          cited by: {', '.join(f'[[{n}]]' for n in o.pages)}; update them")
    summary = ", ".join(f"{n} {status}" for status, n in sorted(counts.items()))
    typer.echo(summary or "nothing to import")
    if counts.get("skipped"):
        typer.echo("skipped files are of an unsupported type or too large; --json lists them")
    if dry_run:
        typer.echo("dry run: nothing was written")


@ingest_app.command("plan")
def ingest_plan(source_id: str, vault: VaultOpt = None) -> None:
    """Print (JSON) the source and the wiki pages an ingest of SOURCE_ID may touch."""
    try:
        _json(ingest.plan(_vault(vault), source_id))
    except VaultError as exc:
        _fail(str(exc))


@ingest_app.command("pending")
def ingest_pending(as_json: JsonOpt = False, vault: VaultOpt = None) -> None:
    """List the sources nobody has compiled yet: the inbox, and frozen sources no page cites."""
    try:
        todo = ingest.pending(_vault(vault))
    except VaultError as exc:
        _fail(str(exc))
    if as_json:
        _json([asdict(p) for p in todo])
        return
    for item in todo:
        todo_hint = (
            "" if sources.SOURCE_ID.fullmatch(item.source_id) else "  (no id yet: run `sb capture`)"
        )
        typer.echo(f"{item.status:<7} {item.source_id}  {item.title}{todo_hint}")
    if not todo:
        typer.echo("nothing pending")


@ingest_app.command("skip")
def ingest_skip(
    source_id: str,
    reason: Annotated[str, typer.Option("--reason", help="Why this source is not compiled.")],
    vault: VaultOpt = None,
) -> None:
    """Record that SOURCE_ID is deliberately not compiled, so it stops being pending."""
    try:
        recorded = ingest.skip(_vault(vault), source_id, reason, _now())
    except VaultError as exc:
        _fail(str(exc))
    typer.echo(f"skipped {source_id}" if recorded else f"{source_id} is already skipped")


@ingest_app.command("close")
def ingest_close(
    source_id: str,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Only validate; write nothing.")
    ] = False,
    vault: VaultOpt = None,
) -> None:
    """Validate the pages citing SOURCE_ID, then freeze the source, log and index."""
    try:
        report = ingest.close(_vault(vault), source_id, _now(), dry_run=dry_run)
    except VaultError as exc:
        _fail(str(exc))
    for finding in report.findings:
        typer.echo(str(finding), err=True)
    if dry_run:
        if checks.errors(report.findings):
            _fail(f"dry run: close of {source_id} would be refused")
        typer.echo(
            f"dry run: {source_id} would close ({len(report.pages)} page(s), "
            f"{report.quotes_checked} quote(s) verified); nothing written"
        )
        return
    if not report.ok:
        _fail(f"ingest of {source_id} refused; nothing was written")
    verb = "resumed and closed" if report.resumed else "closed"
    typer.echo(
        f"{verb} {source_id} ({len(report.pages)} page(s), {report.quotes_checked} quote(s) "
        f"verified) sha256={report.sha256[:12]}"
    )


@app.command("search")
def search_cmd(
    text: str,
    limit: Annotated[int, typer.Option("-k", min=1)] = 5,
    page_type: Annotated[
        str | None, typer.Option("--type", help="Only pages with this frontmatter type.")
    ] = None,
    zone: Annotated[
        str | None, typer.Option("--zone", help="Only this zone: wiki, notes, context, ...")
    ] = None,
    path: Annotated[
        list[str] | None,
        typer.Option(
            "--path",
            help="Only this file, or the pages under this folder (repeatable: their union).",
        ),
    ] = None,
    explain: Annotated[
        bool, typer.Option("--explain", help="Show the raw bm25 score and the zone weight.")
    ] = False,
    semantic: Annotated[
        bool,
        typer.Option(
            "--semantic", help="Also rank by meaning (the `vector` extra; loads a model, ADR-026)."
        ),
    ] = False,
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """Ranked full-text search; each hit carries a path:line citation."""
    scope = path or []
    try:
        v = _vault(vault)
        if semantic:
            if explain:
                raise VaultError("--semantic cannot be combined with --explain")
            search.narrow(zone, page_type, scope)  # a bad filter must not cost a model load
            embed = vectors.load_model()
            skipped = vectors.sync(v, embed).unreadable
            hits, report = vectors.hybrid(
                v, embed, text, limit, zone=zone, page_type=page_type, paths=scope
            )
            report = replace(report, unreadable=tuple(sorted({*report.unreadable, *skipped})))
        else:
            hits, report = search.query_report(
                v, text, limit, zone=zone, page_type=page_type, paths=scope
            )
    except VaultError as exc:
        _fail(str(exc))
    _warn_unreadable(report)
    if as_json:
        extra = set() if explain else {"raw", "weight", "tier"}  # asked for with `--explain`
        _json(
            [
                {k: v for k, v in asdict(h).items() if k not in extra} | {"citation": h.citation}
                for h in hits
            ]
        )
        return
    for hit in hits:
        typer.echo(f"{hit.citation}  {hit.title}\n    {hit.snippet}")
        if explain:
            typer.echo(
                f"    raw={hit.raw:.4g} weight={hit.weight} score={hit.score:.4g} tier={hit.tier}"
            )
    if not hits:
        narrowed = [f"{k}={v}" for k, v in (("zone", zone), ("type", page_type)) if v is not None]
        narrowed += [f"path={p}" for p in scope]
        where = f" ({', '.join(narrowed)})" if narrowed else ""
        hint = "try other words, the English term, or a prefix such as `recupera*`"
        if narrowed:
            hint = "check the filter, or " + hint
        typer.echo(f"no hits for {text!r}{where}: {hint}", err=True)


@index_app.command("vectors")
def index_vectors(vault: VaultOpt = None) -> None:
    """Embed the pages for `--semantic` (the `vector` extra); only changed pages are redone."""
    v = _vault(vault)
    try:
        report = vectors.sync(v, vectors.load_model())
    except VaultError as exc:
        _fail(str(exc))
    _warn_unreadable(report)
    typer.echo(f"embedded {report.changed} page(s) with {vectors.MODEL}")


@index_app.command("rebuild")
def index_rebuild(vault: VaultOpt = None) -> None:
    """Regenerate index.md and .sb/index.sqlite from the files."""
    v = _vault(vault)
    pages = load_pages(v)
    logbook.render_index(v, pages)
    try:
        report = search.rebuild(v)
    except VaultError as exc:
        _fail(str(exc))
    typer.echo(f"index.md regenerated; indexed {report.changed} page(s)")
    _warn_unreadable(report)


@app.command()
def lint(
    path: Annotated[
        list[str] | None, typer.Option("--path", help="Only report on this file (repeatable).")
    ] = None,
    limit: Annotated[
        int, typer.Option("--limit", min=0, help="Findings printed (0: all); --json is never cut.")
    ] = 100,
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """Run the deterministic checks; exit 1 on any error."""
    try:
        report = checks.run_report(_vault(vault), only=path, today=_now().date())
    except VaultError as exc:
        _fail(str(exc))
    findings = report.findings
    errors = len(checks.errors(findings))
    if as_json:
        _json(
            {
                "findings": [f.to_dict() for f in findings],
                "ran": report.ran,
                "crashed": report.crashed,
                "pages": report.pages,
                "sources": report.sources,
                "errors": errors,
                "warnings": len(findings) - errors,
            }
        )
    else:
        shown = findings if limit == 0 else findings[:limit]
        for finding in shown:
            typer.echo(str(finding))
        if len(shown) < len(findings):
            typer.echo(
                f"... {len(findings) - len(shown)} more ({errors} error(s), "
                f"{len(findings) - errors} warning(s) in total); narrow with --path P, "
                "or print all with --limit 0"
            )
        _echo_checked(report)
    if errors:
        raise typer.Exit(1)
    if not as_json and not report.crashed:
        typer.echo(f"ok ({len(findings)} warning(s))")


def _echo_checked(report: checks.Report) -> None:
    """One line that says what was looked at, so a quiet run can be told from an empty one."""
    typer.echo(
        f"checked {report.pages} page(s), {report.sources} source(s): " + ", ".join(report.ran)
    )
    for family, why in report.crashed.items():
        typer.echo(f"NOT checked: {family} ({why})")


@app.command("clip")
def clip_cmd(
    urls: Annotated[
        list[str] | None, typer.Argument(help="Links: pages, PDFs, videos, playlists.")
    ] = None,
    from_file: Annotated[
        Path | None, typer.Option("--from", help="A text file with one link per line.")
    ] = None,
    limit: Annotated[int | None, typer.Option(min=1, help="At most N videos per playlist.")] = None,
    lang: Annotated[str, typer.Option(help="Caption languages, in order of preference.")] = "pt,en",
    allow_local: Annotated[
        bool,
        typer.Option("--allow-local", help="Fetch localhost and link-local addresses (refused)."),
    ] = False,
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """Capture links into sources/inbox/, skipping any the vault already has (ADR-014)."""
    from sb import clip  # the only networked module: imported by this command alone

    if allow_local:
        clip.ALLOW_LOCAL = True

    links = list(urls or [])
    if from_file is not None:
        try:
            lines = from_file.read_text(encoding="utf-8").splitlines()
        except (OSError, UnicodeDecodeError) as exc:
            _fail(f"cannot read {from_file}: {exc}")
        links += [ln.strip() for ln in lines if ln.strip() and not ln.lstrip().startswith("#")]
    if not links:
        _fail("give at least one link, or --from FILE")
    langs = [code.strip() for code in lang.split(",") if code.strip()]
    # What is stored keeps the link as given (it is the dedup key); what is printed is masked.
    outcomes = [
        replace(o, url=redact(o.url), detail=redact(o.detail))
        for o in clip.clip(_vault(vault), links, _now(), limit=limit, langs=langs)
    ]
    if as_json:
        _json([asdict(o) for o in outcomes])
    else:
        for o in outcomes:
            ident = f" {o.source_id}" if o.source_id else ""
            typer.echo(f"{o.status:<9}{ident} {o.url}  ({o.detail})")
    if any(o.status == "failed" for o in outcomes):
        raise typer.Exit(1)


@app.command("log")
def log_cmd(
    op: Annotated[str, typer.Argument(help="Operation: query, analysis, wrapup, consolidate…")],
    title: Annotated[str, typer.Argument(help="What it was about, one line.")],
    vault: VaultOpt = None,
) -> None:
    """Append `## [date] OP | TITLE` to the append-only log."""
    try:
        typer.echo(logbook.append(_vault(vault), op, title, _now()))
    except ValueError as exc:
        _fail(str(exc))


@memory_app.command("brief")
def memory_brief(vault: VaultOpt = None) -> None:
    """Working memory, open decisions, inbox and health: what a session starts from."""
    typer.echo(memory.brief(_vault(vault), today=_now().date()), nl=False)


@app.command()
def candidates(as_json: JsonOpt = False, vault: VaultOpt = None) -> None:
    """Consolidation leads (possible duplicates, stale links, contradictions) to judge."""
    leads = review.candidates(_vault(vault))
    if as_json:
        _json(leads)
        return
    for lead in leads:
        typer.echo(f"{lead['kind']:<14} {' <-> '.join(lead['pages'])}  ({lead['reason']})")
    typer.echo(f"{len(leads)} lead(s)")


@app.command("eval")
def eval_cmd(
    queries: Annotated[Path, typer.Option(help="Golden queries YAML.")] = Path("eval/queries.yaml"),
    record: Annotated[
        bool, typer.Option("--record", help=f"Append this run to {evaluate.RUNS}.")
    ] = False,
    compare: Annotated[
        bool,
        typer.Option("--baseline", help="Compare with the last recorded run of these queries."),
    ] = False,
    semantic: Annotated[
        bool, typer.Option("--semantic", help="Measure the hybrid search (the `vector` extra).")
    ] = False,
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """Measure retrieval (recall, MRR, hit rate, NDCG, p95 latency); report the ADR-003 trigger."""
    v = _vault(vault)
    try:
        golden = evaluate.load_queries(v.root / queries)  # before the model: refuse cheaply
        embed = vectors.load_model() if semantic and golden else None
        if embed is not None:
            vectors.sync(v, embed)
        report = evaluate.run(v, golden, semantic=embed)
        previous = evaluate.baseline(v, report) if compare and report.queries else None
        if record and report.queries:
            evaluate.record(v, report, _now())
    except VaultError as exc:
        _fail(str(exc))
    data: dict[str, Any] = asdict(report) | {"trigger_hybrid": report.trigger_hybrid}
    if compare:
        data["baseline"] = previous
    if as_json:
        _json(data)
        return
    if not report.queries:
        typer.echo(f"no queries in {queries} yet; add `- query: ...` / `expect: [Page]` items")
        return
    k = evaluate.K
    typer.echo(
        f"queries={report.queries} recall@{k}={report.recall_at_k:.2f} mrr={report.mrr:.2f} "
        f"hit@{k}={report.hit_rate:.2f} ndcg@{k}={report.ndcg_at_k:.2f} p95={report.p95_ms:.1f}ms"
    )
    for kind, row in report.by_kind.items():
        typer.echo(
            f"  kind {kind}: queries={row['queries']:.0f} recall@{k}={row['recall_at_k']:.2f}"
        )
    for miss in report.misses:
        typer.echo(f"  miss: {miss['query']!r} missing {miss['missing']}")
    if compare:
        _echo_baseline(previous)
    if report.trigger_hybrid:
        typer.echo(f"recall below {evaluate.RECALL_TRIGGER}: evaluate hybrid retrieval (ADR-003)")


def _echo_baseline(previous: dict[str, Any] | None) -> None:
    if previous is None:
        typer.echo("no comparable baseline: record a run of these queries with --record")
        return
    changes = " ".join(
        f"{name}={previous[name]:+.3f}"
        for name in ("recall_at_k", "mrr", "hit_rate", "ndcg_at_k", "p95_ms")
        if name in previous
    )
    mode = "hybrid" if previous["semantic"] else "lexical"
    typer.echo(f"baseline {previous['at']} ({mode} run): {changes}")
    for kind, change in previous.get("kinds", {}).items():
        if change < -1e-9:
            typer.echo(f"  kind {kind}: recall fell by {-change:.2f}")
    if previous["regressed"]:
        typer.echo("regression: a quality metric fell against the baseline")


@app.command()
def doctor(
    bundle: Annotated[
        Path | None,
        typer.Option(
            "--bundle", help="Write a diagnostics file with versions and counts, no content."
        ),
    ] = None,
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """Check the environment: Python, SQLite FTS5 with accent folding, the vault."""
    if bundle is not None and as_json:
        _fail("--bundle writes a file and --json prints one: give one of them")
    rows, found = _doctor_rows(vault)
    if bundle is not None:
        try:
            _write_bundle(bundle, rows, found)
        except VaultError as exc:
            _fail(str(exc))
        typer.echo(f"wrote {bundle}")
    elif as_json:
        _json(
            [
                {"status": "info" if status == "head" else status, "message": message}
                for status, message in rows
            ]
        )
    else:
        labels = {"ok": "ok  ", "warn": "warn", "fail": "FAIL", "info": "info"}
        for status, message in rows:
            typer.echo(f"{labels[status]} {message}" if status != "head" else message)
    if any(status == "fail" for status, _ in rows):
        raise typer.Exit(1)


def _doctor_rows(vault: Path | None) -> tuple[list[tuple[str, str]], Vault | None]:
    rows: list[tuple[str, str]] = [
        (
            "head",
            f"sb {__version__} on Python {sys.version.split()[0]}, SQLite {sqlite3.sqlite_version}",
        )
    ]
    try:
        conn = sqlite3.connect(":memory:")
        conn.execute(
            "CREATE VIRTUAL TABLE t USING fts5(x, tokenize='unicode61 remove_diacritics 2')"
        )
        conn.close()
        rows.append(("ok", "FTS5 with accent folding"))
    except sqlite3.OperationalError as exc:
        rows.append(("fail", f"FTS5 unavailable ({exc}); search cannot work"))
    try:
        found = Vault.find(vault or Path.cwd())
    except VaultError as exc:
        rows.append(("info", str(exc)))
        return rows, None
    rows.append(("ok", f"vault at {found.root}"))
    warning = path_budget_warning(found.root)
    if warning:
        rows.append(("warn", warning))
    rows.append(_doctor_index(found))
    rows += [("warn", line) for line in _framework_warnings(found)]
    for rel in (".claude/settings.local.json", ".githooks/pre-commit"):
        current = sb_command() in _hook_commands(found.root / rel)
        hint = "" if current else " (missing or from another machine: run `sb hook install`)"
        rows.append(("ok" if current else "warn", f"{rel}{hint}"))
    if "hooks" in _json_or_empty(found.root / ".claude" / "settings.json"):
        rows.append(
            ("warn", ".claude/settings.json holds hooks (pre-ADR-011): run `sb hook install`")
        )
    on_path = shutil.which("sb") is not None
    rows.append(("ok" if on_path else "warn", "`sb` on PATH (skills call `sb` directly)"))
    return rows, found


def _doctor_index(vault: Vault) -> tuple[str, str]:
    state = search.health(vault)
    if state.status == "ok":
        return "ok", f"search index ({state.pages} page(s) as of the last search)"
    if state.status == "absent":
        return "ok", "search index: not built yet (the first search builds it)"
    if state.status == "busy":
        return "ok", "search index: in use by another program right now"
    if state.status == "recipe":
        return "ok", "search index: built by another recipe; the next search rebuilds it"
    return (
        "warn",
        f"search index {state.detail}; the next search rebuilds it, or run `sb index rebuild`",
    )


def _write_bundle(target: Path, rows: list[tuple[str, str]], found: Vault | None) -> None:
    """What to attach to a bug report: versions, check results and counts. No page name, no
    text, no path of this machine: a bundle is meant to be sent."""
    where = target.resolve()
    if found is not None and where.is_relative_to(found.root.resolve()):
        raise VaultError("write the bundle outside the vault, so it is not committed by accident")
    if where.exists() and not _is_bundle(where):
        raise VaultError(f"{target} exists and is not a diagnostics bundle; pick a new file name")
    private = [str(Path.cwd()), str(Path.home())]
    if found is not None:
        private.insert(0, str(found.root))
    data: dict[str, Any] = {
        "sb": __version__,
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "sqlite": sqlite3.sqlite_version,
        "checks": [{"status": s, "message": redact(_scrub(m, private, found))} for s, m in rows],
    }
    if found is not None:
        report = checks.run_report(found, today=_now().date())
        config = _json_or_empty(found.state / "config.json")
        data["vault"] = {
            "pages": report.pages,
            "sources": report.sources,
            "layout": config.get("version"),
            "created_with": config.get("created_with"),
            "agents_mirror": config.get("agents") is True,
            "families_run": report.ran,
            "families_crashed": sorted(report.crashed),
            "findings": dict(sorted(Counter(f.check for f in report.findings).items())),
        }
    target.parent.mkdir(parents=True, exist_ok=True)
    write_text_atomic(target, json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def _scrub(message: str, private: list[str], found: Vault | None) -> str:
    """The message without this machine's folders, in the plain, the posix and the escaped
    (`\\\\`) spelling an OS error uses; the vault becomes `<vault>`, the rest `<path>`."""
    for index, folder in enumerate(private):
        label = "<vault>" if found is not None and index == 0 else "<path>"
        spellings = {folder, Path(folder).as_posix(), folder.replace("\\", "\\\\")}
        for spelling in sorted(spellings, key=len, reverse=True):
            message = message.replace(spelling, label)
    return message


def _is_bundle(path: Path) -> bool:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    return isinstance(data, dict) and {"sb", "checks"} <= set(data)


@app.command("uninstall")
def uninstall_cmd(
    apply: Annotated[
        bool, typer.Option("--apply", help="Remove the files listed as `remove`.")
    ] = False,
    vault: VaultOpt = None,
) -> None:
    """Show (and with --apply, do) what taking sb's files out of this vault would remove."""
    found = _vault(vault)
    try:
        plan = upgrade.uninstall(found, apply=apply)
    except VaultError as exc:
        _fail(str(exc))
    for change in plan:
        detail = f"  ({change.detail})" if change.detail else ""
        typer.echo(f"{change.action:<7} {change.path}{detail}")
    typer.echo("your notes, sources, memory and log are never touched; `.sb/` stays")
    if not apply:
        typer.echo("dry run: nothing was removed; add --apply to remove the `remove` lines")


def _framework_warnings(vault: Vault) -> list[str]:
    """What is out of step between this vault's skills and rules and the `sb` that runs (a dry
    run): shown by `sb doctor` and at the start of a session."""
    try:
        vault.require_known_format()
    except VaultError as exc:
        return [str(exc)]
    created = str(_json_or_empty(vault.state / "config.json").get("created_with", ""))
    last = scaffold.recorded_version(vault.state / scaffold.MANIFEST)
    newer = [v for v in (last, created) if scaffold.is_newer(v)]
    if newer:  # `sb upgrade` would put older files over newer ones
        return [f"this vault was made by a newer sb ({newer[0]}); update sb, do not upgrade"]
    try:
        drift = [
            c
            for c in upgrade.run(vault, dry_run=True)
            if c.action in {"create", "update", "append"}
        ]
    except VaultError as exc:
        return [f"framework files could not be checked: {exc}"]
    if drift:
        return [
            f"{len(drift)} framework file(s) differ from this sb: "
            "see `sb upgrade --dry-run`, then run `sb upgrade`"
        ]
    return []


def _json_or_empty(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _hook_commands(path: Path) -> str:
    """The hook command text of a generated file: parsed JSON commands, or the script."""
    if path.suffix == ".json":
        events = _json_or_empty(path).get("hooks")
        commands = [
            str(h.get("command", ""))
            for event in (events.values() if isinstance(events, dict) else [])
            for group in (event if isinstance(event, list) else [])
            for h in ((group.get("hooks") if isinstance(group, dict) else None) or [])
            if isinstance(h, dict)
        ]
        return "\n".join(commands)
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return ""


@hook_app.command("session-start")
def hook_session_start(vault: VaultOpt = None) -> None:
    """SessionStart hook: print the brief (Claude Code adds stdout to the context)."""
    try:
        found = Vault.find(vault or Path.cwd())
    except VaultError:
        return  # not in a vault: stay silent
    typer.echo(memory.brief(found, today=_now().date()), nl=False)
    for line in _framework_warnings(found):
        typer.echo(f"\nFramework: {line}")
    if shutil.which("sb") is None:  # skills say `sb`; tell the agent how to reach it here
        typer.echo(f"\nNote: `sb` is not on PATH in this environment; run it as: {sb_command()}")


@hook_app.command("install")
def hook_install(vault: VaultOpt = None) -> None:
    """(Re)write this machine's Claude Code hooks and git pre-commit (once per clone)."""
    v = _vault(vault)
    try:
        written = v.install_hooks()
    except VaultError as exc:
        _fail(str(exc))
    for rel in written:
        typer.echo(f"updated {rel}")
    typer.echo("enable the pre-commit hook once per clone: git config core.hooksPath .githooks")
    typer.echo("if .githooks/ was committed before (pre-ADR-011): git rm -r --cached .githooks")


@hook_app.command("post-edit")
def hook_post_edit(vault: VaultOpt = None) -> None:
    """PostToolUse hook: lint the edited file; exit 2 shows its errors to Claude."""
    try:
        payload = json.loads(sys.stdin.buffer.read().decode("utf-8") or "{}")
    except (json.JSONDecodeError, UnicodeDecodeError):
        return
    if not isinstance(payload, dict):
        return
    raw = (payload.get("tool_input") or {}).get("file_path")
    if not raw or not str(raw).lower().endswith(".md"):
        return
    edited = Path(raw)
    try:
        found = Vault.find(vault or edited.parent)
        found.require_known_format()  # an older sb must not rewrite index.md of a newer vault
        rel = found.rel(edited.resolve())
    except (VaultError, ValueError):
        return  # outside any vault
    if rel.startswith("wiki/"):
        logbook.render_index(found, load_pages(found))  # keep the generated catalogue current
    try:
        findings = checks.run(found, only=[rel], today=_now().date())
    except VaultError:
        return  # the edited file is gone (moved or deleted since): nothing to check
    if checks.errors(findings):  # blocking: Claude Code shows stderr to the model on exit 2
        for finding in findings:
            typer.echo(str(finding), err=True)
        raise typer.Exit(2)
    if findings:  # advice: exit 0 and one JSON object, which the host adds as context
        summary = "; ".join(f"{f.check} line {f.line}: {f.message}" for f in findings[:HOOK_NOTES])
        more = len(findings) - HOOK_NOTES
        note = f"sb lint on {rel}: {summary}" + (f" (and {more} more)" if more > 0 else "")
        context = {"hookEventName": "PostToolUse", "additionalContext": note[:HOOK_NOTE_CHARS]}
        typer.echo(json.dumps({"hookSpecificOutput": context}, ensure_ascii=False))
