"""Starter packs: a conventions block and a few seed pages for a kind of vault (ADR-040).

A pack is data under `templates/packs/<name>/`: `CONVENTIONS.md` (a fragment appended once to the
vault's own conventions) and `pages/*.md` (seed pages, written only where none exists). Applying
one twice changes nothing, and it never overwrites a page the curator has touched.
"""

from __future__ import annotations

from datetime import date

from sb.logbook import render_index
from sb.pages import link_key, load_pages, name_in_use
from sb.scaffold import templates_root
from sb.sources import frozen_ids, inbox_ids
from sb.vault import Vault, VaultError, read_text, write_text_atomic

_HEADER = "# Conventions\n\nThe rules this vault's curator and agent agree on.\n"


def names() -> list[str]:
    root = templates_root() / "packs"
    return sorted(p.name for p in root.iterdir() if p.is_dir())


def _folder(name: str) -> object:
    if name not in names():
        raise VaultError(f"unknown pack {name!r}; the packs are {', '.join(names())}")
    return templates_root() / "packs" / name


def seeds(name: str) -> list[str]:
    """The vault-relative paths the pack's seed pages go to."""
    pages = _folder(name) / "pages"  # type: ignore[operator]
    return sorted(f"wiki/{p.name}" for p in pages.iterdir() if p.name.endswith(".md"))


def describe(name: str) -> str:
    """The first line of the pack's conventions, which says what the pack is for."""
    text = (_folder(name) / "CONVENTIONS.md").read_text(encoding="utf-8")  # type: ignore[operator]
    return next((ln.lstrip("# ").strip() for ln in text.splitlines() if ln.strip()), name)


def apply(vault: Vault, name: str, today: date) -> list[str]:
    """Seed the pages that are missing and add the conventions block once; return what changed.

    A seed whose name another page or a source already carries is left out: names are unique
    (ADR-006), and a page the curator moved or renamed is not made again.
    """
    del today  # packs are static text; the argument keeps `apply` shaped like `blueprint.create`
    folder = _folder(name)
    fragment = (folder / "CONVENTIONS.md").read_text(encoding="utf-8")  # type: ignore[operator]
    path = vault.root / "CONVENTIONS.md"
    try:
        current = read_text(path) if path.is_file() else _HEADER
    except UnicodeDecodeError as exc:
        raise VaultError("CONVENTIONS.md is not UTF-8; re-save it as UTF-8 first") from exc
    pages = load_pages(vault)
    ids = frozen_ids(vault) | inbox_ids(vault)
    writes: list[tuple[str, str]] = []
    for rel in seeds(name):
        target = vault.root / rel
        if target.exists() or name_in_use(pages, ids, link_key(target.stem)):
            continue
        source = (folder / "pages" / target.name).read_text(encoding="utf-8")  # type: ignore[operator]
        writes.append((rel, source))
    marker = f"<!-- pack:{name} -->"
    changed: list[str] = []
    for rel, text in writes:
        write_text_atomic(vault.root / rel, text)
        changed.append(rel)
    if marker not in current:
        write_text_atomic(
            path, current.rstrip("\n") + "\n\n" + marker + "\n" + fragment.strip() + "\n"
        )
        changed.append("CONVENTIONS.md")
    if writes:
        render_index(vault, load_pages(vault))
    return changed
