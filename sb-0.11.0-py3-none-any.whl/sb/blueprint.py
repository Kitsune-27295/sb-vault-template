"""`sb new`: a page of a given type with the sections that type needs (ADR-040).

Deterministic and offline: it writes a skeleton, and every place the author still has to write
something carries `[PENDING VALIDATION]`, which `sb lint` counts (`CTX001`) until it is gone.
Nothing here judges content.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, timedelta

from sb.logbook import render_index
from sb.pages import link_key, load_pages, name_in_use
from sb.sources import frozen_ids, inbox_ids
from sb.vault import Vault, VaultError, is_safe_name, slugify, write_text_atomic

REVIEW_DAYS = 182  # a procedure or incident write-up is checked again in about half a year
_UNSAFE = re.compile(r"[#|^:\[\]%/\\<>\"?*]+")
_PENDING = "[PENDING VALIDATION]"


@dataclass(frozen=True)
class Blueprint:
    folder: str
    sections: tuple[tuple[str, str], ...]  # (heading, what goes under it)
    meta: tuple[tuple[str, str], ...] = ()
    dated: bool = False  # the file name starts with the date, like the other decisions
    review: bool = False  # `updated` today and `review_by` in half a year


_BLUEPRINTS: dict[str, Blueprint] = {
    "concept": Blueprint(
        "wiki",
        (
            ("What it is", "Define it in two or three sentences, in your own words."),
            ("Why it matters here", "Say where this vault's work uses it."),
            ("Related", "Link the pages that explain, contrast or depend on it."),
        ),
    ),
    "entity": Blueprint(
        "wiki",
        (
            (
                "Summary",
                "What is true now about this person, team, system or thing. Rewrite it "
                "when it changes: this is the compiled truth.",
            ),
            (
                "Timeline",
                "One dated line per event, newest last. Append only: the past is not edited.",
            ),
        ),
    ),
    "analysis": Blueprint(
        "wiki",
        (
            ("Question", "State what is being asked, exactly."),
            ("Answer", "The answer, with each claim attributed to its source."),
            ("Evidence", "Quote each source word for word; `sb lint` checks every quote."),
            ("Open points", "What this does not settle."),
        ),
    ),
    "procedure": Blueprint(
        "wiki",
        (
            ("When to use", "The situation this is for, and when not to."),
            ("Steps", "Numbered, one action each, with the exact command or click."),
            ("Check it worked", "What you should see when it is done."),
            ("If it fails", "The first things to look at, and who to ask."),
        ),
        review=True,
    ),
    "incident": Blueprint(
        "wiki",
        (
            ("Impact", "Who or what was affected, and for how long."),
            ("Timeline", "Dated lines: what was seen, what was done, what changed."),
            ("Cause", "Why it happened, as far as is known; say what is not."),
            ("Fix", "What ended it."),
            ("What changes", "The follow-ups that stop it happening again, each with an owner."),
        ),
        review=True,
    ),
    "decision": Blueprint(
        "memory/decisions",
        (
            ("Context", "What forced a choice, and what was known."),
            ("Decision", "What was decided, in one sentence."),
            ("Consequences", "What gets easier, what gets harder, what is now fixed."),
            ("Alternatives", "What was considered and why it lost."),
        ),
        meta=(("status", "proposed"),),
        dated=True,
    ),
}


def kinds() -> list[str]:
    return sorted(_BLUEPRINTS)


def _file_name(title: str) -> str:
    clean = " ".join(_UNSAFE.sub(" ", title).split()).strip(". ")
    if not clean:
        raise VaultError("the title has no letters or digits to name the page with")
    return clean[:80].rstrip(". ")


def create(vault: Vault, kind: str, title: str, today: date) -> str:
    """Write the skeleton and return its vault-relative path; refuses before writing."""
    blueprint = _BLUEPRINTS.get(kind)
    if blueprint is None:
        raise VaultError(f"unknown type {kind!r}; the types are {', '.join(kinds())}")
    clean = _file_name(title)
    slug = slugify(clean)
    # slugify keeps ASCII only: a title with no Latin letters keeps its own words in the name
    stem = clean if slug == "untitled" else slug
    name = f"{today.isoformat()}-{stem}" if blueprint.dated else clean
    if not is_safe_name(f"{name}.md"):
        raise VaultError(f"{name!r} is not a file name every system accepts; use another title")
    rel = f"{blueprint.folder}/{name}.md"
    if (vault.root / rel).exists():
        raise VaultError(f"{rel} already exists")
    taken = name_in_use(load_pages(vault), frozen_ids(vault) | inbox_ids(vault), link_key(name))
    if taken:
        raise VaultError(f"{name!r} already exists as {taken}; give it another title")
    lines = ["---", f"type: {kind}", "description: One line that says what this page is."]
    lines += [f"{key}: {value}" for key, value in blueprint.meta]
    if blueprint.review:
        lines += [
            f"updated: {today.isoformat()}",
            f"review_by: {(today + timedelta(days=REVIEW_DAYS)).isoformat()}",
        ]
    heading = " ".join(title.split()).replace("[[", "[").replace("]]", "]").replace('*"', '"')
    lines += ["sources: []", "---", f"# {heading}", ""]
    lines += [f"{_PENDING} Write the one-line description in the frontmatter.", ""]
    for heading, hint in blueprint.sections:
        lines += [f"## {heading}", "", f"{_PENDING} {hint}", ""]
    write_text_atomic(vault.root / rel, "\n".join(lines))
    render_index(vault, load_pages(vault))
    return rel
