"""`sb upgrade` (ADR-016): refresh the framework's files in a vault, never the curator's data.

The only paths it can touch are the ones in `scaffold.installed()`, plus `.sb/templates.json`
and this machine's hooks. It never lists, reads or writes a wiki page, a source, a note, a
journal or a log. It never deletes: `uninstall` below is the one separate command that does.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from sb import __version__, scaffold
from sb.vault import (
    BOM,
    PRE_COMMIT_MARK,
    Vault,
    VaultError,
    read_text,
    read_text_or_none,
    strip_sb_settings,
    write_text_atomic,
)

CREATE = "create"  # the file is missing: written from the template
UPDATE = "update"  # the curator never edited it: replaced by the new template
APPEND = "append"  # .gitignore: template lines the vault lacks are added
CURRENT = "current"  # already identical to the new template
KEPT = "kept"  # the curator's edit: left exactly as it is
REMOVE = "remove"  # `sb uninstall`: a framework file nobody edited
KEEP = "keep"  # `sb uninstall`: left alone, with the reason
EDIT = "edit"  # `sb uninstall`: only sb's own entries come out of the file

SETTINGS = ".claude/settings.json"
LOCAL_SETTINGS = ".claude/settings.local.json"


@dataclass(frozen=True)
class Change:
    path: str
    action: str
    detail: str = ""


def run(vault: Vault, dry_run: bool = False, agents: bool = False) -> list[Change]:
    """Decide for every template file, then write. A refusal happens before any write."""
    try:
        return _run(vault, dry_run, agents)
    except (OSError, UnicodeDecodeError) as exc:
        raise VaultError(
            f"{exc}; fix the cause and run `sb upgrade` again "
            "(an interrupted upgrade resumes safely)"
        ) from exc


def _run(vault: Vault, dry_run: bool, agents: bool) -> list[Change]:
    last = scaffold.recorded_version(vault.state / scaffold.MANIFEST)
    if scaffold.is_newer(last):  # a colleague's newer sb already upgraded it: do not roll back
        raise VaultError(
            f"this vault was last upgraded by sb {last}, newer than this sb ({__version__}); "
            "update sb first (`python setup-sb.py`), or upgrading would put older files over "
            "newer ones"
        )
    recorded = _load_manifest(vault)
    digests = dict(recorded)
    changes: list[Change] = []
    writes: dict[str, str] = {}
    wants = agents or vault.wants_agents()
    for template in scaffold.installed(agents=wants):
        dest = vault.root / template.target
        if template.is_merged and dest.exists():
            merged = _merge_ignore(vault, template)
            if merged is not None:
                writes[template.target] = merged
                changes.append(Change(template.target, APPEND, "lines the template has"))
        elif not dest.exists():
            writes[template.target] = template.text
            changes.append(Change(template.target, CREATE))
            if template.is_managed:
                digests[template.target] = template.digest
        elif template.is_managed:
            change = _decide(vault, template, recorded)
            changes.append(change)
            if change.action == UPDATE:
                writes[template.target] = template.text
            if change.action in (UPDATE, CURRENT):
                digests[template.target] = template.digest
    _preflight(vault, writes)
    for note in vault.pending_migrations():  # pre-ADR-011 vaults (ADR-011)
        path, _, detail = note.partition(" (")
        if not any(c.path == path and c.action in (UPDATE, APPEND) for c in changes):
            changes.append(Change(path, UPDATE, detail.rstrip(")")))
    if dry_run:
        return changes
    if agents:  # before the first write: an interrupted run then resumes with the mirror
        vault.record_agents()
    for target, text in writes.items():
        write_text_atomic(vault.root / target, text)
    if digests != recorded:
        write_text_atomic(vault.state / scaffold.MANIFEST, scaffold.dump_manifest(digests))
    vault.install_hooks()
    return changes


def _preflight(vault: Vault, writes: dict[str, str]) -> None:
    """Everything `install_hooks` will read must be readable now, before the first write."""
    settings = vault.root / SETTINGS
    shared = writes.get(SETTINGS) or (read_text_or_none(settings) if settings.is_file() else "{}")
    _require_json_object(SETTINGS, shared)
    local = vault.root / LOCAL_SETTINGS
    if local.is_file():
        _require_json_object(LOCAL_SETTINGS, read_text_or_none(local))
    ignore = vault.root / ".gitignore"
    if ignore.is_file() and read_text_or_none(ignore) is None:
        raise VaultError(".gitignore is not UTF-8; convert it (UTF-8, LF), then run `sb upgrade`")


def _require_json_object(target: str, text: str | None) -> None:
    try:
        if text is None:
            raise ValueError("not UTF-8")
        data = json.loads(text.removeprefix(BOM))
    except ValueError as exc:
        raise VaultError(
            f"{target} is not valid JSON ({exc}); fix it, then run `sb upgrade` again"
        ) from exc
    if not isinstance(data, dict):
        raise VaultError(f"{target} must be a JSON object; fix it, then run `sb upgrade` again")


def uninstall(vault: Vault, apply: bool = False) -> list[Change]:
    """The framework's files that `sb` would take out of this vault, and what it keeps.

    The plan is made of template paths only (a manifest that names anything else is not
    trusted). A file that still equals what was installed is removed; an edited one is kept and
    named. The shared settings are kept: they hold the rules that guard `.env` and the sources.
    Of the machine's local settings only sb's own hooks and rules go. Notes, sources, memory, the
    log, `CONVENTIONS.md` and `.sb/` are never in the plan.
    """
    recorded = _load_manifest(vault)
    templates = {t.target for t in scaffold.installed(agents=True)}
    plan: list[Change] = []
    for target, digest in sorted(recorded.items()):
        path = vault.root / target
        if target not in templates:
            plan.append(Change(target, KEEP, "not a framework file"))
        elif target == ".claude/settings.json" and path.is_file():
            plan.append(Change(target, KEEP, "holds the rules that guard .env and sources/"))
        elif path.is_file():
            text = read_text_or_none(path)
            if text is not None and scaffold.text_digest(text.removeprefix(BOM)) == digest:
                plan.append(Change(target, REMOVE))
            else:
                plan.append(Change(target, KEEP, "edited by the curator"))
    hook = vault.root / ".githooks" / "pre-commit"
    if hook.is_file() and PRE_COMMIT_MARK in (read_text_or_none(hook) or ""):
        plan.append(Change(".githooks/pre-commit", REMOVE, "generated for this machine"))
    local = vault.root / ".claude" / "settings.local.json"
    if local.is_file():
        plan.append(Change(".claude/settings.local.json", EDIT, "sb's hooks and rules only"))
    if apply:
        done = 0
        try:
            for change in plan:
                path = vault.root / change.path
                if change.action == REMOVE:
                    path.unlink()
                    for parent in path.parents:
                        if parent == vault.root or any(parent.iterdir()):
                            break
                        parent.rmdir()
                elif change.action == EDIT:
                    _strip_local(path)
                done += change.action in {REMOVE, EDIT}
        except OSError as exc:
            raise VaultError(
                f"stopped after {done} change(s): {exc}; close what holds the file and run "
                "`sb uninstall --apply` again (it resumes)"
            ) from exc
    return plan


def _strip_local(path: Path) -> None:
    try:
        data = json.loads(read_text(path).removeprefix(BOM))
    except ValueError:
        return  # not JSON: not ours to rewrite
    if isinstance(data, dict) and strip_sb_settings(data):
        write_text_atomic(path, json.dumps(data, indent=2, ensure_ascii=False) + "\n")


def _load_manifest(vault: Vault) -> dict[str, str]:
    path = vault.state / scaffold.MANIFEST
    if not path.is_file():
        return {}  # made before ADR-016: matching files are adopted, the others are kept
    text = read_text_or_none(path)
    try:
        if text is None:
            raise ValueError("not UTF-8")
        return scaffold.parse_manifest(text.removeprefix(BOM))
    except ValueError as exc:
        raise VaultError(
            f"{vault.rel(path)} is damaged ({exc}); delete it and run `sb upgrade` again: "
            "files equal to the new templates are adopted, edited ones are kept"
        ) from exc


def _decide(vault: Vault, template: scaffold.Template, recorded: dict[str, str]) -> Change:
    text = read_text_or_none(vault.root / template.target) if _is_file(vault, template) else None
    if text is None:
        return Change(template.target, KEPT, "not a readable UTF-8 file")
    disk = scaffold.text_digest(text.removeprefix(BOM))
    if disk == template.digest:
        return Change(template.target, CURRENT)
    if recorded.get(template.target) == disk:
        return Change(template.target, UPDATE)
    return Change(
        template.target,
        KEPT,
        "differs from the template (your edit or an older version); "
        "delete it and run `sb upgrade` to take the new one",
    )


def _is_file(vault: Vault, template: scaffold.Template) -> bool:
    return (vault.root / template.target).is_file()


def _merge_ignore(vault: Vault, template: scaffold.Template) -> str | None:
    """The vault's .gitignore plus the template lines it lacks; None when nothing is missing.

    The file's own line endings are kept: a CRLF file stays CRLF, so the diff is only the
    added lines.
    """
    raw = (vault.root / template.target).read_bytes()
    try:
        current = raw.decode("utf-8").removeprefix(BOM)
    except UnicodeDecodeError:  # never replace what cannot be read
        return None
    eol = "\r\n" if "\r\n" in current else "\n"
    present = {line.strip() for line in current.splitlines()}
    wanted = [
        line.strip()
        for line in template.text.splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]
    missing = [line for line in wanted if line not in present]
    if not missing:
        return None
    body = current.rstrip("\r\n")
    return (body + eol if body else "") + eol.join(missing) + eol
