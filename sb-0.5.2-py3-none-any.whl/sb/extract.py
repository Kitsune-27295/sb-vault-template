"""Turning a document's bytes into markdown, offline (S26, ADR-029).

HTML, PDF and plain text become the markdown a source is made of. Nothing here touches the
network, so `sb clip` (which fetches) and `sb import` (which reads a folder) share it, and the
core stays offline: this module must never import `urllib.request`. HTML and PDF need the
`capture` extra, imported inside the functions that use it.
"""

from __future__ import annotations

import hashlib
import io
import json
import logging
import re
from typing import Any
from urllib.parse import urlsplit


class ExtractError(Exception):
    """One document could not be read; the others continue."""


class NoContentError(ExtractError):
    """Readable, but no text worth keeping (a page of links, a scan)."""


def host_of(netloc: str) -> str:
    host = netloc.lower().rsplit("@", 1)[-1].split(":", 1)[0]
    for prefix in ("www.", "m."):
        host = host.removeprefix(prefix)
    return host


def missing(package: str) -> str:
    return f'{package} is not installed; run: pip install -e ".[capture]"'


def front(meta: dict[str, Any]) -> str:
    lines = [f"{k}: {json.dumps(v, ensure_ascii=False)}" for k, v in meta.items() if v]
    return "---\n" + "\n".join(lines) + "\n---\n"


def page_markdown(url: str, body: bytes, ctype: str) -> tuple[str, str]:
    """(title, markdown) of an HTML page, a PDF or plain text."""
    if ctype == "application/pdf" or body[:5] == b"%PDF-":
        return _pdf_markdown(url, body)
    if ctype.startswith("text/") and "html" not in ctype:
        text = body.decode("utf-8", errors="replace")
        title = next((ln[2:].strip() for ln in text.split("\n") if ln.startswith("# ")), "")
        return title or name_from_url(url), text
    try:
        import trafilatura
    except ImportError as exc:
        raise ExtractError(missing("trafilatura")) from exc
    html = body.decode("utf-8", errors="replace")
    content = trafilatura.extract(
        html,
        url=url,
        output_format="markdown",
        include_links=True,
        include_tables=True,
        include_comments=False,  # a page's comment thread is not the source (ingest 1 found an ad)
    )
    if not content or not content.strip():
        raise NoContentError("no readable main content (JavaScript-only page or paywall?)")
    meta = trafilatura.extract_metadata(html, default_url=url)
    title = (getattr(meta, "title", None) or "").strip() or name_from_url(url)
    header = {
        "title": title,
        "url": url,
        "author": getattr(meta, "author", None),
        "published": getattr(meta, "date", None),
        "site": getattr(meta, "sitename", None),
        "kind": "page",
    }
    return title, f"{front(header)}\n# {title}\n\n{content.strip()}\n"


def _pdf_markdown(url: str, body: bytes) -> tuple[str, str]:
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise ExtractError(missing("pypdf")) from exc
    # pypdf logs a warning per odd font (a 54 KB wall for six arXiv papers); the text is fine.
    logging.getLogger("pypdf").setLevel(logging.ERROR)
    try:
        reader = PdfReader(io.BytesIO(body))
        pages = [(page.extract_text() or "").strip() for page in reader.pages]
        title = str(reader.metadata.get("/Title") or "").strip() if reader.metadata else ""
    except Exception as exc:  # malformed PDFs raise assorted errors
        raise ExtractError(f"unreadable PDF: {exc}") from exc
    if not any(pages):
        raise NoContentError("the PDF has no text layer (scanned?); OCR is out of scope")
    # Rejoin words split at a line end ("ho-\nmogeneous"), so they can be quoted; a hyphen
    # followed by an upper-case letter or a digit is kept (it is likely a real one).
    pages = [_LINE_HYPHEN.sub(r"\1\2", text) for text in pages]
    first_line = next((ln.strip() for ln in pages[0].split("\n") if ln.strip()), "")
    if not title and 8 <= len(first_line) <= 150:
        title = first_line  # papers often carry no /Title; their first line is the title
    title = title or name_from_url(url)
    parts = [f"## Page {i}\n\n{text}" for i, text in enumerate(pages, start=1) if text]
    header = {"title": title, "url": url, "kind": "pdf", "pages": len(pages)}
    return title, f"{front(header)}\n# {title}\n\n" + "\n\n".join(parts) + "\n"


_LINE_HYPHEN = re.compile(r"(\w)-\n([a-zà-öø-ÿ])")  # continuation starts lower-case


def name_from_url(url: str) -> str:
    parts = urlsplit(url)
    tail = [s for s in parts.path.split("/") if s]
    return tail[-1] if tail else host_of(parts.netloc)


def content_digest(text: str) -> str:
    """sha256 of the captured content without its header (which holds the url and dates)."""
    body = text.split("\n---\n", 1)[1] if text.startswith("---\n") and "\n---\n" in text else text
    return hashlib.sha256(" ".join(body.split()).encode("utf-8")).hexdigest()
