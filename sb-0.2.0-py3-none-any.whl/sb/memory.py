"""Session brief: what the agent must know at the start of every session (ADR-005)."""

from __future__ import annotations

from sb import checks
from sb.pages import load_pages
from sb.sources import inbox_ids
from sb.vault import Vault, read_text

MAX_LISTED = 5


def brief(vault: Vault) -> str:
    """Working memory, open decisions, pending inbox and vault health, in one short text."""
    pages = load_pages(vault)
    parts = ["# Session brief (sb)", ""]

    hot = vault.root / "memory" / "hot.md"
    parts += ["## In flight (memory/hot.md)", ""]
    try:
        parts.append(read_text(hot).strip() if hot.is_file() else "_memory/hot.md is missing_")
    except UnicodeDecodeError:
        parts.append("_memory/hot.md is not valid UTF-8; re-save it as UTF-8_")

    proposed = sorted(
        (
            p
            for p in pages
            if p.meta.get("type") == "decision" and p.meta.get("status") == "proposed"
        ),
        key=lambda p: p.name,
    )
    parts += ["", f"## Open decisions ({len(proposed)})", ""]
    parts += [f"- [[{p.name}]] — {p.meta.get('description', '')}" for p in proposed[:MAX_LISTED]]
    if not proposed:
        parts.append("- none")

    pending = sorted(inbox_ids(vault))
    parts += ["", f"## Inbox ({len(pending)} awaiting ingest)", ""]
    parts += [f"- {sid}" for sid in pending[:MAX_LISTED]] or ["- empty"]
    if len(pending) > MAX_LISTED:
        parts.append(f"- … and {len(pending) - MAX_LISTED} more")

    findings = checks.run(vault)
    errs = checks.errors(findings)
    parts += ["", f"## Health: {len(errs)} error(s), {len(findings) - len(errs)} warning(s)", ""]
    parts += [f"- {f}" for f in errs[:MAX_LISTED]]
    if errs:
        parts.append("- Run `sb lint` for the full list.")
    return "\n".join(parts) + "\n"
