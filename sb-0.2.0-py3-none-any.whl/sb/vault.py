"""Vault location, layout, safe names and atomic UTF-8/LF IO."""

from __future__ import annotations

import json
import os
import re
import shlex
import sys
import tempfile
import unicodedata
from dataclasses import dataclass
from pathlib import Path

from sb import scaffold

MARKER = ".sb"
PRE_COMMIT_MARK = "Installed by `sb hook install`"  # first comment of the generated hook
GENERATED_PATHS = (".claude/settings.local.json", ".githooks/")  # per machine (ADR-011)
REQUIRED_IGNORES = (*GENERATED_PATHS, ".env", ".env.*")  # also enforced on existing vaults
BOM = chr(0xFEFF)  # UTF-8 byte-order mark, stripped wherever text is read
_SKIP_DIRS = frozenset({MARKER, ".claude", ".git", ".obsidian", ".trash"})
ZONES = ("sources/inbox", "wiki", "notes", "context", "memory/decisions", "memory/journal", "log")
# Characters Obsidian warns against in names, plus those Windows forbids.
_ILLEGAL = re.compile(r'[#|^:\[\]%<>"/\\?*\x00-\x1f]')
_RESERVED = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}


class VaultError(Exception):
    """A vault operation was refused."""


def is_safe_name(name: str) -> bool:
    stem = name.split(".", 1)[0]
    return (
        bool(name.strip())
        and not _ILLEGAL.search(name)
        and not name.endswith((" ", "."))
        and stem.upper() not in _RESERVED
    )


def fold(text: str) -> str:
    """Case- and accent-insensitive form, matching FTS5 `remove_diacritics 2`."""
    decomposed = unicodedata.normalize("NFKD", text)
    return "".join(c for c in decomposed if not unicodedata.combining(c)).casefold()


def slugify(text: str, limit: int = 60) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", fold(text)).strip("-")
    return slug[:limit].rstrip("-") or "untitled"


# The longest relative path sb writes: sources/inbox/ + a maximal source id + .meta.json.
LONGEST_REL_PATH = len("sources/inbox/") + len("20260930-") + 60 + len("-99.meta.json")
WINDOWS_MAX_PATH = 259  # MAX_PATH (260) minus the terminating NUL


def path_budget_warning(root: Path, windows: bool = os.name == "nt") -> str | None:
    """On Windows without long-path support, a deep vault folder breaks writes (MAX_PATH)."""
    if not windows:
        return None
    longest = len(str(root)) + 1 + LONGEST_REL_PATH
    if longest <= WINDOWS_MAX_PATH:
        return None
    return (
        f"vault path is {len(str(root))} characters; its longest files would reach {longest} "
        f"(Windows limit {WINDOWS_MAX_PATH}). Use a shorter folder, e.g. C:\\brain"
    )


def sb_command() -> str:
    """How hooks invoke this installation: the interpreter that has `sb`, by absolute path.

    A bare `sb` works only when it is on PATH, which a virtualenv install is not; a hook
    that cannot start fails silently in every session.
    """
    exe = Path(sys.executable).as_posix()
    # POSIX shells expand `$` and backticks inside double quotes; Windows forbids `"` in names.
    return f'"{exe}" -m sb' if os.name == "nt" else f"{shlex.quote(exe)} -m sb"


# Unambiguous credential formats only (low false-positive rate): a vault may be pushed.
_SECRETS = re.compile(
    r"-----BEGIN [A-Z ]*PRIVATE KEY-----"  # PEM private keys
    r"|\bgh[pousr]_[A-Za-z0-9]{36,}\b"  # GitHub tokens
    r"|\bgithub_pat_[A-Za-z0-9_]{40,}\b"  # GitHub fine-grained tokens
    r"|\bAKIA[0-9A-Z]{16}\b"  # AWS access key ids
    r"|\bsk-(?:ant-|proj-)?[A-Za-z0-9_-]{32,}\b"  # Anthropic / OpenAI style API keys
    r"|\bxox[baprs]-[A-Za-z0-9-]{10,}\b"  # Slack tokens
)


# Markdown backslash-escapes of ASCII punctuation. trafilatura 2.3 writes `ghp\_abc`, and a
# token whose underscore is escaped is still the same token.
_MD_ESCAPE = re.compile(r"\\([!-/:-@\[-`{-~])")


def secret_lines(text: str) -> list[int]:
    """1-based lines of `text` that contain an unambiguous credential format."""
    return [
        n
        for n, line in enumerate(text.split("\n"), start=1)
        if _SECRETS.search(_MD_ESCAPE.sub(r"\1", line))
    ]


_SB_HOOKS = frozenset({"session-start", "post-edit"})


def _is_sb_hook(handler: object) -> bool:
    """Exactly the commands sb generates: `sb hook X`, or `<interpreter> -m sb hook X`.

    Tokenised with `shlex.split`, the inverse of the `shlex.quote` in `sb_command`, so any
    quoting of the interpreter path (spaces, apostrophes) is recognised.
    """
    command = handler.get("command") if isinstance(handler, dict) else None
    if not isinstance(command, str):
        return False
    try:
        tokens = shlex.split(command)
    except ValueError:
        return False  # unbalanced quotes: certainly not something sb wrote
    if len(tokens) < 3 or tokens[-2] != "hook" or tokens[-1] not in _SB_HOOKS:
        return False
    head = tokens[:-2]
    return head == ["sb"] or (len(head) == 3 and head[1:] == ["-m", "sb"])


def _drop_sb_hooks(settings: dict[str, object]) -> bool:
    """Remove sb's own hook handlers in place; True if any went.

    Everything else is left exactly as found: a group or an event disappears only when
    sb's handlers were all it held, and `hooks` only when nothing else remains in it.
    """
    events = settings.get("hooks")
    if not isinstance(events, dict):
        return False
    removed = False
    for event in list(events):
        groups = events[event]
        if not isinstance(groups, list):
            continue  # not a shape sb writes: not ours to touch
        kept_groups: list[object] = []
        event_removed = False
        for group in groups:
            handlers = group.get("hooks") if isinstance(group, dict) else None
            if not isinstance(handlers, list) or not any(_is_sb_hook(h) for h in handlers):
                kept_groups.append(group)
                continue
            kept = [h for h in handlers if not _is_sb_hook(h)]
            event_removed = removed = True
            if kept:
                kept_groups.append({**group, "hooks": kept})
        if event_removed and not kept_groups:
            del events[event]
        else:
            events[event] = kept_groups
    if removed and not events:
        del settings["hooks"]
    return removed


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def read_text_or_none(path: Path) -> str | None:
    """The file's text, or None when it is not UTF-8 (`load_all` reports such files as FM001)."""
    try:
        return read_text(path)
    except UnicodeDecodeError:
        return None


def write_text_atomic(path: Path, text: str) -> None:
    """Write via a temp file in the same directory, then atomically replace."""
    path.parent.mkdir(parents=True, exist_ok=True)
    # A short fixed name: the temp path must never be longer than the final one (MAX_PATH).
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".sb-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
        Path(tmp).replace(path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


@dataclass(frozen=True)
class Vault:
    root: Path

    @property
    def state(self) -> Path:
        return self.root / MARKER

    @property
    def inbox(self) -> Path:
        return self.root / "sources" / "inbox"

    @property
    def sources(self) -> Path:
        return self.root / "sources"

    @property
    def wiki(self) -> Path:
        return self.root / "wiki"

    @property
    def index_db(self) -> Path:
        return self.state / "index.sqlite"

    @classmethod
    def find(cls, start: Path) -> Vault:
        """Walk up from `start` to the first directory holding a `.sb/` marker."""
        here = start.resolve()
        for candidate in (here, *here.parents):
            if (candidate / MARKER).is_dir():
                return cls(candidate)
        raise VaultError(f"no vault found at or above {here} (run `sb init`)")

    @classmethod
    def init(cls, root: Path) -> Vault:
        root = root.resolve()
        if (root / MARKER).exists():
            raise VaultError(f"{root} is already a vault")
        vault = cls(root)
        for zone in ZONES:
            (root / zone).mkdir(parents=True, exist_ok=True)
        vault.state.mkdir(parents=True)
        write_text_atomic(vault.state / "config.json", json.dumps({"version": 1}) + "\n")
        templates = scaffold.installed()
        for template in templates:
            dest = root / template.target
            if not dest.exists():  # never overwrite what the curator already has
                write_text_atomic(dest, template.text)
        recorded = {t.target: t.digest for t in templates if t.is_managed}
        write_text_atomic(vault.state / scaffold.MANIFEST, scaffold.dump_manifest(recorded))
        try:
            vault.install_hooks()
        except VaultError as exc:  # the vault itself is complete; only the hooks are missing
            raise VaultError(
                f"vault created at {root}, but hooks were not installed: {exc}"
            ) from exc
        return vault

    def install_hooks(self) -> list[str]:
        """(Re)write this machine's hook files; return their vault-relative paths.

        They embed this machine's interpreter (`sb_command`), so they are generated per
        machine and gitignored: run `sb hook install` once in every new clone. Vaults made
        before ADR-011 are migrated: hooks leave the shared settings, `.gitignore` gains the
        generated paths.
        """
        templates = scaffold.templates_root()
        command = sb_command()
        written = self._migrate_shared_hooks()
        local = self.root / ".claude" / "settings.local.json"
        rendered = json.loads(
            templates.joinpath("settings.local.json")
            .read_text(encoding="utf-8")
            .replace("{{SB}}", json.dumps(command, ensure_ascii=False)[1:-1])
        )
        merged = self._merge_local_hooks(local, rendered)
        write_text_atomic(local, json.dumps(merged, indent=2, ensure_ascii=False) + "\n")
        written.append(".claude/settings.local.json")
        hook = self.root / ".githooks" / "pre-commit"
        if hook.is_file() and PRE_COMMIT_MARK not in read_text(hook):
            written.append(".githooks/pre-commit (kept: not generated by sb)")
            return written
        text = templates.joinpath("pre-commit").read_text(encoding="utf-8")
        write_text_atomic(hook, text.replace("{{SB}}", command))
        hook.chmod(0o755)  # git ignores a hook that is not executable (POSIX)
        written.append(".githooks/pre-commit")
        return written

    @staticmethod
    def _merge_local_hooks(path: Path, rendered: dict[str, object]) -> dict[str, object]:
        """The machine's settings with sb's hooks refreshed and every other key left alone.

        Claude Code writes the curator's local approvals into this same file.
        """
        loaded: object = {}
        if path.is_file():
            try:
                loaded = json.loads(read_text(path).removeprefix(BOM))
            except ValueError as exc:
                raise VaultError(
                    f"{path.name} is not valid JSON ({exc}); fix or delete it, "
                    "then run `sb hook install`"
                ) from exc
        if not isinstance(loaded, dict):
            raise VaultError(f"{path.name} is not a JSON object; fix or delete it")
        merged: dict[str, object] = dict(loaded)
        _drop_sb_hooks(merged)
        events = merged.setdefault("hooks", {})
        fresh = rendered.get("hooks")
        if isinstance(events, dict) and isinstance(fresh, dict):
            for event, groups in fresh.items():
                kept = events.get(event)
                events[event] = [*(kept if isinstance(kept, list) else []), *groups]
        return merged

    def pending_migrations(self) -> list[str]:
        """What `install_hooks` would migrate in a pre-ADR-011 vault; writes nothing."""
        return self._migrate_shared_hooks(write=False)

    def _migrate_shared_hooks(self, write: bool = True) -> list[str]:
        """Pre-ADR-011 vaults kept sb's hooks in the committed settings; drop only those.

        Hooks the curator wrote stay exactly where they are. Invalid JSON is refused with
        an actionable message before anything is written.
        """
        changed: list[str] = []
        shared = self.root / ".claude" / "settings.json"
        if shared.is_file():
            try:
                data = json.loads(read_text(shared).removeprefix(BOM))
            except ValueError as exc:
                msg = f"{self.rel(shared)} is not valid JSON ({exc}); fix it, run `sb hook install`"
                raise VaultError(msg) from exc
            if isinstance(data, dict) and _drop_sb_hooks(data):
                if write:
                    text = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
                    write_text_atomic(shared, text)
                changed.append(".claude/settings.json (sb hooks moved out)")
        ignore = self.root / ".gitignore"
        current = read_text(ignore).removeprefix(BOM) if ignore.is_file() else ""
        present = {line.strip() for line in current.replace("\r\n", "\n").split("\n")}
        missing = [p for p in REQUIRED_IGNORES if p not in present]
        if missing:
            if write:
                text = current.rstrip("\r\n") + "\n" + "\n".join(missing) + "\n"
                write_text_atomic(ignore, text)
            changed.append(".gitignore (generated paths added)")
        return changed

    def entries(self, suffix: str = "") -> list[tuple[str, os.DirEntry[str]]]:
        """(vault-relative POSIX path, DirEntry) for every content file ending in `suffix`,
        excluding tool state, trash and the inbox; sorted by path.

        `os.scandir` is used because a DirEntry carries its stat from the directory listing
        on Windows, which keeps `search.sync` cheap on every query.
        """
        out: list[tuple[str, os.DirEntry[str]]] = []
        pending = [("", self.root)]
        while pending:
            prefix, folder = pending.pop()
            with os.scandir(folder) as listing:
                for entry in listing:
                    rel = f"{prefix}{entry.name}"
                    if entry.is_dir(follow_symlinks=False):
                        if (
                            not (prefix == "" and entry.name in _SKIP_DIRS)
                            and rel != "sources/inbox"
                        ):
                            pending.append((f"{rel}/", Path(entry.path)))
                    elif entry.is_file() and entry.name.lower().endswith(suffix):
                        out.append((rel, entry))
        return sorted(out, key=lambda item: item[0])

    def files(self) -> list[Path]:
        return [Path(entry.path) for _, entry in self.entries()]

    def markdown_files(self) -> list[Path]:
        return [Path(entry.path) for _, entry in self.entries(".md")]

    def rel(self, path: Path) -> str:
        return path.relative_to(self.root).as_posix()
