"""Ingest transaction: validate everything first, then freeze, log, index (ADR-004)."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from sb import checks, logbook, search
from sb.checks import NAMED_ZONES, Finding
from sb.pages import Page, link_key, link_targets, load_all, load_pages
from sb.sources import (
    check_id,
    freeze,
    frozen_ids,
    inbox_ids,
    read_meta,
    sha256_text,
    source_text,
    verify_hash,
)
from sb.vault import Vault, VaultError, secret_lines


@dataclass
class CloseReport:
    source_id: str
    pages: list[str] = field(default_factory=list)
    findings: list[Finding] = field(default_factory=list)
    sha256: str = ""
    resumed: bool = False
    quotes_checked: int = 0

    @property
    def ok(self) -> bool:
        return bool(self.sha256)


def close(vault: Vault, source_id: str, now: datetime, dry_run: bool = False) -> CloseReport:
    """Close the ingest of one source. Idempotent: re-running completes an interrupted close.

    Refuses, writing nothing, unless every wiki page parses, at least one wiki page
    cites the source in `sources:`, and every citing page passes the checks. Pages
    outside `wiki/` never block an ingest. With `dry_run`, only the checks run.
    """
    check_id(source_id)
    inbox_md = vault.inbox / f"{source_id}.md"
    frozen_md = vault.sources / f"{source_id}.md"
    resumed = frozen_md.exists()
    if resumed and not verify_hash(vault, source_id):
        raise VaultError(f"frozen source {source_id} fails its sha256 check; it was modified")
    if not resumed and not inbox_md.exists():
        raise VaultError(f"source {source_id} is not in sources/inbox/")

    pages, load_errors = load_all(vault)
    report = CloseReport(source_id, resumed=resumed)
    # A wiki page that does not parse might be the one citing this source; an unreadable
    # log file would fail the log step after the freeze. Both refuse before writing.
    report.findings = checks.load_findings(
        e for e in load_errors if e.rel.startswith(("wiki/", "log/"))
    )
    if report.findings:
        return report  # a wiki page that does not parse might be the one citing this source

    citing = [p for p in pages if p.zone == "wiki" and source_id in p.source_ids()]
    if not citing:
        raise VaultError(f"no wiki page cites {source_id!r} in `sources:`; write the pages first")
    report.pages = sorted(p.rel for p in citing)
    report.quotes_checked = sum(len(checks.quotes(p)) for p in citing)
    cited = set(report.pages)
    # The source's id joins the wikilink namespace when frozen: no page may already use it.
    clash = [
        Finding("NAM002", "error", p.rel, 1, f"page name collides with source id {source_id!r}")
        for p in pages
        if p.zone in NAMED_ZONES and p.zone != "sources" and link_key(p.name) == link_key(source_id)
    ]
    names = link_targets(vault, pages) | {link_key(i) for i in inbox_ids(vault)}
    report.findings = (
        clash
        + [f for f in checks.duplicate_names(pages) if f.path in cited]
        + checks.check_pages(citing, names, frozen_ids(vault) | inbox_ids(vault))
        + checks.check_quotes(vault, citing)  # report.quotes_checked says how many
        + ([] if resumed else _changed_since_capture(vault, source_id))
        + ([] if resumed else _uncited_edits(vault, source_id, pages))
        + ([] if resumed else _secret_in_source(vault, source_id))
    )
    if checks.errors(report.findings) or dry_run:
        return report  # a dry run reports what a real close would find, and writes nothing

    if resumed:
        report.sha256 = str(read_meta(frozen_md)["sha256"])
        inbox_md.unlink(missing_ok=True)  # left behind by a crash after the frozen copy landed
        inbox_md.with_suffix(".meta.json").unlink(missing_ok=True)
    else:
        report.sha256 = freeze(vault, source_id, now)
    if not logbook.has_entry(vault, "ingest", source_id):
        title = source_title(source_text(vault, source_id) or "", source_id)
        logbook.append(
            vault, "ingest", f"{source_id} — {title}", now
        )  # id for tools, title for people
    pages, _ = load_all(vault)  # reload: the source moved into the frozen store
    logbook.render_index(vault, pages)
    search.sync(vault)
    return report


def _changed_since_capture(vault: Vault, source_id: str) -> list[Finding]:
    """SRC003 (warn): the inbox copy no longer matches what `sb capture` recorded.

    The curator may edit the inbox legitimately, so this informs rather than blocks; the
    agent is denied inbox edits by the vault's settings (defence in depth for quotes).
    """
    inbox_md = vault.inbox / f"{source_id}.md"
    if not inbox_md.with_suffix(".meta.json").exists():
        return []
    recorded = read_meta(inbox_md).get("captured_sha256")
    text = source_text(vault, source_id)
    if recorded is None or text is None or sha256_text(text) == recorded:
        return []
    rel = f"sources/inbox/{source_id}.md"
    return [Finding("SRC003", "warn", rel, 1, "source changed since `sb capture`")]


def _uncited_edits(vault: Vault, source_id: str, pages: list[Page]) -> list[Finding]:
    """SRC004 (warn): wiki pages modified since the source was captured that do not cite it.

    `sb` cannot know which pages an ingest touched; a page edited during the ingest window
    without the id in `sources:` is the likely miss (evaluation E1, finding 7).
    """
    inbox_md = vault.inbox / f"{source_id}.md"
    if not inbox_md.with_suffix(".meta.json").exists():
        return []
    captured = read_meta(inbox_md).get("captured_at")
    if not isinstance(captured, str):
        return []
    try:
        since = datetime.fromisoformat(captured).timestamp()
    except ValueError:
        return []  # a hand-edited timestamp only disables this heuristic
    # Pages edited for an earlier ingest were written before that ingest froze its source:
    # only edits after the latest close belong to this one (evaluation: noise in batches).
    frozen = [p.stat().st_mtime for p in vault.sources.glob("*.md")]
    since = max([since, *frozen])
    wiki = [p for p in pages if p.zone == "wiki"]
    recent = [
        p for p in wiki if source_id not in p.source_ids() and p.path.stat().st_mtime >= since
    ]
    if len(recent) > max(3, len(wiki) // 2):
        return []  # most of the wiki looks new: a clone or checkout, not an ingest (review F4)
    msg = f"edited since {source_id} was captured but does not cite it (add the id if touched)"
    return [Finding("SRC004", "warn", p.rel, 1, msg) for p in recent]


def _secret_in_source(vault: Vault, source_id: str) -> list[Finding]:
    """SEC001 (error): a credential in the source about to be frozen, and then committed."""
    text = source_text(vault, source_id)
    msg = "the source contains what looks like a credential; remove it before closing"
    rel = f"sources/inbox/{source_id}.md"
    return [Finding("SEC001", "error", rel, n, msg) for n in secret_lines(text or "")]


def source_title(text: str, source_id: str) -> str:
    """A source's human title: its first `# ` heading, else the words of its id."""
    return next(
        (ln[2:].strip() for ln in text.split("\n") if ln.startswith("# ")),
        source_id.split("-", 1)[1].replace("-", " "),
    )


def plan(vault: Vault, source_id: str, limit: int = 10) -> dict[str, Any]:
    """Context for the LLM before it writes: the source, and the wiki pages it may touch.

    Read-only. The `ingest` skill turns this into a plan the curator approves.
    """
    check_id(source_id)
    text = source_text(vault, source_id)
    if text is None:
        raise VaultError(f"source {source_id} not found (or not UTF-8) in sources/")
    frozen = (vault.sources / f"{source_id}.md").exists()
    title = source_title(text, source_id)
    pages = load_pages(vault)
    citing = sorted(p.rel for p in pages if p.zone == "wiki" and source_id in p.source_ids())
    hits = [h for h in search.query(vault, title, limit * 3) if h.path.startswith("wiki/")]
    return {
        "source_id": source_id,
        "path": f"sources/{'' if frozen else 'inbox/'}{source_id}.md",
        "status": "frozen" if frozen else "inbox",
        "title": title,
        "chars": len(text),
        "already_citing": citing,
        "candidate_pages": [
            {"path": h.path, "title": h.title, "citation": h.citation, "snippet": h.snippet}
            for h in hits[:limit]
        ],
        "types": sorted(checks.TYPES),
    }
