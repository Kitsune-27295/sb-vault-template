"""Command-line surface. Thin: parse, call a module, print. Exit 0 ok, 1 refused/findings."""

from __future__ import annotations

import io
import json
import shutil
import sqlite3
import sys
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Annotated, Any, NoReturn

import typer

from sb import (
    __version__,
    checks,
    evaluate,
    ingest,
    logbook,
    memory,
    review,
    search,
    sources,
    upgrade,
)
from sb.pages import load_pages
from sb.vault import Vault, VaultError, path_budget_warning, sb_command

app = typer.Typer(no_args_is_help=True, add_completion=False, help=__doc__)
ingest_app = typer.Typer(no_args_is_help=True, help="Ingest transactions.")
index_app = typer.Typer(no_args_is_help=True, help="The generated catalogue and search index.")
memory_app = typer.Typer(no_args_is_help=True, help="Working memory.")
hook_app = typer.Typer(no_args_is_help=True, help="Claude Code hook entry points.")
app.add_typer(ingest_app, name="ingest")
app.add_typer(index_app, name="index")
app.add_typer(memory_app, name="memory")
app.add_typer(hook_app, name="hook")

VaultOpt = Annotated[
    Path | None, typer.Option("--vault", help="Vault root (default: search upward from cwd).")
]
JsonOpt = Annotated[bool, typer.Option("--json", help="Machine-readable output.")]


@app.callback()
def _utf8_output() -> None:
    """Emit UTF-8 even when piped on Windows, where the default is the ANSI code page."""
    for stream in (sys.stdout, sys.stderr):
        if isinstance(stream, io.TextIOWrapper):
            stream.reconfigure(encoding="utf-8")


def _vault(path: Path | None) -> Vault:
    try:
        return Vault.find(path or Path.cwd())
    except VaultError as exc:
        _fail(str(exc))


def _now() -> datetime:
    return datetime.now().astimezone()


def _fail(message: str) -> NoReturn:
    typer.echo(f"error: {message}", err=True)
    raise typer.Exit(1)


def _json(data: Any) -> None:
    typer.echo(json.dumps(data, ensure_ascii=False, indent=2))


@app.command()
def init(path: Annotated[Path, typer.Argument(help="Directory to turn into a vault.")]) -> None:
    """Create a vault skeleton with its skills and hooks (no questions asked)."""
    try:
        vault = Vault.init(path)
    except VaultError as exc:
        _fail(str(exc))
    typer.echo(f"vault created at {vault.root}")
    warning = path_budget_warning(vault.root)
    if warning:
        typer.echo(f"warning: {warning}", err=True)
    typer.echo("next: `git init` there, then `git config core.hooksPath .githooks`;")
    typer.echo("      open Claude Code in the vault and run the onboarding skill.")


@app.command("upgrade")
def upgrade_cmd(
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Show what would change; write nothing.")
    ] = False,
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """Refresh the framework's files in this vault (skills, rules, settings). Never touches data."""
    try:
        changes = upgrade.run(_vault(vault), dry_run=dry_run)
    except VaultError as exc:
        _fail(str(exc))
    if as_json:
        _json([asdict(c) for c in changes])
        return
    shown = [c for c in changes if c.action != upgrade.CURRENT]
    for c in shown:
        typer.echo(f"{c.action:<7} {c.path}" + (f"  ({c.detail})" if c.detail else ""))
    if not shown:
        typer.echo("already up to date")
    if dry_run:
        typer.echo("dry run: nothing was written")
    else:
        typer.echo("your notes, sources, memory and log were not touched; review with `git diff`")


@app.command()
def capture(
    file: Annotated[Path, typer.Argument(exists=True, dir_okay=False)],
    url: Annotated[
        str | None, typer.Option("--url", help="The link this file was clipped from.")
    ] = None,
    vault: VaultOpt = None,
) -> None:
    """Give a text/markdown file a source id in sources/inbox/ and print the id."""
    try:
        typer.echo(sources.capture(_vault(vault), file, _now(), url=url))
    except VaultError as exc:
        _fail(str(exc))


@ingest_app.command("plan")
def ingest_plan(source_id: str, vault: VaultOpt = None) -> None:
    """Print (JSON) the source and the wiki pages an ingest of SOURCE_ID may touch."""
    try:
        _json(ingest.plan(_vault(vault), source_id))
    except VaultError as exc:
        _fail(str(exc))


@ingest_app.command("close")
def ingest_close(
    source_id: str,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Only validate; write nothing.")
    ] = False,
    vault: VaultOpt = None,
) -> None:
    """Validate the pages citing SOURCE_ID, then freeze the source, log and index."""
    try:
        report = ingest.close(_vault(vault), source_id, _now(), dry_run=dry_run)
    except VaultError as exc:
        _fail(str(exc))
    for finding in report.findings:
        typer.echo(str(finding), err=True)
    if dry_run:
        if checks.errors(report.findings):
            _fail(f"dry run: close of {source_id} would be refused")
        typer.echo(
            f"dry run: {source_id} would close ({len(report.pages)} page(s), "
            f"{report.quotes_checked} quote(s) verified); nothing written"
        )
        return
    if not report.ok:
        _fail(f"ingest of {source_id} refused; nothing was written")
    verb = "resumed and closed" if report.resumed else "closed"
    typer.echo(
        f"{verb} {source_id} ({len(report.pages)} page(s), {report.quotes_checked} quote(s) "
        f"verified) sha256={report.sha256[:12]}"
    )


@app.command("search")
def search_cmd(
    text: str,
    limit: Annotated[int, typer.Option("-k", min=1)] = 5,
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """Ranked full-text search; each hit carries a path:line citation."""
    hits = search.query(_vault(vault), text, limit)
    if as_json:
        _json([asdict(h) | {"citation": h.citation} for h in hits])
        return
    for hit in hits:
        typer.echo(f"{hit.citation}  {hit.title}\n    {hit.snippet}")
    if not hits:
        hint = "try other words, the English term, or a prefix such as `recupera*`"
        typer.echo(f"no hits for {text!r}: {hint}", err=True)


@index_app.command("rebuild")
def index_rebuild(vault: VaultOpt = None) -> None:
    """Regenerate index.md and .sb/index.sqlite from the files."""
    v = _vault(vault)
    pages = load_pages(v)
    logbook.render_index(v, pages)
    typer.echo(f"index.md regenerated; indexed {search.rebuild(v)} page(s)")


@app.command()
def lint(
    path: Annotated[
        list[str] | None, typer.Option("--path", help="Only report on this file (repeatable).")
    ] = None,
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """Run the deterministic checks; exit 1 on any error."""
    try:
        findings = checks.run(_vault(vault), only=path)
    except VaultError as exc:
        _fail(str(exc))
    if as_json:
        _json([f.to_dict() for f in findings])
    else:
        for finding in findings:
            typer.echo(str(finding))
    if checks.errors(findings):
        raise typer.Exit(1)
    if not as_json:
        typer.echo(f"ok ({len(findings)} warning(s))")


@app.command("clip")
def clip_cmd(
    urls: Annotated[
        list[str] | None, typer.Argument(help="Links: pages, PDFs, videos, playlists.")
    ] = None,
    from_file: Annotated[
        Path | None, typer.Option("--from", help="A text file with one link per line.")
    ] = None,
    limit: Annotated[int | None, typer.Option(min=1, help="At most N videos per playlist.")] = None,
    lang: Annotated[str, typer.Option(help="Caption languages, in order of preference.")] = "pt,en",
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """Capture links into sources/inbox/, skipping any the vault already has (ADR-014)."""
    from sb import clip  # the only networked module: imported by this command alone

    links = list(urls or [])
    if from_file is not None:
        try:
            lines = from_file.read_text(encoding="utf-8").splitlines()
        except (OSError, UnicodeDecodeError) as exc:
            _fail(f"cannot read {from_file}: {exc}")
        links += [ln.strip() for ln in lines if ln.strip() and not ln.lstrip().startswith("#")]
    if not links:
        _fail("give at least one link, or --from FILE")
    langs = [code.strip() for code in lang.split(",") if code.strip()]
    outcomes = clip.clip(_vault(vault), links, _now(), limit=limit, langs=langs)
    if as_json:
        _json([asdict(o) for o in outcomes])
    else:
        for o in outcomes:
            ident = f" {o.source_id}" if o.source_id else ""
            typer.echo(f"{o.status:<9}{ident} {o.url}  ({o.detail})")
    if any(o.status == "failed" for o in outcomes):
        raise typer.Exit(1)


@app.command("log")
def log_cmd(
    op: Annotated[str, typer.Argument(help="Operation: query, analysis, wrapup, consolidate…")],
    title: Annotated[str, typer.Argument(help="What it was about, one line.")],
    vault: VaultOpt = None,
) -> None:
    """Append `## [date] OP | TITLE` to the append-only log."""
    try:
        typer.echo(logbook.append(_vault(vault), op, title, _now()))
    except ValueError as exc:
        _fail(str(exc))


@memory_app.command("brief")
def memory_brief(vault: VaultOpt = None) -> None:
    """Working memory, open decisions, inbox and health: what a session starts from."""
    typer.echo(memory.brief(_vault(vault)), nl=False)


@app.command()
def candidates(as_json: JsonOpt = False, vault: VaultOpt = None) -> None:
    """Consolidation leads (possible duplicates, stale links, contradictions) to judge."""
    leads = review.candidates(_vault(vault))
    if as_json:
        _json(leads)
        return
    for lead in leads:
        typer.echo(f"{lead['kind']:<14} {' <-> '.join(lead['pages'])}  ({lead['reason']})")
    typer.echo(f"{len(leads)} lead(s)")


@app.command("eval")
def eval_cmd(
    queries: Annotated[Path, typer.Option(help="Golden queries YAML.")] = Path("eval/queries.yaml"),
    as_json: JsonOpt = False,
    vault: VaultOpt = None,
) -> None:
    """Measure retrieval (recall@5, MRR, p95 latency) and report the ADR-003 hybrid trigger."""
    v = _vault(vault)
    try:
        report = evaluate.run(v, evaluate.load_queries(v.root / queries))
    except VaultError as exc:
        _fail(str(exc))
    if not report.queries:
        typer.echo(f"no queries in {queries} yet; add `- query: ...` / `expect: [Page]` items")
        return
    data = asdict(report) | {"trigger_hybrid": report.trigger_hybrid}
    if as_json:
        _json(data)
        return
    typer.echo(
        f"queries={report.queries} recall@{evaluate.K}={report.recall_at_k:.2f} "
        f"mrr={report.mrr:.2f} p95={report.p95_ms:.1f}ms"
    )
    for miss in report.misses:
        typer.echo(f"  miss: {miss['query']!r} missing {miss['missing']}")
    if report.trigger_hybrid:
        typer.echo(f"recall below {evaluate.RECALL_TRIGGER}: evaluate hybrid retrieval (ADR-003)")


@app.command()
def doctor(vault: VaultOpt = None) -> None:
    """Check the environment: Python, SQLite FTS5 with accent folding, the vault."""
    problems = 0
    typer.echo(
        f"sb {__version__} on Python {sys.version.split()[0]}, SQLite {sqlite3.sqlite_version}"
    )
    try:
        conn = sqlite3.connect(":memory:")
        conn.execute(
            "CREATE VIRTUAL TABLE t USING fts5(x, tokenize='unicode61 remove_diacritics 2')"
        )
        conn.close()
        typer.echo("ok   FTS5 with accent folding")
    except sqlite3.OperationalError as exc:
        problems += 1
        typer.echo(f"FAIL FTS5 unavailable ({exc}); search cannot work")
    try:
        found = Vault.find(vault or Path.cwd())
        typer.echo(f"ok   vault at {found.root}")
        warning = path_budget_warning(found.root)
        if warning:
            typer.echo(f"warn {warning}")
        for rel in (".claude/settings.local.json", ".githooks/pre-commit"):
            current = sb_command() in _hook_commands(found.root / rel)
            label = "ok  " if current else "warn"
            hint = "" if current else " (missing or from another machine: run `sb hook install`)"
            typer.echo(f"{label} {rel}{hint}")
        if "hooks" in _json_or_empty(found.root / ".claude" / "settings.json"):
            typer.echo(
                "warn .claude/settings.json holds hooks (pre-ADR-011): run `sb hook install`"
            )
        on_path = shutil.which("sb") is not None
        typer.echo(f"{'ok  ' if on_path else 'warn'} `sb` on PATH (skills call `sb` directly)")
    except VaultError as exc:
        typer.echo(f"info {exc}")
    if problems:
        raise typer.Exit(1)


def _json_or_empty(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _hook_commands(path: Path) -> str:
    """The hook command text of a generated file: parsed JSON commands, or the script."""
    if path.suffix == ".json":
        events = _json_or_empty(path).get("hooks")
        commands = [
            str(h.get("command", ""))
            for event in (events.values() if isinstance(events, dict) else [])
            for group in (event if isinstance(event, list) else [])
            for h in ((group.get("hooks") if isinstance(group, dict) else None) or [])
            if isinstance(h, dict)
        ]
        return "\n".join(commands)
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return ""


@hook_app.command("session-start")
def hook_session_start(vault: VaultOpt = None) -> None:
    """SessionStart hook: print the brief (Claude Code adds stdout to the context)."""
    try:
        found = Vault.find(vault or Path.cwd())
    except VaultError:
        return  # not in a vault: stay silent
    typer.echo(memory.brief(found), nl=False)
    if shutil.which("sb") is None:  # skills say `sb`; tell the agent how to reach it here
        typer.echo(f"\nNote: `sb` is not on PATH in this environment; run it as: {sb_command()}")


@hook_app.command("install")
def hook_install(vault: VaultOpt = None) -> None:
    """(Re)write this machine's Claude Code hooks and git pre-commit (once per clone)."""
    v = _vault(vault)
    try:
        written = v.install_hooks()
    except VaultError as exc:
        _fail(str(exc))
    for rel in written:
        typer.echo(f"updated {rel}")
    typer.echo("enable the pre-commit hook once per clone: git config core.hooksPath .githooks")
    typer.echo("if .githooks/ was committed before (pre-ADR-011): git rm -r --cached .githooks")


@hook_app.command("post-edit")
def hook_post_edit(vault: VaultOpt = None) -> None:
    """PostToolUse hook: lint the edited file; exit 2 shows its errors to Claude."""
    try:
        payload = json.loads(sys.stdin.buffer.read().decode("utf-8") or "{}")
    except (json.JSONDecodeError, UnicodeDecodeError):
        return
    raw = (payload.get("tool_input") or {}).get("file_path")
    if not raw or not str(raw).endswith(".md"):
        return
    edited = Path(raw)
    try:
        found = Vault.find(vault or edited.parent)
        rel = found.rel(edited.resolve())
    except (VaultError, ValueError):
        return  # outside any vault
    if rel.startswith("wiki/"):
        logbook.render_index(found, load_pages(found))  # keep the generated catalogue current
    try:
        errs = checks.errors(checks.run(found, only=[rel]))
    except VaultError:
        return  # the edited file is gone (moved or deleted since): nothing to check
    if errs:
        for finding in errs:
            typer.echo(str(finding), err=True)
        raise typer.Exit(2)
