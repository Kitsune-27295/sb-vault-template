"""The template set `sb init` installs and `sb upgrade` refreshes (ADR-016). Never writes."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from importlib import resources
from importlib.resources.abc import Traversable

from sb import __version__

MANIFEST = "templates.json"  # in `.sb/`: target path -> digest of the template last installed
GITIGNORE = ".gitignore"  # merged line by line, never replaced
# The curator's from the first day: created when missing, never rewritten (ADR-016).
SEEDS = frozenset({"memory/hot.md", "memory/lessons.md", "eval/queries.yaml"})

_FILES = (
    ("AGENTS.md", "AGENTS.md"),
    ("CLAUDE.md", "CLAUDE.md"),
    ("hot.md", "memory/hot.md"),
    ("lessons.md", "memory/lessons.md"),
    ("gitignore", GITIGNORE),
    ("gitattributes", ".gitattributes"),
    ("settings.json", ".claude/settings.json"),
    ("queries.yaml", "eval/queries.yaml"),
    ("setup-sb.py", "setup-sb.py"),
    ("sb-update.yml", ".github/workflows/sb-update.yml"),
)


def templates_root() -> Traversable:
    return resources.files("sb") / "templates"


def text_digest(text: str) -> str:
    """sha256 of the text with LF line endings, so a CRLF checkout still compares equal."""
    return hashlib.sha256(text.replace("\r\n", "\n").encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class Template:
    target: str  # vault-relative POSIX path
    text: str

    @property
    def digest(self) -> str:
        return text_digest(self.text)

    @property
    def is_seed(self) -> bool:
        return self.target in SEEDS

    @property
    def is_merged(self) -> bool:
        return self.target == GITIGNORE

    @property
    def is_managed(self) -> bool:
        return not (self.is_seed or self.is_merged)


def installed() -> list[Template]:
    """Every file `sb init` installs, in a stable order (skills are sorted by name)."""
    root = templates_root()
    names = list(_FILES)
    skills = sorted(s.name for s in (root / "skills").iterdir() if s.is_dir())
    names += [(f"skills/{s}/SKILL.md", f".claude/skills/{s}/SKILL.md") for s in skills]
    return [
        Template(target, root.joinpath(*name.split("/")).read_text(encoding="utf-8"))
        for name, target in names
    ]


def parse_manifest(text: str) -> dict[str, str]:
    """The recorded digests; `ValueError` when the document is not a manifest."""
    data = json.loads(text)
    files = data.get("files") if isinstance(data, dict) else None
    if not isinstance(files, dict) or not all(
        isinstance(k, str) and isinstance(v, str) for k, v in files.items()
    ):
        raise ValueError("expected an object with a `files` map of path -> digest")
    return dict(files)


def dump_manifest(files: dict[str, str]) -> str:
    return json.dumps({"sb": __version__, "files": files}, indent=2, sort_keys=True) + "\n"
