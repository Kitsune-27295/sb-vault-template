from sb.cli import app

app()
