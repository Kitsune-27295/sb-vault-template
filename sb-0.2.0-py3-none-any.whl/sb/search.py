"""Derived full-text index over the vault (SQLite FTS5, BM25). Never a source of truth.

The index keeps itself current: every query first syncs it against the files, using each
file's (mtime, size) signature, so pages written moments ago are searchable and deleted
pages disappear, with no manual step.
"""

from __future__ import annotations

import os
import re
import sqlite3
from contextlib import closing, suppress
from dataclasses import dataclass

from sb.frontmatter import FrontmatterError, parse
from sb.pages import Page, load_page
from sb.vault import Vault, fold, read_text

INDEXED_ZONES = frozenset({"wiki", "notes", "context", "memory", "sources"})
_SCHEMA = (
    "CREATE VIRTUAL TABLE IF NOT EXISTS pages USING fts5("
    "path UNINDEXED, title, description, body, "
    "tokenize = 'unicode61 remove_diacritics 2')",
    "CREATE TABLE IF NOT EXISTS files (path TEXT PRIMARY KEY, sig TEXT)",
)
_SCHEMA_VERSION = 2  # bump when _SCHEMA changes: older index files are rebuilt automatically
# bm25() weights per column: path (unindexed), title, description, body. Lower score = better.
# Zone weight (bm25 is negative: a larger multiplier ranks higher). Compiled knowledge is
# what a query should read first; raw sources are for checking quotes, and working memory
# mentions everything in passing (ADR-012).
_ZONE_WEIGHT = (
    "CASE WHEN path LIKE 'wiki/%' THEN 2.0 "
    "WHEN path LIKE 'memory/%' OR path LIKE 'sources/%' THEN 0.7 ELSE 1.0 END"
)
_RANK = f"bm25(pages, 0.0, 10.0, 5.0, 1.0) * {_ZONE_WEIGHT}"
_SQL = (
    "SELECT path, title, snippet(pages, 3, ?, ?, '…', 12), "
    f"{_RANK} AS score FROM pages WHERE pages MATCH ? ORDER BY score LIMIT ?"
)
# Control characters mark hits inside snippets: they never occur in text, so the snippet
# window can be located in the file exactly. Displayed as «guillemets».
_HI_START, _HI_END = chr(2), chr(3)
# Function words that match nearly every page (pt-BR and English). Dropped from queries
# unless the query has nothing else.
STOPWORDS = frozenset(  # folded like the query terms, so "são" and "até" match too
    fold(word)
    for word in [
        "a",
        "o",
        "as",
        "os",
        "um",
        "uma",
        "uns",
        "umas",
        "de",
        "do",
        "da",
        "dos",
        "das",
        "em",
        "no",
        "na",
        "nos",
        "nas",
        "por",
        "pelo",
        "pela",
        "para",
        "com",
        "sem",
        "e",
        "ou",
        "que",
        "se",
        "como",
        "mas",
        "mais",
        "menos",
        "ao",
        "aos",
        "à",
        "às",
        "é",
        "são",
        "ser",
        "foi",
        "entre",
        "sobre",
        "até",
        "the",
        "an",
        "of",
        "in",
        "on",
        "at",
        "to",
        "for",
        "with",
        "and",
        "or",
        "is",
        "are",
        "be",
        "by",
        "from",
        "as",
        "this",
        "that",
        "it",
        "its",
    ]
)


@dataclass(frozen=True)
class Hit:
    path: str
    title: str
    line: int
    snippet: str
    score: float

    @property
    def citation(self) -> str:
        return f"{self.path}:{self.line}"


def _connect(vault: Vault) -> sqlite3.Connection:
    vault.state.mkdir(exist_ok=True)
    conn = sqlite3.connect(vault.index_db)
    if conn.execute("PRAGMA user_version").fetchone()[0] != _SCHEMA_VERSION:
        conn.close()  # derived data from another schema version: discard and recreate
        vault.index_db.unlink()
        conn = sqlite3.connect(vault.index_db)
        conn.execute(f"PRAGMA user_version = {_SCHEMA_VERSION}")
    for statement in _SCHEMA:
        conn.execute(statement)
    return conn


def _signature(entry: os.DirEntry[str]) -> str:
    """Changes whenever the file does: atomic writes also give it a new inode and ctime.

    On Windows the DirEntry stat comes from the directory listing (no extra syscall);
    there `st_ino` is 0 and ctime is the creation time, which a replace also renews.
    """
    st = entry.stat()
    return f"{st.st_mtime_ns}:{st.st_size}:{st.st_ino}:{st.st_ctime_ns}"


def _row(page: Page) -> tuple[str, str, str, str]:
    return (page.rel, page.title, str(page.meta.get("description", "")), page.body)


def sync(vault: Vault) -> int:
    """Bring the index in line with the files; return how many paths changed."""
    current: dict[str, str] = {}
    for rel, entry in vault.entries(".md"):
        if rel.split("/", 1)[0] in INDEXED_ZONES:
            current[rel] = _signature(entry)
    with closing(_connect(vault)) as conn, conn:
        known = dict(conn.execute("SELECT path, sig FROM files"))
        changed = [rel for rel, sig in current.items() if known.get(rel) != sig]
        stale = changed + [rel for rel in known if rel not in current]
        conn.executemany("DELETE FROM pages WHERE path = ?", [(r,) for r in stale])
        conn.executemany("DELETE FROM files WHERE path = ?", [(r,) for r in stale])
        for rel in changed:
            # Unreadable pages are lint's business; remember their signature anyway.
            with suppress(FrontmatterError, UnicodeDecodeError):
                row = _row(load_page(vault, vault.root / rel))
                conn.execute("INSERT INTO pages VALUES (?, ?, ?, ?)", row)
            conn.execute("INSERT INTO files VALUES (?, ?)", (rel, current[rel]))
    return len(stale)


def rebuild(vault: Vault) -> int:
    """Drop and recreate the index from the files; return the number of indexed paths."""
    vault.index_db.unlink(missing_ok=True)
    return sync(vault)


def _tokens(text: str) -> list[str]:
    return re.findall(r"\w+", fold(text))


def _cite_line(vault: Vault, rel: str, snippet: str, terms: list[str]) -> int:
    """1-based file line of the snippet's first highlighted term.

    The snippet window is located in the file's token stream (so it may span lines);
    failing that, the first line with a query term; failing that, line 1.
    """
    lines = read_text(vault.root / rel).split("\n")
    try:
        body_start = parse("\n".join(lines)).body_offset  # snippets come from the body only
    except FrontmatterError:
        body_start = 0
    stream = [
        (tok, n) for n, line in enumerate(lines, start=1) if n > body_start for tok in _tokens(line)
    ]
    parts = snippet.split(_HI_START)
    if len(parts) > 1:
        before, hit = _tokens(parts[0])[-3:], _tokens(parts[1].split(_HI_END)[0])
        window = before + hit[:1]
        words = [tok for tok, _ in stream]
        for i in range(len(words) - len(window) + 1):
            if words[i : i + len(window)] == window:
                return stream[i + len(before)][1]
    folded = [fold(t.rstrip("*")) for t in terms]
    body_lines = list(enumerate(lines, 1))[body_start:]  # snippets never come from frontmatter
    return next((n for n, line in body_lines if any(t in fold(line) for t in folded)), 1)


def _match_terms(text: str) -> list[str]:
    """Query words minus stopwords (unless nothing else is left); `term*` stays a prefix."""
    terms = re.findall(r"\w+\*?", text)
    content = [t for t in terms if t.endswith("*") or fold(t) not in STOPWORDS]
    return content or terms


def _fts(term: str) -> str:
    return f'"{term.rstrip("*")}"*' if term.endswith("*") else f'"{term}"'


def query(vault: Vault, text: str, limit: int = 5) -> list[Hit]:
    """Match all content terms; if nothing matches, fall back to any of them."""
    terms = _match_terms(text)
    if not terms:
        return []
    sync(vault)
    quoted = [_fts(t) for t in terms]
    with closing(_connect(vault)) as conn:
        rows = conn.execute(_SQL, (_HI_START, _HI_END, " ".join(quoted), limit)).fetchall()
        if not rows and len(quoted) > 1:
            rows = conn.execute(_SQL, (_HI_START, _HI_END, " OR ".join(quoted), limit)).fetchall()
    return [
        Hit(p, t, _cite_line(vault, p, s, terms), _display(s), sc)
        for p, t, s, sc in rows
        if (vault.root / p).is_file()
    ]


def _display(snippet: str) -> str:
    """One line, with «guillemets» around hits: `[ ]` would collide with [[wikilinks]]."""
    return " ".join(snippet.replace(_HI_START, "«").replace(_HI_END, "»").split())
