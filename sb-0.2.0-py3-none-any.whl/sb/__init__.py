"""sb: local-first LLM Wiki with operational memory."""

__version__ = "0.2.0"
