"""Retrieval evaluation (S8): golden queries → recall@k, MRR, latency; the ADR-003 trigger."""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from sb import search
from sb.pages import link_key
from sb.vault import Vault, VaultError, read_text

RECALL_TRIGGER = 0.8  # ADR-003: below this recall@5, evaluate hybrid (vector) retrieval
K = 5


@dataclass
class EvalReport:
    queries: int = 0
    recall_at_k: float = 0.0
    mrr: float = 0.0
    p95_ms: float = 0.0
    misses: list[dict[str, Any]] = field(default_factory=list)

    @property
    def trigger_hybrid(self) -> bool:
        return self.queries > 0 and self.recall_at_k < RECALL_TRIGGER


def load_queries(path: Path) -> list[dict[str, Any]]:
    """YAML list of `{query: str, expect: [page name, ...]}`."""
    if not path.is_file():
        raise VaultError(
            f"{path} not found; create it with `- query: ...` / `expect: [Page]` items"
        )
    try:
        data = yaml.safe_load(read_text(path)) or []
    except (yaml.YAMLError, UnicodeDecodeError) as exc:
        raise VaultError(f"{path}: not valid UTF-8 YAML ({exc})") from exc
    if not isinstance(data, list) or not all(
        isinstance(d, dict)
        and isinstance(d.get("query"), str)
        and isinstance(d.get("expect"), list)
        and len(d["expect"]) > 0
        for d in data
    ):
        msg = f"{path}: expected a list of {{query: str, expect: [names]}} (expect non-empty)"
        raise VaultError(msg)
    return data


def run(vault: Vault, queries: list[dict[str, Any]], k: int = K) -> EvalReport:
    report = EvalReport(queries=len(queries))
    if not queries:
        return report
    search.sync(vault)  # warm-up: the first timed query must not pay the index sync
    recalls: list[float] = []
    reciprocal: list[float] = []
    latencies: list[float] = []
    for item in queries:
        expected = {link_key(str(e)) for e in item["expect"]}
        start = time.perf_counter()
        hits = search.query(vault, item["query"], k)
        latencies.append((time.perf_counter() - start) * 1000)
        ranked = [link_key(Path(h.path).stem) for h in hits]
        found = expected & set(ranked)
        recalls.append(len(found) / len(expected))
        rank = next((i for i, name in enumerate(ranked, start=1) if name in expected), 0)
        reciprocal.append(1 / rank if rank else 0.0)
        if len(found) < len(expected):
            report.misses.append(
                {"query": item["query"], "missing": sorted(expected - found), "got": ranked}
            )
    latencies.sort()
    report.recall_at_k = sum(recalls) / len(recalls)
    report.mrr = sum(reciprocal) / len(reciprocal)
    report.p95_ms = latencies[math.ceil(0.95 * len(latencies)) - 1]  # nearest-rank
    return report
