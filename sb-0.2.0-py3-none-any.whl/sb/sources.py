"""Source capture into the inbox, and freezing into the immutable store."""

from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any

from sb.vault import BOM, Vault, VaultError, read_text, secret_lines, slugify, write_text_atomic

TEXT_SUFFIXES = {".md", ".markdown", ".txt"}
SOURCE_ID = re.compile(r"[0-9]{8}-[a-z0-9]+(?:-[a-z0-9]+)*")


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def normalize(text: str) -> str:
    """Canonical stored form: no BOM, LF line endings."""
    return text.removeprefix(BOM).replace("\r\n", "\n").replace("\r", "\n")


def _meta_path(md: Path) -> Path:
    return md.with_suffix(".meta.json")


def read_meta(md: Path) -> dict[str, Any]:
    """The `.meta.json` sidecar; a damaged one (e.g. a merge conflict) is a `VaultError`."""
    path = _meta_path(md)
    try:
        data = json.loads(read_text(path))
    except (ValueError, UnicodeDecodeError) as exc:  # JSONDecodeError is a ValueError
        raise VaultError(f"{path.name} is not valid JSON ({exc}); restore it from git") from exc
    if not isinstance(data, dict):
        raise VaultError(f"{path.name} must hold a JSON object; restore it from git")
    return data


def _write_meta(md: Path, meta: dict[str, Any]) -> None:
    write_text_atomic(_meta_path(md), json.dumps(meta, indent=2, ensure_ascii=False) + "\n")


def frozen_ids(vault: Vault) -> set[str]:
    return {p.stem for p in vault.sources.glob("*.md")}


def inbox_ids(vault: Vault) -> set[str]:
    return {p.stem for p in vault.inbox.glob("*.md")}


def source_text(vault: Vault, source_id: str) -> str | None:
    """The normalised text of a frozen or inbox source, or None if it cannot be read."""
    if not SOURCE_ID.fullmatch(source_id):
        return None
    for path in (vault.sources / f"{source_id}.md", vault.inbox / f"{source_id}.md"):
        if path.is_file():
            try:
                return normalize(read_text(path))
            except UnicodeDecodeError:
                return None
    return None


def check_id(source_id: str) -> None:
    """Refuse anything but a plain `YYYYMMDD-slug` id: it becomes a path (no traversal)."""
    if not SOURCE_ID.fullmatch(source_id):
        raise VaultError(
            f"invalid source id {source_id!r}; expected YYYYMMDD-slug as printed by `sb capture`"
        )


def capture(vault: Vault, file: Path, now: datetime, url: str | None = None) -> str:
    """Give a text file a fresh id in `sources/inbox/`; return the id.

    A file from elsewhere is copied. A file already in the inbox (dropped there by the
    curator or a web clipper) is renamed in place; one that already has an id is kept.
    """
    in_inbox = file.resolve().parent == vault.inbox.resolve()
    if in_inbox and SOURCE_ID.fullmatch(file.stem) and file.suffix == ".md":
        return file.stem
    if file.suffix.lower() not in TEXT_SUFFIXES:
        raise VaultError(
            f"unsupported source type {file.suffix!r}; expected one of {TEXT_SUFFIXES}"
        )
    try:
        text = file.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        raise VaultError(f"{file} is not UTF-8 text") from exc
    meta: dict[str, Any] = {"original_name": file.name}
    if url:  # where a hand-clipped file came from: `sb clip` then treats that link as stored
        meta["url"] = url.strip()
    source_id = capture_text(vault, file.stem, text, now, meta)
    if in_inbox:
        file.unlink()  # the id'd copy replaces the dropped original
    return source_id


def capture_text(
    vault: Vault, name: str, text: str, now: datetime, meta: dict[str, Any] | None = None
) -> str:
    """Store `text` in `sources/inbox/` under a fresh id derived from `name`; return the id.

    The one entry point for new sources (files and `sb clip`): credentials are refused,
    the text is normalised, and the sidecar records what was captured and when.
    """
    found = secret_lines(text)
    if found:
        raise VaultError(f"{name}: line {found[0]} looks like a credential; remove it first")
    base = f"{now:%Y%m%d}-{slugify(name)}"
    # Ids share the wikilink namespace with page names (ADR-006), so avoid every taken name.
    taken = {p.stem.casefold() for p in (*vault.markdown_files(), *vault.inbox.glob("*.md"))}
    source_id, n = base, 2
    while source_id.casefold() in taken:
        source_id, n = f"{base}-{n}", n + 1
    target = vault.inbox / f"{source_id}.md"
    body = normalize(text)
    write_text_atomic(target, body)
    _write_meta(
        target,
        {
            "id": source_id,
            **(meta or {}),
            "captured_at": now.isoformat(timespec="seconds"),
            "captured_sha256": sha256_text(body),
        },
    )
    return source_id


def source_metas(vault: Vault) -> dict[str, dict[str, Any]]:
    """Sidecar metadata of every source (frozen and inbox), keyed by id; damaged ones skipped."""
    out: dict[str, dict[str, Any]] = {}
    for folder in (vault.sources, vault.inbox):
        for md in folder.glob("*.md"):
            if _meta_path(md).exists():
                try:
                    out[md.stem] = read_meta(md)
                except VaultError:
                    continue  # lint reports damaged sidecars (SRC002)
    return out


def freeze(vault: Vault, source_id: str, now: datetime) -> str:
    """Normalise an inbox source (no BOM, LF) into the immutable store; return its sha256.

    Order matters: the sidecar is written before the source, so a crash never leaves a
    frozen source without its hash, and a retry after such a crash can complete.
    """
    check_id(source_id)
    src = vault.inbox / f"{source_id}.md"
    dest = vault.sources / f"{source_id}.md"
    if dest.exists():
        raise VaultError(f"source {source_id} is already frozen")
    meta = read_meta(src) if _meta_path(src).exists() else {"id": source_id}
    try:
        text = normalize(read_text(src))
    except UnicodeDecodeError as exc:
        raise VaultError(f"{vault.rel(src)} is not UTF-8; re-save it as UTF-8") from exc
    digest = sha256_text(text)
    meta |= {"sha256": digest, "frozen_at": now.isoformat(timespec="seconds")}
    _write_meta(dest, meta)
    write_text_atomic(dest, text)
    src.unlink()
    _meta_path(src).unlink(missing_ok=True)
    return digest


def verify_hash(vault: Vault, source_id: str) -> bool:
    """Hash the bytes on disk, so a newline or BOM change is detected too."""
    check_id(source_id)
    md = vault.sources / f"{source_id}.md"
    if not _meta_path(md).exists():
        raise VaultError(f"{vault.rel(md)} has no .meta.json sidecar; its integrity is unknown")
    digest = hashlib.sha256(md.read_bytes()).hexdigest()
    return bool(read_meta(md).get("sha256") == digest)
