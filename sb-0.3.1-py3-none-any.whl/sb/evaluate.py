"""Retrieval evaluation (S8, S17): golden queries → recall, MRR, hit rate, NDCG, latency.

Also the ADR-003 trigger, and the run history (`eval/runs.jsonl`, written only on request).
"""

from __future__ import annotations

import hashlib
import json
import math
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml

from sb import __version__, search
from sb.pages import link_key
from sb.vault import BOM, Vault, VaultError, read_text, write_text_atomic

RECALL_TRIGGER = 0.8  # ADR-003: below this recall@5, evaluate hybrid (vector) retrieval
K = 5
RUNS = "eval/runs.jsonl"  # curator data, append-only: never inside the derived `.sb/` cache
_METRICS = ("recall_at_k", "mrr", "hit_rate", "ndcg_at_k")


@dataclass
class EvalReport:
    queries: int = 0
    recall_at_k: float = 0.0
    mrr: float = 0.0
    p95_ms: float = 0.0
    misses: list[dict[str, Any]] = field(default_factory=list)
    hit_rate: float = 0.0  # share of queries with at least one expected page in the top k
    ndcg_at_k: float = 0.0  # binary gain, so the ideal list holds min(expected, k) pages
    ranks: list[int] = field(default_factory=list)  # first expected page per query; 0 = none
    by_kind: dict[str, dict[str, float]] = field(default_factory=dict)  # only labelled queries
    fingerprint: str = ""  # names the workload (queries and k), so only like is compared to like

    @property
    def trigger_hybrid(self) -> bool:
        return self.queries > 0 and self.recall_at_k < RECALL_TRIGGER


def load_queries(path: Path) -> list[dict[str, Any]]:
    """YAML list of `{query: str, expect: [page name, ...], kind: str (optional)}`."""
    if not path.is_file():
        raise VaultError(
            f"{path} not found; create it with `- query: ...` / `expect: [Page]` items"
        )
    try:
        data = yaml.safe_load(read_text(path)) or []
    except (yaml.YAMLError, UnicodeDecodeError) as exc:
        raise VaultError(f"{path}: not valid UTF-8 YAML ({exc})") from exc
    if not isinstance(data, list) or not all(
        isinstance(d, dict)
        and isinstance(d.get("query"), str)
        and isinstance(d.get("expect"), list)
        and len(d["expect"]) > 0
        and isinstance(d.get("kind", ""), str)
        for d in data
    ):
        msg = (
            f"{path}: expected a list of {{query: str, expect: [names], kind: str (optional)}} "
            "(expect non-empty)"
        )
        raise VaultError(msg)
    return data


def fingerprint(queries: list[dict[str, Any]], k: int = K) -> str:
    """Identifies a workload: the same queries, expectations, kinds and k, in any order."""
    rows = sorted(
        json.dumps(
            [item["query"], sorted(link_key(str(e)) for e in item["expect"]), item.get("kind", "")],
            ensure_ascii=False,
        )
        for item in queries
    )
    return hashlib.sha256(json.dumps([k, rows]).encode()).hexdigest()[:16]


def _ndcg(ranked: list[str], expected: set[str], k: int) -> float:
    """NDCG@k with binary gain: a page earns 1/log2(rank + 1), once."""
    seen: set[str] = set()
    gain = 0.0
    for rank, name in enumerate(ranked[:k], start=1):
        if name in expected and name not in seen:
            seen.add(name)
            gain += 1 / math.log2(rank + 1)
    ideal = sum(1 / math.log2(rank + 1) for rank in range(1, min(len(expected), k) + 1))
    return gain / ideal


def run(vault: Vault, queries: list[dict[str, Any]], k: int = K) -> EvalReport:
    report = EvalReport(queries=len(queries), fingerprint=fingerprint(queries, k))
    if not queries:
        return report
    search.sync(vault)  # warm-up: the first timed query must not pay the index sync
    recalls: list[float] = []
    reciprocal: list[float] = []
    gains: list[float] = []
    latencies: list[float] = []
    kinds: dict[str, list[float]] = {}
    for item in queries:
        expected = {link_key(str(e)) for e in item["expect"]}
        start = time.perf_counter()
        hits = search.query(vault, item["query"], k)
        latencies.append((time.perf_counter() - start) * 1000)
        ranked = [link_key(Path(h.path).stem) for h in hits]
        found = expected & set(ranked)
        recalls.append(len(found) / len(expected))
        rank = next((i for i, name in enumerate(ranked, start=1) if name in expected), 0)
        report.ranks.append(rank)
        reciprocal.append(1 / rank if rank else 0.0)
        gains.append(_ndcg(ranked, expected, k))
        if item.get("kind"):
            kinds.setdefault(item["kind"], []).append(recalls[-1])
        if len(found) < len(expected):
            report.misses.append(
                {"query": item["query"], "missing": sorted(expected - found), "got": ranked}
            )
    latencies.sort()
    report.recall_at_k = sum(recalls) / len(recalls)
    report.mrr = sum(reciprocal) / len(reciprocal)
    report.hit_rate = sum(1 for r in report.ranks if r) / len(report.ranks)
    report.ndcg_at_k = sum(gains) / len(gains)
    report.by_kind = {
        kind: {"queries": len(values), "recall_at_k": sum(values) / len(values)}
        for kind, values in sorted(kinds.items())
    }
    report.p95_ms = latencies[math.ceil(0.95 * len(latencies)) - 1]  # nearest-rank
    return report


def _is_number(value: object) -> bool:
    """A real, finite number: a hand-edited row with `true` or `NaN` is not a metric."""
    return isinstance(value, int | float) and not isinstance(value, bool) and math.isfinite(value)


def history(vault: Vault) -> list[dict[str, Any]]:
    """The recorded runs, oldest first; a damaged line is refused, naming it."""
    path = vault.root / RUNS
    if not path.is_file():
        return []
    try:
        text = read_text(path).removeprefix(BOM)
    except UnicodeDecodeError as exc:
        raise VaultError(f"{RUNS} is not UTF-8 text; restore it from git") from exc
    rows: list[dict[str, Any]] = []
    for number, line in enumerate(text.splitlines(), start=1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except ValueError as exc:
            raise VaultError(
                f"{RUNS}: line {number} is not valid JSON ({exc}); fix or remove it"
            ) from exc
        if not isinstance(row, dict):
            raise VaultError(f"{RUNS}: line {number} must be a JSON object; fix or remove it")
        rows.append(row)
    return rows


def record(vault: Vault, report: EvalReport, now: datetime) -> None:
    """Append this run to `eval/runs.jsonl` (the file is validated before anything is written)."""
    history(vault)
    row = {
        "at": now.isoformat(timespec="seconds"),
        "sb": __version__,
        "fingerprint": report.fingerprint,
        "queries": report.queries,
        **{metric: round(getattr(report, metric), 6) for metric in _METRICS},
        "p95_ms": round(report.p95_ms, 2),
    }
    path = vault.root / RUNS
    current = read_text(path) if path.is_file() else ""
    separator = "" if not current or current.endswith("\n") else "\n"
    write_text_atomic(path, current + separator + json.dumps(row, ensure_ascii=False) + "\n")


def baseline(vault: Vault, report: EvalReport) -> dict[str, Any] | None:
    """How this run differs from the last recorded run of the same workload, if there is one."""
    for row in reversed(history(vault)):
        if row.get("fingerprint") != report.fingerprint:
            continue
        delta = {
            metric: round(round(getattr(report, metric), 6) - row[metric], 6) + 0.0  # +0.0: no -0.0
            for metric in _METRICS
            if _is_number(row.get(metric))
        }
        if _is_number(row.get("p95_ms")):
            delta["p95_ms"] = round(report.p95_ms - row["p95_ms"], 2)
        regressed = any(change < -1e-9 for metric, change in delta.items() if metric in _METRICS)
        return {"at": str(row.get("at", "")), **delta, "regressed": regressed}
    return None
