"""Session brief: what the agent must know at the start of every session (ADR-005)."""

from __future__ import annotations

from sb import checks, ingest
from sb.pages import load_pages
from sb.vault import Vault, read_text

MAX_LISTED = 5


def brief(vault: Vault) -> str:
    """Working memory, open decisions, pending inbox and vault health, in one short text."""
    pages = load_pages(vault)
    parts = ["# Session brief (sb)", ""]

    hot = vault.root / "memory" / "hot.md"
    parts += ["## In flight (memory/hot.md)", ""]
    try:
        parts.append(read_text(hot).strip() if hot.is_file() else "_memory/hot.md is missing_")
    except UnicodeDecodeError:
        parts.append("_memory/hot.md is not valid UTF-8; re-save it as UTF-8_")

    proposed = sorted(
        (
            p
            for p in pages
            if p.meta.get("type") == "decision" and p.meta.get("status") == "proposed"
        ),
        key=lambda p: p.name,
    )
    parts += ["", f"## Open decisions ({len(proposed)})", ""]
    parts += [f"- [[{p.name}]] — {p.meta.get('description', '')}" for p in proposed[:MAX_LISTED]]
    if not proposed:
        parts.append("- none")

    todo = ingest.pending(vault, pages)
    inbox = [p.source_id for p in todo if p.status == "inbox"]
    parts += ["", f"## Inbox ({len(inbox)} awaiting ingest)", ""]
    parts += [f"- {sid}" for sid in inbox[:MAX_LISTED]] or ["- empty"]
    if len(inbox) > MAX_LISTED:
        parts.append(f"- … and {len(inbox) - MAX_LISTED} more")
    uncited = [p.source_id for p in todo if p.status == "frozen"]
    if uncited:  # only when there are some, so a healthy vault's brief stays as short as before
        parts += ["", f"## Uncited sources ({len(uncited)})", ""]
        parts += [f"- {sid}" for sid in uncited[:MAX_LISTED]]
        if len(uncited) > MAX_LISTED:
            parts.append(f"- … and {len(uncited) - MAX_LISTED} more")
        parts.append("- Frozen but cited by no wiki page: run `sb ingest pending`.")

    findings = checks.run(vault)
    errs = checks.errors(findings)
    parts += ["", f"## Health: {len(errs)} error(s), {len(findings) - len(errs)} warning(s)", ""]
    parts += [f"- {f}" for f in errs[:MAX_LISTED]]
    if errs:
        parts.append("- Run `sb lint` for the full list.")
    return "\n".join(parts) + "\n"
