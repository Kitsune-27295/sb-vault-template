"""Turning a document's bytes into markdown, offline (S26, ADR-029).

HTML, PDF and plain text become the markdown a source is made of. Nothing here touches the
network, so `sb clip` (which fetches) and `sb import` (which reads a folder) share it, and the
core stays offline: this module must never import `urllib.request`. HTML and PDF need the
`capture` extra, imported inside the functions that use it.
"""

from __future__ import annotations

import hashlib
import io
import json
import logging
import re
from typing import Any
from urllib.parse import urljoin, urlsplit, urlunsplit

from sb.pages import mask_code
from sb.vault import extra_hint


class ExtractError(Exception):
    """One document could not be read; the others continue."""


class NoContentError(ExtractError):
    """Readable, but no text worth keeping (a page of links, a scan)."""


def host_of(netloc: str) -> str:
    host = netloc.lower().rsplit("@", 1)[-1].split(":", 1)[0]
    for prefix in ("www.", "m."):
        host = host.removeprefix(prefix)
    return host


def missing(package: str) -> str:
    return f"{package} is not installed; {extra_hint('capture')}"


def front(meta: dict[str, Any]) -> str:
    lines = [f"{k}: {json.dumps(v, ensure_ascii=False)}" for k, v in meta.items() if v]
    return "---\n" + "\n".join(lines) + "\n---\n"


_PRE = re.compile(r"<pre\b[^>]*>(.*?)</pre>", re.S | re.I)
_NOT_CONTENT = re.compile(r"<!--.*?-->|<(script|style|template)\b.*?</\1>", re.S | re.I)
_ONLY_EMPTY_CODE = re.compile(r"(?:\s*<code\b[^>]*>\s*</code>)*\s*", re.I)
# A markdown link, not an image: its text (escapes allowed), then a `<...>` or a bare destination
# and an optional quoted title.
_LINK = re.compile(
    r"(?<!!)\[(?P<text>(?:\\.|[^\]\\\n])*)\]"
    r"\(\s*(?:<(?P<angle>(?:\\.|[^<>\\\n])*)>|(?P<bare>(?:[^()\s]|\([^()\s]*\))*))"
    r'(?:\s+"[^"]*")?\s*\)'
)
_ESCAPED = re.compile(r"\\([\\<>])")
_TRACKING = re.compile(r"^(utm_.*|fbclid|gclid|dclid|mc_cid|mc_eid|igshid)$")
_SHARE = re.compile(r"^(si|feature|ref_src)$")


def is_tracking(name: str, *, share: bool = False) -> bool:
    """True for a query parameter that only reports where a visitor came from.

    `share` adds `si`, `feature` and `ref_src`, which a few hosts also use to choose what the page
    shows: fine to tell two links to one page apart (`clip`), wrong to rewrite a link with, whose
    destination would change.
    """
    key = name.lower()
    return bool(_TRACKING.match(key) or (share and _SHARE.match(key)))


def empty_code_blocks(html: str) -> int:
    """How many code blocks are empty in the HTML because a script draws them in the browser.

    Interactive docs (Mermaid's editor is one) ship `<pre><code></code></pre>` and fill it with
    JavaScript; a static fetch keeps the block's label and loses the example. A `<pre>` that holds
    anything else (a line break, an image) is not waiting for a script, and markup inside a
    `<script>`, `<template>`, `<style>` or a comment is not on the page at all.
    """
    live = _NOT_CONTENT.sub("", html)
    return sum(1 for inner in _PRE.findall(live) if _ONLY_EMPTY_CODE.fullmatch(inner))


def clean_links(markdown: str, page_url: str) -> str:
    """Keep only the links that lead somewhere a reader can go.

    `markdown` carries its links as the page wrote them. A link with no text (a heading anchor)
    is dropped. A link to this page, to a `#fragment` or to `javascript:` keeps its text only.
    Any other link loses its fragment and its tracking parameters, and on a web page it is
    made absolute against the page; an exported page (a `file:` address) keeps its relative
    links relative. Code, fenced or inline, is left alone: its brackets are syntax, not links.
    """
    base = _plain(page_url, keep_query=True)
    own = _plain(page_url)
    web = urlsplit(base).scheme in ("http", "https")
    out: list[str] = []
    last = 0
    for found in _LINK.finditer(mask_code(markdown)):  # offsets hold: masking keeps the length
        written = markdown[found.start() : found.end()]
        link = _LINK.fullmatch(written)
        if link is None:
            continue
        try:
            cleaned = _clean_link(link, base, own, web)
        except ValueError:  # an address urllib cannot parse is left as it was
            continue
        out += [markdown[last : found.start()], cleaned]
        last = found.end()
    out.append(markdown[last:])
    return "".join(out)


def _clean_link(link: re.Match[str], base: str, own: str, web: bool) -> str:
    text = link["text"]
    angled = link["angle"] is not None
    target = _ESCAPED.sub(r"\1", link["angle"]) if angled else link["bare"] or ""
    if not text.strip():
        return ""
    if not target or target.startswith("#") or target.lower().startswith("javascript:"):
        return text
    resolved = _plain(urljoin(base, target))
    if resolved.rstrip("/") == own.rstrip("/"):
        return text
    shown = resolved if web else _plain(target)
    if shown == target:
        return link.group(0)
    if any(c in shown for c in " <>()"):  # the same destination form a CommonMark writer uses
        inner = shown.replace("\\", "\\\\").replace("<", "\\<").replace(">", "\\>")
        return f"[{text}](<{inner}>)"
    return f"[{text}]({shown})"


def _plain(url: str, *, keep_query: bool = False) -> str:
    """`url` without its #fragment and tracking parameters, and otherwise exactly as written."""
    parts = urlsplit(url)
    items = parts.query.split("&") if parts.query else []
    kept = [i for i in items if keep_query or not is_tracking(i.split("=", 1)[0])]
    query = "&".join(kept) if len(kept) != len(items) else parts.query
    return urlunsplit(parts._replace(query=query, fragment=""))


def page_markdown(url: str, body: bytes, ctype: str, *, links: bool = True) -> tuple[str, str]:
    """(title, markdown) of an HTML page, a PDF or plain text.

    `links=False` is the conversion of sb before 0.5.3, which kept every link as the extractor
    resolved it: `sb import` needs it to recognise a page it stored with that digest.
    """
    if ctype == "application/pdf" or body[:5] == b"%PDF-":
        return _pdf_markdown(url, body)
    if ctype.startswith("text/") and "html" not in ctype:
        text = body.decode("utf-8", errors="replace")
        title = next((ln[2:].strip() for ln in text.split("\n") if ln.startswith("# ")), "")
        return title or name_from_url(url), text
    try:
        import trafilatura
    except ImportError as exc:
        raise ExtractError(missing("trafilatura")) from exc
    html = body.decode("utf-8", errors="replace")
    content = trafilatura.extract(
        html,
        url=None if links else url,  # given a url it joins every href to the host root
        output_format="markdown",
        include_links=True,
        include_tables=True,
        include_comments=False,  # a page's comment thread is not the source (ingest 1 found an ad)
    )
    if not content or not content.strip():
        raise NoContentError("no readable main content (JavaScript-only page or paywall?)")
    meta = trafilatura.extract_metadata(html, default_url=url)
    title = (getattr(meta, "title", None) or "").strip() or name_from_url(url)
    header = {
        "title": title,
        "url": url,
        "author": getattr(meta, "author", None),
        "published": getattr(meta, "date", None),
        "site": getattr(meta, "sitename", None),
        "kind": "page",
    }
    content = clean_links(content.strip(), url) if links else content.strip()
    return title, f"{front(header)}\n# {title}\n\n{content}\n"


def _pdf_markdown(url: str, body: bytes) -> tuple[str, str]:
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise ExtractError(missing("pypdf")) from exc
    # pypdf logs a warning per odd font (a 54 KB wall for six arXiv papers); the text is fine.
    logging.getLogger("pypdf").setLevel(logging.ERROR)
    try:
        reader = PdfReader(io.BytesIO(body))
        pages = [(page.extract_text() or "").strip() for page in reader.pages]
        title = str(reader.metadata.get("/Title") or "").strip() if reader.metadata else ""
    except Exception as exc:  # malformed PDFs raise assorted errors
        raise ExtractError(f"unreadable PDF: {exc}") from exc
    if not any(pages):
        raise NoContentError("the PDF has no text layer (scanned?); OCR is out of scope")
    # Rejoin words split at a line end ("ho-\nmogeneous"), so they can be quoted; a hyphen
    # followed by an upper-case letter or a digit is kept (it is likely a real one).
    pages = [_LINE_HYPHEN.sub(r"\1\2", text) for text in pages]
    first_line = next((ln.strip() for ln in pages[0].split("\n") if ln.strip()), "")
    if not title and 8 <= len(first_line) <= 150:
        title = first_line  # papers often carry no /Title; their first line is the title
    title = title or name_from_url(url)
    parts = [f"## Page {i}\n\n{text}" for i, text in enumerate(pages, start=1) if text]
    header = {"title": title, "url": url, "kind": "pdf", "pages": len(pages)}
    return title, f"{front(header)}\n# {title}\n\n" + "\n\n".join(parts) + "\n"


_LINE_HYPHEN = re.compile(r"(\w)-\n([a-zà-öø-ÿ])")  # continuation starts lower-case


def name_from_url(url: str) -> str:
    parts = urlsplit(url)
    tail = [s for s in parts.path.split("/") if s]
    return tail[-1] if tail else host_of(parts.netloc)


def content_digest(text: str) -> str:
    """sha256 of the captured content without its header (which holds the url and dates)."""
    body = text.split("\n---\n", 1)[1] if text.startswith("---\n") and "\n---\n" in text else text
    return hashlib.sha256(" ".join(body.split()).encode("utf-8")).hexdigest()
