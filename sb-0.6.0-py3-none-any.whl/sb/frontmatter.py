"""YAML frontmatter parsing and serialisation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import yaml

from sb.vault import BOM

_FENCE = "---"
_MERGE_TAG = "tag:yaml.org,2002:merge"


class FrontmatterError(ValueError):
    """Frontmatter is present but malformed."""


class _UniqueKeyLoader(yaml.SafeLoader):
    """`safe_load` that refuses a mapping key written twice: YAML keeps the last and says nothing,
    so a second `description:` would quietly replace the first."""

    def construct_mapping(self, node: yaml.MappingNode, deep: bool = False) -> dict[Any, Any]:
        seen: set[Any] = set()
        for key_node, _ in node.value:
            # Only plain scalar keys are compared: a merge key (`<<`) may be overridden on
            # purpose, and a list or mapping used as a key is refused by `super()` below.
            if not isinstance(key_node, yaml.ScalarNode) or key_node.tag == _MERGE_TAG:
                continue
            key = self.construct_object(key_node, deep=deep)
            if key in seen:
                raise yaml.constructor.ConstructorError(
                    None, None, f"duplicate key {key!r}", key_node.start_mark
                )
            seen.add(key)
        return super().construct_mapping(node, deep)


@dataclass
class Doc:
    meta: dict[str, Any] = field(default_factory=dict)
    body: str = ""
    body_offset: int = 0  # 0-based line index where the body starts


def parse(text: str) -> Doc:
    lines = text.removeprefix(BOM).split("\n")
    if not lines or lines[0].strip() != _FENCE:
        return Doc({}, text, 0)
    for end in range(1, len(lines)):
        if lines[end].strip() == _FENCE:
            raw = "\n".join(lines[1:end])
            try:
                meta = yaml.load(raw, Loader=_UniqueKeyLoader) if raw.strip() else {}
            except (
                yaml.YAMLError,
                ValueError,
            ) as exc:  # ValueError: an impossible date, 2026-13-40
                raise FrontmatterError(f"invalid YAML frontmatter: {exc}") from exc
            if not isinstance(meta, dict):
                raise FrontmatterError("frontmatter must be a mapping")
            return Doc(meta, "\n".join(lines[end + 1 :]), end + 1)
    raise FrontmatterError("frontmatter opened with '---' but never closed")


def dump(doc: Doc) -> str:
    meta = yaml.safe_dump(doc.meta, sort_keys=False, allow_unicode=True).rstrip("\n")
    return f"{_FENCE}\n{meta}\n{_FENCE}\n{doc.body}"
