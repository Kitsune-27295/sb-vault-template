"""Consolidation candidates (S7): deterministic leads for the `consolidate` skill to judge.

The CLI never decides that two pages contradict or duplicate each other; that is
judgment (ADR-004). It only surfaces pairs worth a look, each with its reason.
"""

from __future__ import annotations

import re
from itertools import combinations
from typing import Any

from sb.pages import Page, link_key, link_values, load_pages
from sb.vault import Vault, fold

TITLE_JACCARD = 0.6  # practitioner merge threshold (B2 refs, F8.2)


def _tokens(name: str) -> set[str]:
    return {t for t in re.findall(r"\w+", fold(name)) if len(t) > 2}


def _jaccard(a: set[str], b: set[str]) -> float:
    return len(a & b) / len(a | b) if a and b else 0.0


def candidates(vault: Vault) -> list[dict[str, Any]]:
    pages = [p for p in load_pages(vault) if p.zone == "wiki"]
    active = [p for p in pages if p.meta.get("status") != "superseded"]
    out: list[dict[str, Any]] = []

    linked = {p.rel: {link_key(t) for t, _ in p.links()} for p in active}  # once per page
    tokens = {p.rel: _tokens(p.name) for p in active}
    for a, b in combinations(sorted(active, key=lambda p: p.rel), 2):
        if a.meta.get("type") != b.meta.get("type"):
            continue  # a source page and the concept it feeds are meant to coexist
        score = _jaccard(tokens[a.rel], tokens[b.rel])
        if score < TITLE_JACCARD:
            continue
        if link_key(b.name) in linked[a.rel] and link_key(a.name) in linked[b.rel]:
            continue  # linked both ways = already judged complementary (consolidate skill)
        out.append(_lead("merge?", a, b, f"same type, titles overlap (Jaccard {score:.2f})"))

    superseded = {link_key(p.name): p for p in pages if p.meta.get("status") == "superseded"}
    for page in active:
        for target, line in page.links():
            old = superseded.get(link_key(target))
            successors = (
                {link_key(s) for s in link_values(old.meta.get("superseded_by"))} if old else set()
            )
            if old is not None and link_key(page.name) not in successors:
                reason = (
                    f"links to superseded [[{old.name}]] (line {line}); relink to its successor"
                )
                out.append(_lead("stale-link", page, old, reason))

    for page in active:
        for other in link_values(page.meta.get("contradicts")):
            out.append(
                {"kind": "contradiction", "pages": [page.rel], "reason": f"declared vs [[{other}]]"}
            )
    return out


def _lead(kind: str, a: Page, b: Page, reason: str) -> dict[str, Any]:
    return {"kind": kind, "pages": [a.rel, b.rel], "reason": reason}
